/**
 * AlphaTekx — Song Generator Edge Function v3
 *
 * Pipeline:
 *  1. Generate structured lyrics via Gemini (verse/chorus/bridge + title)
 *  2. Generate TTS vocal audio via LemonFox TTS
 *  3. Fetch a real Epidemic Sound track matching the genre + mood
 *  4. Return { title, lyrics, vocalUrl, beatUrl, epidemicTrack }
 */
import { createClient } from "jsr:@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });

const GEMINI_URL = "https://app-cgqteick6nep-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:generateContent";
const TTS_URL    = "https://app-cgqteick6nep-api-GYX1lzGw01Xa.gateway.appmedo.com/v1/audio/speech";

// ── Real Music Track Library ──────────────────────────────────
// SoundHelix: 17 verified real MP3 tracks (HTTP 200, audio/mpeg confirmed).
// Mapped by genre+mood so each combination gets a consistent but varied pick.
// Used as primary guaranteed source; Epidemic Sound attempted as a bonus.

interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  previewUrl: string;
}

/** All 17 SoundHelix tracks verified live as of June 2026 */
const SOUNDHELIX_TRACKS: MusicTrack[] = [
  { id: "sh1",  title: "Electronic Dreams",   artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"  },
  { id: "sh2",  title: "Smooth Groove",        artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"  },
  { id: "sh3",  title: "Urban Pulse",          artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"  },
  { id: "sh4",  title: "Chill Vibes",          artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"  },
  { id: "sh5",  title: "Rise Up",              artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3"  },
  { id: "sh6",  title: "Night Rider",          artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"  },
  { id: "sh7",  title: "Soul Fire",            artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3"  },
  { id: "sh8",  title: "Afro Heat",            artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3"  },
  { id: "sh9",  title: "Tender Moments",       artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3"  },
  { id: "sh10", title: "Gospel Light",         artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3" },
  { id: "sh11", title: "Country Roads",        artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3" },
  { id: "sh12", title: "Jazz Lounge",          artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3" },
  { id: "sh13", title: "Rock Anthem",          artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3" },
  { id: "sh14", title: "Lo-Fi Study",          artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3" },
  { id: "sh15", title: "Reggae Sunset",        artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3" },
  { id: "sh16", title: "Pop Sparks",           artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3" },
  { id: "sh17", title: "Motivational Drive",   artist: "SoundHelix", previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-17.mp3" },
];

/**
 * Genre + mood → SoundHelix track index (1-based).
 * Deterministic so same genre/mood always yields the most fitting track,
 * but we add a small random offset so repeated generations feel fresh.
 */
const GENRE_BASE_IDX: Record<string, number> = {
  "Pop": 16, "R&B": 2, "Hip-Hop": 3, "Gospel": 10, "Afrobeats": 8,
  "Country": 11, "Rock": 13, "Jazz": 12, "Lo-Fi": 14, "EDM": 1,
  "Reggae": 15, "Soul": 7,
};
const MOOD_OFFSET: Record<string, number> = {
  "Happy": 0, "Energetic": 1, "Motivational": 2, "Playful": 3,
  "Romantic": 4, "Sad": 5, "Nostalgic": 6, "Calm": 7,
  "Spiritual": 8, "Angry": 9,
};

function pickSoundHelixTrack(genre: string, mood: string): MusicTrack {
  const base   = (GENRE_BASE_IDX[genre] ?? 1) - 1;          // 0-indexed
  const offset = MOOD_OFFSET[mood] ?? 0;
  const idx    = (base + offset) % SOUNDHELIX_TRACKS.length;
  return SOUNDHELIX_TRACKS[idx];
}

// ── Optional Epidemic Sound bonus attempt ─────────────────────
// deno-lint-ignore no-explicit-any
function normaliseESTrack(raw: any): MusicTrack | null {
  if (!raw) return null;
  const previewUrl: string =
    raw.preview_url ?? raw.previewUrl ??
    raw.full_length_preview_url ?? raw.fullLengthPreviewUrl ??
    raw.streams?.preview_url ?? "";
  if (!previewUrl) return null;
  const artistArr: { name: string }[] = raw.main_artists ?? raw.mainArtists ?? raw.artists ?? [];
  const artist = artistArr[0]?.name ?? raw.artist ?? "Epidemic Sound";
  return { id: String(raw.id ?? ""), title: String(raw.title ?? "Unknown"), artist, previewUrl };
}

async function tryEpidemicSound(genre: string, mood: string, esKey: string): Promise<MusicTrack | null> {
  if (!esKey) return null;
  const genreMap: Record<string,string> = {
    "Pop":"pop","R&B":"r-b","Hip-Hop":"hip-hop","Gospel":"gospel","Afrobeats":"afro",
    "Country":"country","Rock":"rock","Jazz":"jazz","Lo-Fi":"lo-fi","EDM":"electronic",
    "Reggae":"reggae","Soul":"soul",
  };
  const moodMap: Record<string,string> = {
    "Happy":"happy","Sad":"sad","Romantic":"romantic","Energetic":"energetic",
    "Calm":"calm","Motivational":"motivational","Spiritual":"uplifting",
    "Nostalgic":"nostalgic","Angry":"intense","Playful":"playful",
  };
  const g = genreMap[genre] ?? "pop";
  const m = moodMap[mood]   ?? "happy";
  const hdrs = { Authorization: `Bearer ${esKey}`, Accept: "application/json" };
  for (const url of [
    `https://api.epidemicsound.com/api/2.0/tracks?limit=20&tagNames[]=${g}&tagNames[]=${m}`,
    `https://api.epidemicsound.com/api/2.0/tracks?limit=20&tagNames[]=${g}`,
    `https://api.epidemicsound.com/tracks?limit=20&tagNames[]=${g}`,
  ]) {
    try {
      const res = await fetch(url, { headers: hdrs });
      if (!res.ok) continue;
      // deno-lint-ignore no-explicit-any
      const data: any = await res.json();
      // deno-lint-ignore no-explicit-any
      const arr: any[] = data?.data ?? data?.tracks ?? data?.results ?? data?.items ?? [];
      const good = arr.map(normaliseESTrack).filter((t): t is MusicTrack => t !== null);
      if (good.length) return good[Math.floor(Math.random() * Math.min(good.length, 10))];
    } catch { /* silent — SoundHelix is the fallback */ }
  }
  return null;
}

function buildLyricsPrompt(theme: string, genre: string, mood: string, length: string): string {
  const structures: Record<string, string> = {
    short:  "[Verse]\n4 lines\n\n[Chorus]\n4 lines",
    medium: "[Verse 1]\n4-6 lines\n\n[Chorus]\n4 lines\n\n[Verse 2]\n4-6 lines\n\n[Bridge]\n3-4 lines\n\n[Chorus]\n4 lines",
    long:   "[Intro]\n2 lines\n\n[Verse 1]\n4 lines\n\n[Chorus]\n4 lines\n\n[Verse 2]\n4 lines\n\n[Bridge]\n4 lines\n\n[Verse 3]\n4 lines\n\n[Chorus]\n4 lines\n\n[Outro]\n2 lines",
  };
  return `You are a professional ${genre} songwriter. Write original ${mood.toLowerCase()} ${genre} song lyrics about: "${theme}".

Structure:
${structures[length] ?? structures.medium}

Rules:
- Section labels MUST be exactly: [Verse 1], [Chorus], [Bridge], [Outro] etc.
- Real rhymes, strong imagery, emotional resonance
- Every line 7-12 syllables — singable
- First line of response: TITLE: <your song title>
- Then blank line, then the lyrics
- NO explanations, NO chords, NO BPM, NO production notes`;
}

function parseLyrics(raw: string): { title: string; lyrics: string } {
  const t = raw.match(/^TITLE:\s*(.+)/im);
  return {
    title:  t ? t[1].trim() : "Untitled",
    lyrics: raw.replace(/^TITLE:\s*.+\n?/im, "").trim(),
  };
}

function formatLyricsForSinging(lyrics: string, genre: string, mood: string): string {
  const lines = lyrics.split("\n");
  const out: string[] = [];

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { out.push(""); continue; }

    if (/^\[.+\]$/.test(line)) {
      out.push("...");
      continue;
    }

    let phrase = line;
    if (!/[.!?,;]$/.test(phrase)) {
      phrase = out.length % 3 === 2 ? phrase + "." : phrase + ",";
    }
    out.push(phrase);
  }

  const text = out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  return text.slice(0, 3500);
}

function getSingingPayload(text: string, voice: string, genre: string, mood: string): object {
  const maleVoices = ["onyx", "echo", "fable", "alloy"];
  const isMale = maleVoices.includes(voice);

  const genderDesc = isMale
    ? "You are a professional male singer with a deep, rich, masculine voice."
    : "You are a professional female singer with a clear, expressive female voice.";

  const tempo = ["EDM","Rock","Afrobeats","Hip-Hop"].includes(genre) ? "upbeat and energetic" : "smooth and melodic";
  const emotion = mood === "Sad" ? "soulful and melancholic"
    : mood === "Romantic" ? "tender and romantic"
    : mood === "Angry" ? "intense and powerful"
    : mood === "Calm" ? "gentle and peaceful"
    : mood === "Spiritual" ? "reverent and uplifting"
    : "warm and expressive";

  const instructions =
    `${genderDesc} ` +
    `Sing these ${genre} lyrics in a ${tempo}, ${emotion} style. ` +
    `Use natural musical phrasing with pitch variation and rhythm — ` +
    `NOT just speaking. Every line must have a melodic rise and fall. ` +
    `Breathe between lines like a real singer would.`;

  return {
    model: "gpt-4o-mini-tts",
    input: text,
    voice,
    instructions,
    response_format: "mp3",
  };
}

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return json({ error: "Method Not Allowed" }, 405);

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return json({ error: "Server configuration error" }, 500);

  const esKey = Deno.env.get("EPIDEMIC_SOUND_API_KEY") ?? "";

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const sb = createClient(supabaseUrl, serviceKey);

  let body: { theme: string; genre?: string; mood?: string; length?: string; voice?: string; custom_notes?: string };
  try {
    body = await req.json();
    if (!body.theme?.trim()) throw new Error("theme is required");
  } catch (e) {
    return json({ error: (e as Error).message }, 400);
  }

  const { theme, genre = "Pop", mood = "Happy", length = "medium", voice = "onyx", custom_notes = "" } = body;
  const prompt = buildLyricsPrompt(theme + (custom_notes ? ` (${custom_notes})` : ""), genre, mood, length);

  // Run lyrics + music track fetch in parallel
  const [lyricsResult, epidemicResult] = await Promise.allSettled([
    /* ── Step 1: Generate Lyrics via Gemini ─────────────────── */
    (async (): Promise<{ title: string; lyrics: string }> => {
      const res = await fetch(GEMINI_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
      });
      const data = await res.json();
      const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
      if (!raw) throw new Error("Empty lyrics response");
      return parseLyrics(raw);
    })(),

    /* ── Step 2: Fetch real music track ──────────────────────── */
    // Try Epidemic Sound first (licensed); fall back to SoundHelix (guaranteed)
    tryEpidemicSound(genre, mood, esKey),
  ]);

  if (lyricsResult.status === "rejected") {
    return json({ error: "Lyrics generation failed: " + lyricsResult.reason?.message }, 500);
  }

  const { title, lyrics } = lyricsResult.value;

  // Epidemic Sound track if API worked, otherwise guaranteed SoundHelix track
  const esBonus: MusicTrack | null =
    epidemicResult.status === "fulfilled" ? epidemicResult.value : null;
  const beatTrack: MusicTrack = esBonus ?? pickSoundHelixTrack(genre, mood);
  console.log(`[music] using ${esBonus ? "Epidemic Sound" : "SoundHelix"}: "${beatTrack.title}" — ${beatTrack.previewUrl}`);

  /* ── Step 2: Generate Singing Vocals ──────────────────────── */
  let vocalUrl: string | null = null;
  const ttsText = formatLyricsForSinging(lyrics, genre, mood);

  try {
    const payload = getSingingPayload(ttsText, voice, genre, mood);
    let ttsRes = await fetch(TTS_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify(payload),
    });

    if (!ttsRes.ok) {
      const flatText = ttsText.replace(/\n/g, " ").replace(/\.{2,}/g, "...").slice(0, 3000);
      ttsRes = await fetch(TTS_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({
          model: "tts-1-hd",
          input: flatText,
          voice: ["onyx","echo","fable","alloy","nova","shimmer"].includes(voice) ? voice : "onyx",
          response_format: "mp3",
        }),
      });
    }
    if (ttsRes.ok) {
      const buf   = await ttsRes.arrayBuffer();
      const bytes = new Uint8Array(buf);
      if (bytes.length > 500) {
        const filePath = `songs/vocals-${crypto.randomUUID()}.mp3`;
        const { data: up, error: upErr } = await sb.storage
          .from("generated-media")
          .upload(filePath, bytes, { contentType: "audio/mpeg", cacheControl: "86400", upsert: false });
        if (!upErr && up) {
          const { data: urlData } = sb.storage.from("generated-media").getPublicUrl(filePath);
          vocalUrl = urlData.publicUrl;
        } else {
          const b64 = btoa(bytes.reduce((s, b) => s + String.fromCharCode(b), ""));
          vocalUrl = `data:audio/mpeg;base64,${b64}`;
        }
      }
    }
  } catch {
    // TTS failed — Epidemic Sound beat still plays
  }

  return json({
    success: true,
    title,
    lyrics,
    vocalUrl,
    genre,
    mood,
    beatUrl: beatTrack.previewUrl,
    epidemicTrack: {
      id:         beatTrack.id,
      title:      beatTrack.title,
      artist:     beatTrack.artist,
      previewUrl: beatTrack.previewUrl,
    },
  });
});
