// Kling Omni Video — Query Edge Function (polls status + saves to storage)
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function streamVideoToStorage(
  videoUrl: string,
  supabase: ReturnType<typeof createClient>,
): Promise<{ success: true; publicUrl: string } | { success: false; error: string }> {
  try {
    const response = await fetch(videoUrl);
    if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);
    const contentType = response.headers.get("content-type") ?? "video/mp4";
    const filePath = `uploads/${crypto.randomUUID()}.mp4`;
    const { error } = await supabase.storage
      .from("generated-media")
      .upload(filePath, response.body!, { contentType, cacheControl: "no-cache", upsert: false });
    if (error) throw error;
    const { data: urlData } = supabase.storage.from("generated-media").getPublicUrl(filePath);
    return { success: true, publicUrl: urlData.publicUrl };
  } catch (err) {
    console.warn("Storage transfer failed:", (err as Error).message);
    return { success: false, error: (err as Error).message };
  }
}

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: CORS });

  let taskId: string;
  try {
    const body = await req.json();
    taskId = body.task_id;
    if (!taskId) throw new Error("Missing task_id");
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const upstream = await fetch(
    `https://app-cgqteick6nep-api-pLVzAEz1ZQOL.gateway.appmedo.com/v1/videos/omni-video/${encodeURIComponent(taskId)}`,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
    }
  );

  if (upstream.status === 429 || upstream.status === 402) {
    const errText = await upstream.text();
    return new Response(errText, { status: upstream.status, headers: { ...CORS, "Content-Type": "application/json" } });
  }
  if (!upstream.ok) {
    return new Response(
      JSON.stringify({ error: `Upstream error: ${upstream.status}` }),
      { status: 502, headers: { ...CORS, "Content-Type": "application/json" } }
    );
  }

  const result = await upstream.json();
  if (result.code !== 0) {
    return new Response(
      JSON.stringify({ error: `API error ${result.code}: ${result.message}` }),
      { status: 500, headers: { ...CORS, "Content-Type": "application/json" } }
    );
  }

  const taskData = result.data;

  // On success, transfer video to Supabase Storage for a persistent URL
  if (taskData.task_status === "succeed" && taskData.task_result?.videos?.length > 0) {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    taskData.task_result.videos = await Promise.all(
      taskData.task_result.videos.map(async (video: { id: string; url: string; duration: string }) => {
        const transfer = await streamVideoToStorage(video.url, supabase);
        return { ...video, url: transfer.success ? transfer.publicUrl : video.url };
      })
    );
  }

  return new Response(JSON.stringify(result), {
    status: 200, headers: { ...CORS, "Content-Type": "application/json" },
  });
});
