import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// Simulated pipeline stage durations (ms)
const STAGE_DURATIONS: Record<string, number> = {
  build: 800,
  test: 600,
  security_scan: 400,
  deploy: 1000,
  health_check: 500,
};

function generateCommitHash(): string {
  const chars = "0123456789abcdef";
  return Array.from({ length: 7 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { project_id, audit_report_id, audit_score, findings_snapshot } = body as {
      project_id: string;
      audit_report_id: string;
      audit_score: number;
      findings_snapshot: Record<string, unknown>;
    };

    if (!project_id) {
      return new Response(JSON.stringify({ error: "project_id is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Deployment gate — block if audit_score <= 80
    if (!audit_score || audit_score <= 80) {
      return new Response(JSON.stringify({
        error: "DEPLOYMENT_BLOCKED",
        message: `Audit score ${audit_score ?? 0}/100 is below the deployment threshold of 80. Resolve critical findings and re-audit.`,
      }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const commitHash = generateCommitHash();
    const startTime = Date.now();

    // Create deployment record
    const { data: deployment, error: deployErr } = await supabase
      .from("guardian_deployments")
      .insert({
        project_id,
        user_id: user.id,
        audit_report_id: audit_report_id ?? null,
        audit_score,
        status: "running",
        commit_hash: commitHash,
        branch: "main",
        findings_snapshot: findings_snapshot ?? {},
      })
      .select()
      .maybeSingle();

    if (deployErr) throw deployErr;

    // Update project status to deploying
    await supabase.from("guardian_projects").update({ audit_status: "deploying" }).eq("id", project_id);

    // Simulate pipeline execution
    let totalDelay = 0;
    for (const [, duration] of Object.entries(STAGE_DURATIONS)) {
      await new Promise(r => setTimeout(r, duration));
      totalDelay += duration;
    }

    const durationMs = Date.now() - startTime;
    const simulatedDeployUrl = `https://medo-prod-${commitHash}.deployment.alphatekx.io`;

    // Simulate webhook payload to production environment
    const webhookPayload = {
      event: "deployment.completed",
      project_id,
      commit_hash: commitHash,
      branch: "main",
      audit_score,
      deployment_url: simulatedDeployUrl,
      timestamp: new Date().toISOString(),
    };

    // Mark deployment as success
    await supabase.from("guardian_deployments").update({
      status: "success",
      deployment_url: simulatedDeployUrl,
      webhook_payload: webhookPayload,
      webhook_response: { status: 200, message: "Webhook delivered to MeDo production environment" },
      duration_ms: durationMs,
      completed_at: new Date().toISOString(),
    }).eq("id", deployment?.id);

    // Update project as deployed
    await supabase.from("guardian_projects").update({
      audit_status: "deployed",
      deployment_url: simulatedDeployUrl,
    }).eq("id", project_id);

    return new Response(JSON.stringify({
      deployment_id: deployment?.id,
      status: "success",
      commit_hash: commitHash,
      deployment_url: simulatedDeployUrl,
      duration_ms: durationMs,
      webhook_delivered: true,
      stages: {
        build: "success",
        test: "success",
        security_scan: "success",
        deploy: "success",
        health_check: "success",
      },
    }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("guardian-deploy error:", err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
