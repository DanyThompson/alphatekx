/* ═══════════════════════════════════════════════════════════════
   AlphaTekx OS — ElevenLabs TTS Edge Function
   Uses ELEVENLABS_API_KEY secret, returns audio/mpeg blob
   POST body: { text: string, voice_id: string, model_id?: string }
═══════════════════════════════════════════════════════════════ */

const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const ELEVENLABS_BASE = "https://api.elevenlabs.io/v1/text-to-speech";

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

  // Parse request
  let text: string, voice_id: string, model_id: string;
  try {
    const body = await req.json();
    text     = (body.text ?? "").trim();
    voice_id = body.voice_id ?? "EXAVITQu4vr4xnSDxMaL"; // Sarah default
    model_id = body.model_id ?? "eleven_turbo_v2_5";      // fast + cheap
    if (!text) throw new Error("Missing text");
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid request body — need { text, voice_id }" }),
      { status: 400, headers: { ...CORS, "Content-Type": "application/json" } },
    );
  }

  const apiKey = Deno.env.get("ELEVENLABS_API_KEY");
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: "ELEVENLABS_API_KEY not configured" }),
      { status: 500, headers: { ...CORS, "Content-Type": "application/json" } },
    );
  }

  const upstream = await fetch(`${ELEVENLABS_BASE}/${voice_id}`, {
    method: "POST",
    headers: {
      "Content-Type":  "application/json",
      "xi-api-key":    apiKey,
      "Accept":        "audio/mpeg",
    },
    body: JSON.stringify({
      text,
      model_id,
      voice_settings: { stability: 0.5, similarity_boost: 0.75, style: 0.0 },
    }),
  });

  if (!upstream.ok) {
    const errText = await upstream.text();
    console.error(`ElevenLabs error ${upstream.status}:`, errText);
    return new Response(
      JSON.stringify({ error: `ElevenLabs API error ${upstream.status}`, detail: errText.slice(0, 300) }),
      { status: upstream.status, headers: { ...CORS, "Content-Type": "application/json" } },
    );
  }

  // Stream the audio bytes back to the client
  const audioBuffer = await upstream.arrayBuffer();

  return new Response(audioBuffer, {
    status: 200,
    headers: {
      ...CORS,
      "Content-Type":  "audio/mpeg",
      "Content-Length": String(audioBuffer.byteLength),
      "Cache-Control": "no-cache",
    },
  });
});
