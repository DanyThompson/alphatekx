// Unified Video Status Poller — routes to correct provider based on task_id prefix
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

/* ── Stream video to Supabase Storage ─────────────────────── */
async function streamVideoToStorage(
  videoUrl: string,
  supabase: ReturnType<typeof createClient>,
): Promise<{ success: true; publicUrl: string } | { success: false; error: string }> {
  try {
    const response = await fetch(videoUrl);
    if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);
    const contentType = response.headers.get("content-type") ?? "video/mp4";
    const filePath = `uploads/${crypto.randomUUID()}.mp4`;
    const { error } = await supabase.storage
      .from("generated-media")
      .upload(filePath, response.body!, { contentType, cacheControl: "no-cache", upsert: false });
    if (error) throw error;
    const { data: urlData } = supabase.storage.from("generated-media").getPublicUrl(filePath);
    return { success: true, publicUrl: urlData.publicUrl };
  } catch (err) {
    console.warn("Storage transfer failed:", (err as Error).message);
    return { success: false, error: (err as Error).message };
  }
}

/* ── Poll Kling ───────────────────────────────────────────── */
async function pollKling(
  apiKey: string,
  taskId: string,
  supabase: ReturnType<typeof createClient>,
): Promise<Record<string, unknown>> {
  const res = await fetch(
    `https://app-cgqteick6nep-api-pLVzAEz1ZQOL.gateway.appmedo.com/v1/videos/omni-video/${encodeURIComponent(taskId)}`,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
    }
  );
  if (!res.ok) throw new Error(`Kling query HTTP ${res.status}`);
  const result = await res.json();
  if (result.code !== 0) throw new Error(`Kling API error ${result.code}: ${result.message}`);

  const taskData = result.data;
  if (taskData.task_status === "succeed" && taskData.task_result?.videos?.length > 0) {
    taskData.task_result.videos = await Promise.all(
      taskData.task_result.videos.map(async (video: { url: string }) => {
        const transfer = await streamVideoToStorage(video.url, supabase);
        return { ...video, url: transfer.success ? transfer.publicUrl : video.url };
      })
    );
  }
  return {
    code: 0,
    data: {
      task_status: taskData.task_status,
      task_status_msg: taskData.task_status_msg || "",
      task_result: taskData.task_result || { videos: [] },
    },
  };
}

/* ── Poll Higgsfield ──────────────────────────────────────── */
async function pollHiggsfield(
  apiKey: string,
  _projectId: string,
  taskId: string,
  _supabase: ReturnType<typeof createClient>,
): Promise<Record<string, unknown>> {
  const attempts = [
    {
      url: `https://platform.higgsfield.ai/v1/generations/${encodeURIComponent(taskId)}`,
      headers: { "Authorization": `Bearer ${apiKey}` },
    },
    {
      url: `https://platform.higgsfield.ai/v1/generations/${encodeURIComponent(taskId)}`,
      headers: { "x-api-key": apiKey },
    },
  ];
  for (const attempt of attempts) {
    try {
      const res = await fetch(attempt.url, { method: "GET", headers: attempt.headers });
      if (!res.ok) continue;
      const data = await res.json();
      const status = data.status || data.state || data.task_status || "processing";
      const isDone = status === "completed" || status === "succeed" || status === "done";
      const videoUrl = data.video_url || data.url || data.output_url || "";
      return {
        code: 0,
        data: {
          task_status: isDone ? "succeed" : "processing",
          task_status_msg: data.message || "",
          task_result: videoUrl ? { videos: [{ url: videoUrl, id: taskId, duration: "5" }] } : { videos: [] },
        },
      };
    } catch { /* try next */ }
  }
  throw new Error("Higgsfield: all poll attempts failed");
}

/* ── Poll LTX Studio ──────────────────────────────────────── */
async function pollLtx(
  apiKey: string,
  taskId: string,
  _supabase: ReturnType<typeof createClient>,
): Promise<Record<string, unknown>> {
  const attempts = [
    {
      url: `https://api.ltx.studio/v1/generations/${encodeURIComponent(taskId)}`,
    },
    {
      url: `https://api.ltx.studio/v1/videos/${encodeURIComponent(taskId)}`,
    },
  ];
  for (const attempt of attempts) {
    try {
      const res = await fetch(attempt.url, {
        method: "GET",
        headers: { "Authorization": `Bearer ${apiKey}` },
      });
      if (!res.ok) continue;
      const text = await res.text();
      if (!text) continue;
      const data = JSON.parse(text);
      const status = data.status || data.state || "processing";
      const isDone = status === "completed" || status === "succeed" || status === "done" || status === "ready";
      const videoUrl = data.video_url || data.url || data.output?.video_url || "";
      return {
        code: 0,
        data: {
          task_status: isDone ? "succeed" : "processing",
          task_status_msg: data.message || "",
          task_result: videoUrl ? { videos: [{ url: videoUrl, id: taskId, duration: "5" }] } : { videos: [] },
        },
      };
    } catch { /* try next */ }
  }
  throw new Error("LTX: all poll attempts failed");
}

/* ═══════════════════════════════════════════════════════════════
   Main handler
   ═══════════════════════════════════════════════════════════════ */
Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: CORS });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const rawTaskId = String(body.task_id || "");
  if (!rawTaskId) {
    return new Response(JSON.stringify({ error: "Missing task_id" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server config: INTEGRATIONS_API_KEY missing" }), {
      status: 500, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  /* ── Route to provider based on prefix ─────────────────── */
  let result: Record<string, unknown>;
  try {
    if (rawTaskId.startsWith("higgsfield:")) {
      const taskId = rawTaskId.replace("higgsfield:", "");
      const hfKey = Deno.env.get("HIGGSFIELD_API_KEY")!;
      const hfId  = Deno.env.get("HIGGSFIELD_PROJECT_ID")!;
      result = await pollHiggsfield(hfKey, hfId, taskId, supabase);
    } else if (rawTaskId.startsWith("ltx:")) {
      const taskId = rawTaskId.replace("ltx:", "");
      const ltxKey = Deno.env.get("LTX_STUDIO_API_KEY")!;
      result = await pollLtx(ltxKey, taskId, supabase);
    } else {
      // Default: Kling (no prefix or raw task_id)
      result = await pollKling(apiKey, rawTaskId, supabase);
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: msg }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify(result), {
    status: 200, headers: { ...CORS, "Content-Type": "application/json" },
  });
});
