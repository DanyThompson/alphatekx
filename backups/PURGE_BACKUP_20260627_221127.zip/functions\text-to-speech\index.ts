// AlphaTekx OS — Text-to-Speech Edge Function v2
// Uses LemonFox TTS via platform gateway.
// Strategy: buffer full audio bytes first, then upload as Uint8Array (avoids duplex/stream issues).
// Fallback: if Storage upload fails, return base64 data-URL so the frontend always gets audio.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  // ── Parse request ────────────────────────────────────────────────
  let input: string, voice: string, responseFormat: string;
  try {
    const body = await req.json();
    input          = (body.input  ?? "").trim();
    voice          = (body.voice  ?? "heart").trim();
    responseFormat = (body.response_format ?? "mp3").trim();
    if (!input) throw new Error("input is required");
  } catch (e) {
    return json({ error: (e as Error).message || "Invalid request body" }, 400);
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return json({ error: "Server configuration error: missing API key" }, 500);

  // ── Call upstream TTS ────────────────────────────────────────────
  let upstream: Response;
  try {
    upstream = await fetch(
      "https://app-cgqteick6nep-api-GYX1lzGw01Xa.gateway.appmedo.com/v1/audio/speech",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Gateway-Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ input, voice, response_format: responseFormat }),
      }
    );
  } catch (e) {
    return json({ error: `TTS network error: ${(e as Error).message}` }, 502);
  }

  // Credit / rate-limit pass-through
  if (upstream.status === 429 || upstream.status === 402) {
    const t = await upstream.text().catch(() => "");
    let parsed: unknown;
    try { parsed = JSON.parse(t); } catch { parsed = { error: t || `HTTP ${upstream.status}` }; }
    return json(parsed, upstream.status);
  }

  if (!upstream.ok) {
    const detail = await upstream.text().catch(() => "");
    console.error(`[tts] upstream error ${upstream.status}:`, detail);
    return json({ error: `TTS service error ${upstream.status}`, detail }, 502);
  }

  // ── Buffer audio bytes (safe — no stream piping) ─────────────────
  let audioBytes: Uint8Array;
  try {
    const buf = await upstream.arrayBuffer();
    audioBytes = new Uint8Array(buf);
    if (audioBytes.length === 0) throw new Error("Empty audio response from TTS");
  } catch (e) {
    console.error("[tts] failed to buffer audio:", e);
    return json({ error: `Failed to read audio: ${(e as Error).message}` }, 502);
  }

  console.log(`[tts] buffered ${audioBytes.length} bytes, voice=${voice}, fmt=${responseFormat}`);

  // ── Try Supabase Storage upload ──────────────────────────────────
  const supabaseUrl  = Deno.env.get("SUPABASE_URL");
  const serviceRole  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (supabaseUrl && serviceRole) {
    try {
      const supabase  = createClient(supabaseUrl, serviceRole);
      const filePath  = `tts/${crypto.randomUUID()}.${responseFormat}`;
      const mimeType  = responseFormat === "wav" ? "audio/wav"
                       : responseFormat === "ogg" ? "audio/ogg"
                       : "audio/mpeg";

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("generated-media")
        .upload(filePath, audioBytes, {
          contentType: mimeType,
          cacheControl: "86400",
          upsert: false,
        });

      if (!uploadError && uploadData) {
        const { data: urlData } = supabase.storage
          .from("generated-media")
          .getPublicUrl(filePath);
        console.log("[tts] storage upload OK:", urlData.publicUrl);
        return json({ audioUrl: urlData.publicUrl, path: uploadData.path });
      }

      console.warn("[tts] storage upload failed, falling back to base64:", uploadError?.message);
    } catch (storageErr) {
      console.warn("[tts] storage exception, falling back to base64:", (storageErr as Error).message);
    }
  }

  // ── Fallback: return base64 data-URL (always works, no storage needed) ──
  const mimeType = responseFormat === "wav" ? "audio/wav"
                 : responseFormat === "ogg" ? "audio/ogg"
                 : "audio/mpeg";
  // Use chunked approach — spreading large Uint8Array into String.fromCharCode
  // exhausts the JS call-stack for audio > ~64KB (crashes with "Too many arguments")
  let b64 = "";
  const BTOA_CHUNK = 0x8000; // 32 KB slices — safe for all JS engines
  for (let i = 0; i < audioBytes.length; i += BTOA_CHUNK) {
    b64 += String.fromCharCode(...audioBytes.subarray(i, i + BTOA_CHUNK));
  }
  const dataUrl = `data:${mimeType};base64,${btoa(b64)}`;
  console.log(`[tts] returning base64 data-URL fallback (${audioBytes.length} bytes)`);
  return json({ audioUrl: dataUrl, path: null });
});
