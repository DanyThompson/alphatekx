// Unified Video Generator — Kling → Higgsfield → LTX Studio fallback chain
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

/* ═══════════════════════════════════════════════════════════════
   Provider 1 — Kling Omni (platform gateway)
   ═══════════════════════════════════════════════════════════════ */
async function submitKling(
  apiKey: string,
  prompt: string,
): Promise<{ success: true; task_id: string } | { success: false; error: string }> {
  try {
    const res = await fetch(
      "https://app-cgqteick6nep-api-k93RvqRrRZba.gateway.appmedo.com/v1/videos/omni-video",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Gateway-Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ prompt, duration: "5", aspect_ratio: "16:9", mode: "pro" }),
      }
    );
    if (!res.ok) return { success: false, error: `Kling HTTP ${res.status}` };
    const data = await res.json();
    if (data.code !== 0) return { success: false, error: `Kling API error: ${data.message}` };
    return { success: true, task_id: data.data.task_id };
  } catch (e) {
    return { success: false, error: `Kling exception: ${(e as Error).message}` };
  }
}

/* ═══════════════════════════════════════════════════════════════
   Provider 2 — Higgsfield AI
   ═══════════════════════════════════════════════════════════════ */
async function submitHiggsfield(
  apiKey: string,
  projectId: string,
  prompt: string,
): Promise<{ success: true; task_id: string } | { success: false; error: string }> {
  // Try multiple auth formats / endpoints
  const attempts = [
    {
      url: "https://platform.higgsfield.ai/v1/generations",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: { prompt, project_id: projectId },
    },
    {
      url: "https://platform.higgsfield.ai/v1/generations",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "x-project-id": projectId,
      },
      body: { prompt },
    },
    {
      url: "https://platform.higgsfield.ai/api/v1/generations",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: { prompt, project_id: projectId },
    },
  ];

  for (const attempt of attempts) {
    try {
      const res = await fetch(attempt.url, {
        method: "POST",
        headers: attempt.headers,
        body: JSON.stringify(attempt.body),
      });
      if (!res.ok) continue;
      const data = await res.json();
      if (data.id || data.task_id || data.job_id) {
        const taskId = data.id || data.task_id || data.job_id;
        return { success: true, task_id: `higgsfield:${taskId}` };
      }
    } catch { /* try next auth format */ }
  }
  return { success: false, error: "Higgsfield: all auth formats failed" };
}

/* ═══════════════════════════════════════════════════════════════
   Provider 3 — LTX Studio
   ═══════════════════════════════════════════════════════════════ */
async function submitLtx(
  apiKey: string,
  prompt: string,
): Promise<{ success: true; task_id: string } | { success: false; error: string }> {
  const attempts = [
    {
      url: "https://api.ltx.studio/v1/generations",
      body: { prompt, duration: 5, aspect_ratio: "16:9" },
    },
    {
      url: "https://api.ltx.studio/v1/videos",
      body: { prompt, duration: 5 },
    },
    {
      url: "https://api.ltx.studio/v1/create",
      body: { text: prompt, duration: 5 },
    },
  ];

  for (const attempt of attempts) {
    try {
      const res = await fetch(attempt.url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify(attempt.body),
      });
      if (!res.ok) continue;
      const text = await res.text();
      if (!text) continue;
      const data = JSON.parse(text);
      if (data.id || data.task_id || data.job_id || data.generation_id) {
        const taskId = data.id || data.task_id || data.job_id || data.generation_id;
        return { success: true, task_id: `ltx:${taskId}` };
      }
    } catch { /* try next endpoint */ }
  }
  return { success: false, error: "LTX Studio: all endpoints failed" };
}

/* ═══════════════════════════════════════════════════════════════
   Main handler — tries Kling → Higgsfield → LTX
   ═══════════════════════════════════════════════════════════════ */
Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: CORS });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const prompt = String(body.prompt || "");
  if (!prompt) {
    return new Response(JSON.stringify({ error: "Missing prompt" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server config: INTEGRATIONS_API_KEY missing" }), {
      status: 500, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  /* ── 1. Kling (primary) ──────────────────────────────────── */
  const kling = await submitKling(apiKey, prompt);
  if (kling.success) {
    return new Response(JSON.stringify({
      provider: "kling",
      task_id: kling.task_id,
      status: "submitted",
    }), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
  }
  console.warn("Kling failed:", kling.error);

  /* ── 2. Higgsfield (fallback 1) ────────────────────────── */
  const hfKey = Deno.env.get("HIGGSFIELD_API_KEY");
  const hfId  = Deno.env.get("HIGGSFIELD_PROJECT_ID");
  if (hfKey && hfId) {
    const hf = await submitHiggsfield(hfKey, hfId, prompt);
    if (hf.success) {
      return new Response(JSON.stringify({
        provider: "higgsfield",
        task_id: hf.task_id,
        status: "submitted",
      }), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
    }
    console.warn("Higgsfield failed:", hf.error);
  }

  /* ── 3. LTX Studio (fallback 2) ────────────────────────── */
  const ltxKey = Deno.env.get("LTX_STUDIO_API_KEY");
  if (ltxKey) {
    const ltx = await submitLtx(ltxKey, prompt);
    if (ltx.success) {
      return new Response(JSON.stringify({
        provider: "ltx",
        task_id: ltx.task_id,
        status: "submitted",
      }), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
    }
    console.warn("LTX failed:", ltx.error);
  }

  /* ── All failed ──────────────────────────────────────────── */
  return new Response(JSON.stringify({
    error: "All video generation providers failed. Kling: " + kling.error,
  }), { status: 503, headers: { ...CORS, "Content-Type": "application/json" } });
});
