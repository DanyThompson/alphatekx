// Deployment Guardian test
const SECRET = 'process.env.ALPHATekX_OPENAI_API_KEY';
console.log(SECRET);
