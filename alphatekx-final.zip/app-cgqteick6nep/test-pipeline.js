import fs from 'fs/promises';
import path from 'path';
import { runDeploymentPipeline } from './core/pipeline/pipeline.js';

const ROOT = process.cwd();
const PROJECT_PATH = path.join(ROOT, 'pipeline-test-project');
const SECRET_FILE = path.join(PROJECT_PATH, 'index.js');

async function setupProject() {
  await fs.mkdir(PROJECT_PATH, { recursive: true });
  const content = `// Deployment Guardian test\nconst SECRET = 'sk_test_deployment_secret_1234567890abcdef';\nconsole.log(SECRET);\n`;
  await fs.writeFile(SECRET_FILE, content, 'utf8');
  console.log('[test] Created pipeline test project at', PROJECT_PATH);
}

async function run() {
  await setupProject();

  console.log('[test] Running deployment pipeline first time (should block and remediate)…');
  const firstResult = await runDeploymentPipeline(PROJECT_PATH, { logger: console });
  console.log('[test] First pipeline result:', JSON.stringify(firstResult, null, 2));

  if (firstResult.finalSecurityStatus !== 'AUTHORIZED') {
    console.log('[test] First pass blocked deployment as expected and attempted remediation.');
  }

  console.log('[test] Running deployment pipeline second time (should allow deploy)…');
  const secondResult = await runDeploymentPipeline(PROJECT_PATH, { logger: console });
  console.log('[test] Second pipeline result:', JSON.stringify(secondResult, null, 2));

  if (secondResult.finalSecurityStatus === 'AUTHORIZED') {
    console.log('[test] SUCCESS: Deployment Guardian allowed the deploy after cleanup.');
  } else {
    console.error('[test] FAILURE: Deployment still denied after remediation.');
    process.exit(1);
  }
}

run().catch((error) => {
  console.error('[test] FAILURE:', error);
  process.exit(1);
});
