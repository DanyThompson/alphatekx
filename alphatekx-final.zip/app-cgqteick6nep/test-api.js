import fs from 'fs/promises';
import path from 'path';

const ROOT = process.cwd();
const API_BASE = process.env.API_BASE || 'http://localhost:4000';
const API_KEY = process.env.API_KEY || 'alpha-tekx-enterprise-key';
const PROJECT_PATH = path.join(ROOT, 'api-test-project');
const SECRET_FILE = path.join(PROJECT_PATH, 'index.js');

async function setupProject() {
  await fs.mkdir(PROJECT_PATH, { recursive: true });
  const content = `// API wrapper deployment test\nconst secret = 'sk_test_api_wrapper_1234567890abcdef';\nconsole.log(secret);\n`;
  await fs.writeFile(SECRET_FILE, content, 'utf8');
  console.log('[test-api] Created project at', PROJECT_PATH);
}

async function run() {
  await setupProject();

  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${API_KEY}`,
  };

  const deployResponse = await fetch(`${API_BASE}/api/deploy`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ projectPath: PROJECT_PATH }),
  });
  const deployResult = await deployResponse.json();
  console.log('[test-api] /api/deploy response:', JSON.stringify(deployResult, null, 2));

  const reportResponse = await fetch(`${API_BASE}/api/report`, { headers });
  const reportResult = await reportResponse.json();
  console.log('[test-api] /api/report response:', JSON.stringify(reportResult, null, 2));

  if (deployResult.transactionID) {
    const statusResponse = await fetch(`${API_BASE}/api/status/${deployResult.transactionID}`, { headers });
    const statusResult = await statusResponse.json();
    console.log('[test-api] /api/status response:', JSON.stringify(statusResult, null, 2));
  }
}

run().catch((error) => {
  console.error('[test-api] FAILURE:', error);
  process.exit(1);
});
