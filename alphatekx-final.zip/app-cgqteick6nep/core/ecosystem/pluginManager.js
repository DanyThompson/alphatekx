import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const PLUGIN_DIR = fileURLToPath(new URL('./plugins', import.meta.url));

export async function loadPlugins(logger = console) {
  const plugins = [];
  try {
    const files = await fs.readdir(PLUGIN_DIR);
    for (const file of files) {
      if (!file.endsWith('.js')) continue;
      const fullPath = path.join(PLUGIN_DIR, file);
      try {
        const module = await import(pathToFileURL(fullPath).href);
        if (typeof module.default === 'function') {
          const metadata = module.metadata || {
            description: 'No plugin metadata provided.',
            supportedHooks: [],
          };
          plugins.push({
            name: path.basename(file, '.js'),
            file,
            execute: module.default,
            metadata,
          });
          logger.info(`[ecosystem] Loaded plugin: ${file}`);
        } else {
          logger.warn(`[ecosystem] Skipping plugin ${file}: default export is not a function.`);
        }
      } catch (error) {
        logger.error(`[ecosystem] Failed loading plugin ${file}: ${error.message}`);
      }
    }
  } catch (error) {
    if (error.code !== 'ENOENT') {
      logger.error(`[ecosystem] Plugin directory load failed: ${error.message}`);
    }
  }

  return plugins;
}

export async function executePluginHooks(hooks, context, logger = console) {
  const results = [];
  const plugins = await loadPlugins(logger);

  for (const plugin of plugins) {
    try {
      const hookResult = await plugin.execute(hooks, context);
      results.push({ plugin: plugin.name, status: 'ok', metadata: plugin.metadata, result: hookResult });
    } catch (error) {
      logger.error(`[ecosystem] Plugin ${plugin.name} hook failed: ${error.message}`);
      results.push({ plugin: plugin.name, status: 'error', metadata: plugin.metadata, error: error.message });
    }
  }

  return results;
}
