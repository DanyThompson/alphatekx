# AlphaTekx Ecosystem

This module is the foundation for a plugin-driven AlphaTekx ecosystem.

## Design goals

- support third-party hooks and extensions
- execute deployment lifecycle plugins without changing core pipeline code
- support new developer experiences, audit integrations, and security extensions

## Structure

- `pluginManager.js` loads JavaScript plugins from `core/ecosystem/plugins`
- `executePluginHooks()` calls each plugin with a hook event and shared context

## Plugin contract

Each plugin should export a default async function:

```js
export default async function plugin(hooks, context) {
  if (hooks.event === 'deployment.completed') {
    return { ... };
  }
  return { message: 'none' };
}
```

## Available hooks

- `deployment.completed`
- `deployment.failed`
- `deployment.started`
- `deployment.preflight`

## Example

```js
import { executePluginHooks } from '../core/ecosystem/pluginManager.js';

await executePluginHooks({ event: 'deployment.completed' }, { transactionID, deploymentDomain });
```
