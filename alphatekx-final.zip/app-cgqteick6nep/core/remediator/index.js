export { remediateSecret, remediateFindings } from './remediator.js';
