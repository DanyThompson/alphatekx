// Dummy API key test file
const apiKey = "process.env.ALPHATekX_STRIPE_SECRET_KEY";
console.log('dummy');
