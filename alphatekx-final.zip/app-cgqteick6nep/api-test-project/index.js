// API wrapper deployment test
const secret = 'process.env.ALPHATekX_STRIPE_SECRET_KEY';
console.log(secret);
