import fs from 'fs/promises';
import path from 'path';
import { scanFile } from './core/scanner/scanner.js';
import { remediateSecret } from './core/remediator/remediator.js';

const ROOT = process.cwd();
const DUMMY_PATH = path.join(ROOT, 'dummy-remediation.js');
const DUMMY_CONTENT = `// Dummy API key test file\nconst apiKey = "sk_test_1234567890abcdef1234567890";\nconsole.log('dummy');\n`;

async function run() {
  await fs.writeFile(DUMMY_PATH, DUMMY_CONTENT, 'utf8');
  console.log('[test] Created dummy file:', DUMMY_PATH);

  const findingsBefore = await scanFile(DUMMY_PATH);
  console.log('[test] Scanner findings before remediation:', JSON.stringify(findingsBefore, null, 2));

  if (!findingsBefore.length) {
    console.error('[test] ERROR: No findings detected in dummy file.');
    process.exit(1);
  }

  const result = await remediateSecret(findingsBefore[0], { logger: console });
  console.log('[test] Remediation result:', JSON.stringify(result, null, 2));

  const findingsAfter = await scanFile(DUMMY_PATH);
  console.log('[test] Scanner findings after remediation:', JSON.stringify(findingsAfter, null, 2));

  if (findingsAfter.length) {
    console.error('[test] ERROR: Secret still detected after remediation.');
    process.exit(1);
  }

  const envExample = await fs.readFile(path.join(ROOT, '.env.example'), 'utf8');
  console.log('[test] .env.example content:');
  console.log(envExample);

  console.log('[test] SUCCESS: Secret remediated and confirmed clean.');
}

run().catch((error) => {
  console.error('[test] FAILURE:', error);
  process.exit(1);
});
