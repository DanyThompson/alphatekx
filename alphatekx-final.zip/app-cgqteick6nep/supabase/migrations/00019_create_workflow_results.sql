
create table if not exists public.workflow_results (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid references auth.users(id) on delete cascade,
  title         text not null default '',
  content       text not null default '',
  audio_url     text,
  video_task_id text,
  style         text not null default 'Cinematic',
  voice         text not null default 'heart',
  created_at    timestamptz not null default now()
);

alter table public.workflow_results enable row level security;

create policy "Users see own workflow results"
  on public.workflow_results for select
  using (auth.uid() = user_id);

create policy "Users insert own workflow results"
  on public.workflow_results for insert
  with check (auth.uid() = user_id or user_id is null);

create policy "Users delete own workflow results"
  on public.workflow_results for delete
  using (auth.uid() = user_id);
