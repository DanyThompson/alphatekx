
-- ══════════════════════════════════════════════════════════════
-- AUDIT_LOGS TABLE (auto-fix engine log)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE audit_logs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  project_id    uuid REFERENCES guardian_projects(id) ON DELETE SET NULL,
  file_path     text NOT NULL,
  line_number   integer NOT NULL,
  old_content   text NOT NULL,
  new_content   text NOT NULL,
  diff          text NOT NULL,
  status        text NOT NULL DEFAULT 'success' CHECK (status IN ('success', 'failed')),
  error_message text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_logs_user      ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_project   ON audit_logs(project_id);
CREATE INDEX idx_audit_logs_created   ON audit_logs(created_at DESC);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "al_select_own" ON audit_logs FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "al_insert_own" ON audit_logs FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "al_update_own" ON audit_logs FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "al_delete_own" ON audit_logs FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "al_anon_none"  ON audit_logs FOR SELECT TO anon USING (false);
