
-- Add credit system fields to profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS phone_number  text,
  ADD COLUMN IF NOT EXISTS credit_balance integer NOT NULL DEFAULT 30,
  ADD COLUMN IF NOT EXISTS device_id     text;

-- Phone number must be unique when set
CREATE UNIQUE INDEX IF NOT EXISTS profiles_phone_number_unique
  ON public.profiles (phone_number)
  WHERE phone_number IS NOT NULL;

-- Device ID must be unique when set (anti-cheat)
CREATE UNIQUE INDEX IF NOT EXISTS profiles_device_id_unique
  ON public.profiles (device_id)
  WHERE device_id IS NOT NULL;

-- Helper function: check if a device_id has already claimed free credits
CREATE OR REPLACE FUNCTION public.device_has_claimed_credits(p_device_id text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles WHERE device_id = p_device_id
  );
END;
$$;

-- RPC: register or login a user by phone + name with anti-cheat
CREATE OR REPLACE FUNCTION public.upsert_phone_user(
  p_phone    text,
  p_name     text,
  p_device_id text
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_profile   public.profiles%ROWTYPE;
  v_credits   integer;
  v_message   text;
  v_is_new    boolean := false;
  v_cheat     boolean := false;
BEGIN
  -- Check if phone already registered
  SELECT * INTO v_profile FROM public.profiles WHERE phone_number = p_phone LIMIT 1;

  IF FOUND THEN
    -- Existing user: just return their data (login)
    RETURN json_build_object(
      'id',             v_profile.id,
      'full_name',      v_profile.full_name,
      'phone_number',   v_profile.phone_number,
      'credit_balance', v_profile.credit_balance,
      'is_new',         false,
      'message',        'Welcome back, ' || COALESCE(v_profile.full_name, 'User') || '!'
    );
  ELSE
    -- New user registration
    v_is_new := true;

    -- Anti-cheat: check if device already claimed
    IF public.device_has_claimed_credits(p_device_id) THEN
      v_credits := 0;
      v_cheat   := true;
      v_message := 'Trial already claimed on this device.';
    ELSE
      v_credits := 30;
      v_message := 'Welcome! You have been awarded 30 free credits.';
    END IF;

    INSERT INTO public.profiles (
      id, full_name, phone_number, credit_balance, device_id, role
    ) VALUES (
      gen_random_uuid(), p_name, p_phone, v_credits,
      CASE WHEN v_cheat THEN NULL ELSE p_device_id END,
      'user'
    )
    RETURNING * INTO v_profile;

    RETURN json_build_object(
      'id',             v_profile.id,
      'full_name',      v_profile.full_name,
      'phone_number',   v_profile.phone_number,
      'credit_balance', v_profile.credit_balance,
      'is_new',         true,
      'cheat_detected', v_cheat,
      'message',        v_message
    );
  END IF;
END;
$$;

-- RPC: deduct credits atomically (returns new balance or -1 if insufficient)
CREATE OR REPLACE FUNCTION public.deduct_credits(
  p_profile_id uuid,
  p_amount     integer
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_new_balance integer;
BEGIN
  UPDATE public.profiles
  SET credit_balance = credit_balance - p_amount
  WHERE id = p_profile_id AND credit_balance >= p_amount
  RETURNING credit_balance INTO v_new_balance;

  IF NOT FOUND THEN
    RETURN -1; -- insufficient credits
  END IF;

  RETURN v_new_balance;
END;
$$;

-- RPC: add credits after payment
CREATE OR REPLACE FUNCTION public.add_credits(
  p_profile_id uuid,
  p_amount     integer
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_new_balance integer;
BEGIN
  UPDATE public.profiles
  SET credit_balance = credit_balance + p_amount
  WHERE id = p_profile_id
  RETURNING credit_balance INTO v_new_balance;

  RETURN v_new_balance;
END;
$$;
