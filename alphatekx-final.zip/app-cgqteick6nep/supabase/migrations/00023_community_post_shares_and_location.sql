
-- Add location column to community_posts if not present
ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS location text;

-- increment_post_shares RPC (idempotent)
CREATE OR REPLACE FUNCTION increment_post_shares(p_post_id bigint)
RETURNS void LANGUAGE sql AS $$
  UPDATE community_posts SET share_count = COALESCE(share_count, 0) + 1 WHERE id = p_post_id;
$$;
