
-- Enable pg_trgm first, then create table + index
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS community_users (
  id         uuid PRIMARY KEY,
  name       text NOT NULL,
  init       text NOT NULL DEFAULT '?',
  color      text NOT NULL DEFAULT '#7c3aed',
  last_seen  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE community_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "community_users_select" ON community_users FOR SELECT USING (true);
CREATE POLICY "community_users_insert" ON community_users FOR INSERT WITH CHECK (true);
CREATE POLICY "community_users_update" ON community_users FOR UPDATE USING (true);

CREATE INDEX IF NOT EXISTS idx_community_users_name ON community_users USING gin(name gin_trgm_ops);
