
-- Team HQ messages
create table if not exists public.team_messages (
  id          bigserial primary key,
  created_at  timestamptz default now() not null,
  sender_name text        not null,
  content     text        not null,
  msg_type    text        default 'text' not null  -- 'text' | 'system'
);

alter table public.team_messages enable row level security;

-- Anyone authenticated (or anon with HQ key) can read + insert
create policy "hq_read"   on public.team_messages for select using (true);
create policy "hq_insert" on public.team_messages for insert with check (true);

-- Enable realtime
alter publication supabase_realtime add table public.team_messages;
