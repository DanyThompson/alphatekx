-- Drop the integer overload — numeric handles all cases (integers and decimals)
DROP FUNCTION IF EXISTS public.deduct_credits(uuid, integer);

-- Ensure the numeric overload exists with correct atomic logic
CREATE OR REPLACE FUNCTION public.deduct_credits(p_profile_id uuid, p_amount numeric)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_balance numeric;
BEGIN
  UPDATE public.profiles
    SET credit_balance = credit_balance - p_amount
    WHERE id = p_profile_id AND credit_balance >= p_amount
    RETURNING credit_balance INTO v_balance;
  IF NOT FOUND THEN RETURN -1; END IF;
  RETURN v_balance;
END;
$$;