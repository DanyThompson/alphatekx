
-- ── apps: the core registry for subdomain-routed deployed apps ────────────
CREATE TABLE deployed_apps (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id   uuid        NOT NULL,
  slug         text        NOT NULL UNIQUE,
  title        text        NOT NULL DEFAULT 'My App',
  description  text,
  html_code    text        NOT NULL DEFAULT '',
  tech_stack   text        NOT NULL DEFAULT 'HTML/CSS/JS',
  is_live      boolean     NOT NULL DEFAULT true,
  views        bigint      NOT NULL DEFAULT 0,
  project_id   uuid        REFERENCES projects(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- slug must be lowercase alphanumeric + hyphens only
ALTER TABLE deployed_apps
  ADD CONSTRAINT slug_format CHECK (slug ~ '^[a-z0-9][a-z0-9\-]{0,61}[a-z0-9]$');

ALTER TABLE deployed_apps ENABLE ROW LEVEL SECURITY;

-- Public can read live apps (needed for subdomain routing)
CREATE POLICY "public_read_live_apps"
  ON deployed_apps FOR SELECT
  USING (is_live = true);

-- Authenticated users full access to own apps
CREATE POLICY "owner_all"
  ON deployed_apps FOR ALL
  USING (true) WITH CHECK (true);

-- Index for fast slug lookup (hot path for every subdomain visit)
CREATE INDEX idx_deployed_apps_slug ON deployed_apps(slug);

-- Auto-increment views via RPC
CREATE OR REPLACE FUNCTION increment_app_views(p_slug text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE deployed_apps SET views = views + 1 WHERE slug = p_slug;
END;
$$;

-- Trigger: auto-update updated_at
CREATE TRIGGER deployed_apps_updated_at
  BEFORE UPDATE ON deployed_apps
  FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
