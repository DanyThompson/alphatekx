
create table if not exists public.community_posts (
  id          bigserial primary key,
  created_at  timestamptz default now() not null,
  author_name text        not null,
  author_init text        not null default 'AN',
  author_color text       not null default '#6d28d9',
  title       text        not null,
  content     text        not null,
  category    text        not null default 'General',
  youtube_url text,
  likes       integer     not null default 0
);

create table if not exists public.post_likes (
  id          bigserial primary key,
  post_id     bigint references public.community_posts(id) on delete cascade,
  session_id  text not null,
  unique(post_id, session_id)
);

alter table public.community_posts enable row level security;
alter table public.post_likes       enable row level security;

create policy "posts_read"   on public.community_posts for select using (true);
create policy "posts_insert" on public.community_posts for insert with check (true);
create policy "likes_read"   on public.post_likes for select using (true);
create policy "likes_insert" on public.post_likes for insert with check (true);
create policy "likes_delete" on public.post_likes for delete using (true);

-- seed some starter posts
insert into public.community_posts (author_name, author_init, author_color, title, content, category, youtube_url, likes)
values
  ('Thompson Daniel','TD','#6d28d9','Welcome to the AlphaTekx Community 🚀','This is your space to share, grow, and connect. Post what you''re building, studying, or creating. Let''s build the future together!','Announcement',null,47),
  ('Aisha Bello','AB','#1d4ed8','How I used AI to pass my WAEC with flying colours','I want to share exactly how I used AlphaTekx School Library + AI Tutor for 3 months and nailed every subject. DM me for my full study plan!','Tutorial',null,31),
  ('Chidi Okonkwo','CO','#0d9488','My coding journey — from zero to full-stack in 8 months','Started knowing nothing about code. Used AlphaTekx Live Editor + AI Chat every single day. Watch my full story.','Showcase','https://youtube.com',28),
  ('Funmi Adeyemi','FA','#be185d','5 YouTube channels every student must follow for free education','Here are my top 5 channels for learning maths, science, and tech for free. Great complement to AlphaTekx!','Tips','https://youtube.com/results?search_query=free+education',19),
  ('Ngozi Eze','NE','#b45309','Voice chat with AI changed how I study','I never liked reading long texts. But speaking to AlphaTekx AI and hearing it reply back made everything click. Try the voice mode!','Tips',null,15)
  on conflict do nothing;
