
-- 1. Decimal credits
ALTER TABLE public.profiles ALTER COLUMN credit_balance TYPE numeric(12,2) USING credit_balance::numeric;

-- 2. Presence table
CREATE TABLE public.user_presence (
  profile_id  uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  last_seen   timestamptz NOT NULL DEFAULT now(),
  page        text DEFAULT 'chat'
);
ALTER TABLE public.user_presence ENABLE ROW LEVEL SECURITY;
CREATE POLICY "presence_select_all" ON public.user_presence FOR SELECT USING (true);
CREATE POLICY "presence_upsert_own" ON public.user_presence FOR INSERT WITH CHECK (auth.uid() = profile_id);
CREATE POLICY "presence_update_own" ON public.user_presence FOR UPDATE USING (auth.uid() = profile_id);
CREATE POLICY "presence_delete_own" ON public.user_presence FOR DELETE USING (auth.uid() = profile_id);

-- 3. deduct_chat_credit RPC
CREATE OR REPLACE FUNCTION public.deduct_chat_credit(p_profile_id uuid)
RETURNS numeric
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_balance numeric;
BEGIN
  SELECT credit_balance INTO v_balance FROM public.profiles WHERE id = p_profile_id;
  IF v_balance IS NULL OR v_balance < 0.09 THEN RETURN -1; END IF;
  UPDATE public.profiles SET credit_balance = credit_balance - 0.09 WHERE id = p_profile_id
  RETURNING credit_balance INTO v_balance;
  RETURN v_balance;
END; $$;

-- 4. Update deduct_credits to numeric
CREATE OR REPLACE FUNCTION public.deduct_credits(p_profile_id uuid, p_amount numeric)
RETURNS numeric
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_balance numeric;
BEGIN
  SELECT credit_balance INTO v_balance FROM public.profiles WHERE id = p_profile_id;
  IF v_balance IS NULL OR v_balance < p_amount THEN RETURN -1; END IF;
  UPDATE public.profiles SET credit_balance = credit_balance - p_amount WHERE id = p_profile_id
  RETURNING credit_balance INTO v_balance;
  RETURN v_balance;
END; $$;

-- 5. Admin stats RPC
CREATE OR REPLACE FUNCTION public.get_admin_stats()
RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_total_users     bigint; v_new_today bigint; v_new_week bigint;
  v_online_now      bigint; v_total_messages bigint;
BEGIN
  SELECT COUNT(*) INTO v_total_users FROM public.profiles;
  SELECT COUNT(*) INTO v_new_today   FROM public.profiles WHERE created_at >= now() - interval '24 hours';
  SELECT COUNT(*) INTO v_new_week    FROM public.profiles WHERE created_at >= now() - interval '7 days';
  SELECT COUNT(*) INTO v_online_now  FROM public.user_presence WHERE last_seen >= now() - interval '3 minutes';
  SELECT COUNT(*) INTO v_total_messages FROM public.chat_messages;
  RETURN json_build_object(
    'total_users', v_total_users, 'new_today', v_new_today,
    'new_this_week', v_new_week, 'online_now', v_online_now,
    'total_messages', v_total_messages
  );
END; $$;

-- 6. Recent signups RPC
CREATE OR REPLACE FUNCTION public.get_recent_signups(p_limit int DEFAULT 20)
RETURNS TABLE(id uuid, full_name text, email text, credit_balance numeric, created_at timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT id, full_name, email, credit_balance, created_at
  FROM public.profiles ORDER BY created_at DESC LIMIT p_limit;
$$;

-- 7. upsert_phone_user updated for numeric balance
CREATE OR REPLACE FUNCTION public.upsert_phone_user(
  p_full_name text, p_phone text, p_device_id text DEFAULT NULL, p_claim_trial boolean DEFAULT true
)
RETURNS json LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_profile public.profiles%ROWTYPE; v_credits numeric; v_message text; v_is_new boolean := false; v_cheat boolean := false;
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE phone_number = p_phone LIMIT 1;
  IF FOUND THEN
    RETURN json_build_object('id',v_profile.id,'full_name',v_profile.full_name,'phone_number',v_profile.phone_number,'credit_balance',v_profile.credit_balance,'is_new',false,'message','Welcome back!');
  ELSE
    v_is_new := true;
    IF p_claim_trial AND public.device_has_claimed_credits(p_device_id) THEN v_credits:=0; v_cheat:=true; v_message:='Trial already claimed.';
    ELSIF p_claim_trial THEN v_credits:=20; v_message:='Welcome! 20 free credits.';
    ELSE v_credits:=0; v_message:='Account created.';
    END IF;
    INSERT INTO public.profiles(id,full_name,phone_number,credit_balance,device_id,role)
    VALUES(gen_random_uuid(),p_full_name,p_phone,v_credits,CASE WHEN v_cheat THEN NULL ELSE p_device_id END,'user')
    RETURNING * INTO v_profile;
    RETURN json_build_object('id',v_profile.id,'full_name',v_profile.full_name,'phone_number',v_profile.phone_number,'credit_balance',v_profile.credit_balance,'is_new',true,'cheat_detected',v_cheat,'message',v_message);
  END IF;
END; $$;

-- 8. add_credits updated for numeric
CREATE OR REPLACE FUNCTION public.add_credits(p_profile_id uuid, p_amount numeric)
RETURNS numeric
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_balance numeric;
BEGIN
  UPDATE public.profiles SET credit_balance = credit_balance + p_amount WHERE id = p_profile_id
  RETURNING credit_balance INTO v_balance;
  RETURN v_balance;
END; $$;

-- 9. Session touch trigger (if not exists)
CREATE OR REPLACE FUNCTION public.touch_session_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
