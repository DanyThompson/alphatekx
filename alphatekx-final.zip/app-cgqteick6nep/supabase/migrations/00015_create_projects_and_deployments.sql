
-- ── projects: master project registry (extends builder_apps) ──────────────
CREATE TABLE projects (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id    uuid NOT NULL,
  name          text NOT NULL DEFAULT 'Untitled Project',
  description   text,
  tech_stack    text NOT NULL DEFAULT 'HTML/CSS/JS',
  status        text NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft','building','deployed','error')),
  html_code     text NOT NULL DEFAULT '',
  live_url      text,
  custom_domain text,
  thumbnail_url text,
  stars         int  NOT NULL DEFAULT 0,
  views         int  NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "projects_all" ON projects FOR ALL USING (true) WITH CHECK (true);

-- auto-update updated_at
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER projects_updated_at
  BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- ── deployments: every deploy event per project ───────────────────────────
CREATE TABLE deployments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id   uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  profile_id   uuid NOT NULL,
  version      int  NOT NULL DEFAULT 1,
  status       text NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending','building','live','failed','rolled_back')),
  live_url     text,
  build_log    text,
  deploy_time_ms int,
  credits_used int NOT NULL DEFAULT 5,
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE deployments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "deployments_all" ON deployments FOR ALL USING (true) WITH CHECK (true);

-- ── project_collaborators: team access ────────────────────────────────────
CREATE TABLE project_collaborators (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  profile_id uuid NOT NULL,
  role       text NOT NULL DEFAULT 'viewer' CHECK (role IN ('owner','editor','viewer')),
  added_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE(project_id, profile_id)
);

ALTER TABLE project_collaborators ENABLE ROW LEVEL SECURITY;
CREATE POLICY "collab_all" ON project_collaborators FOR ALL USING (true) WITH CHECK (true);

-- ── Storage bucket for deployed apps ──────────────────────────────────────
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('deployed-apps', 'deployed-apps', true, 10485760,
        ARRAY['text/html','application/octet-stream','text/css','application/javascript'])
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "deployed_apps_storage_all"
  ON storage.objects FOR ALL
  USING  (bucket_id = 'deployed-apps')
  WITH CHECK (bucket_id = 'deployed-apps');
