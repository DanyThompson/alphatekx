
-- ── Extend profiles with community fields ────────────────────────
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS username         text,
  ADD COLUMN IF NOT EXISTS bio              text DEFAULT '',
  ADD COLUMN IF NOT EXISTS skills           text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS location         text DEFAULT '',
  ADD COLUMN IF NOT EXISTS country_code     text DEFAULT '',
  ADD COLUMN IF NOT EXISTS avatar_url       text DEFAULT '',
  ADD COLUMN IF NOT EXISTS verified         boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS follower_count   int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS following_count  int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS online_at        timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_username ON profiles(username) WHERE username IS NOT NULL;

-- ── Extend community_posts (id is bigint) ────────────────────────
ALTER TABLE community_posts
  ADD COLUMN IF NOT EXISTS user_id          uuid REFERENCES profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS author_avatar    text DEFAULT '',
  ADD COLUMN IF NOT EXISTS media_urls       text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS code_snippet     text DEFAULT '',
  ADD COLUMN IF NOT EXISTS code_language    text DEFAULT '',
  ADD COLUMN IF NOT EXISTS link_url         text DEFAULT '',
  ADD COLUMN IF NOT EXISTS hashtags         text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS comment_count    int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS share_count      int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_repost        boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS repost_of        bigint;

-- ── post_comments ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS post_comments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id      bigint NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  user_id      uuid REFERENCES profiles(id) ON DELETE SET NULL,
  author_name  text NOT NULL DEFAULT 'Anonymous',
  author_init  text NOT NULL DEFAULT 'A',
  author_color text NOT NULL DEFAULT '#6d28d9',
  content      text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE post_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "comments_select_all"  ON post_comments FOR SELECT USING (true);
CREATE POLICY "comments_insert_all"  ON post_comments FOR INSERT WITH CHECK (true);
CREATE POLICY "comments_delete_all"  ON post_comments FOR DELETE USING (true);

-- ── user_follows ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_follows (
  follower_id  text NOT NULL,
  following_id text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, following_id)
);
ALTER TABLE user_follows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "follows_select_all"  ON user_follows FOR SELECT USING (true);
CREATE POLICY "follows_insert_all"  ON user_follows FOR INSERT WITH CHECK (true);
CREATE POLICY "follows_delete_all"  ON user_follows FOR DELETE USING (true);

-- ── direct_messages ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS direct_messages (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id    text NOT NULL,
  sender_name  text NOT NULL DEFAULT 'Anonymous',
  sender_init  text NOT NULL DEFAULT 'A',
  sender_color text NOT NULL DEFAULT '#6d28d9',
  receiver_id  text NOT NULL,
  receiver_name text NOT NULL DEFAULT 'Anonymous',
  content      text NOT NULL,
  read_status  boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE direct_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "dm_select_all"   ON direct_messages FOR SELECT USING (true);
CREATE POLICY "dm_insert_all"   ON direct_messages FOR INSERT WITH CHECK (true);
CREATE POLICY "dm_update_all"   ON direct_messages FOR UPDATE USING (true);

-- ── notifications ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      text NOT NULL,
  type         text NOT NULL,
  actor_name   text NOT NULL DEFAULT '',
  actor_init   text NOT NULL DEFAULT '',
  actor_color  text NOT NULL DEFAULT '#6d28d9',
  related_id   text,
  message      text NOT NULL DEFAULT '',
  read_status  boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif_select_all"  ON notifications FOR SELECT USING (true);
CREATE POLICY "notif_insert_all"  ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "notif_update_all"  ON notifications FOR UPDATE USING (true);
CREATE POLICY "notif_delete_all"  ON notifications FOR DELETE USING (true);

-- ── Indexes ───────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_community_posts_created  ON community_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_community_posts_likes    ON community_posts(likes DESC);
CREATE INDEX IF NOT EXISTS idx_post_comments_post       ON post_comments(post_id);
CREATE INDEX IF NOT EXISTS idx_user_follows_follower    ON user_follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_user_follows_following   ON user_follows(following_id);
CREATE INDEX IF NOT EXISTS idx_dms_sender               ON direct_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_dms_receiver             ON direct_messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user       ON notifications(user_id, created_at DESC);

-- ── RPCs ──────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION increment_post_likes(p_post_id bigint)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE community_posts SET likes = likes + 1 WHERE id = p_post_id;
END;$$;

CREATE OR REPLACE FUNCTION decrement_post_likes(p_post_id bigint)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE community_posts SET likes = GREATEST(likes - 1, 0) WHERE id = p_post_id;
END;$$;

CREATE OR REPLACE FUNCTION increment_post_comments(p_post_id bigint)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE community_posts SET comment_count = comment_count + 1 WHERE id = p_post_id;
END;$$;

CREATE OR REPLACE FUNCTION increment_post_shares(p_post_id bigint)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE community_posts SET share_count = share_count + 1 WHERE id = p_post_id;
END;$$;
