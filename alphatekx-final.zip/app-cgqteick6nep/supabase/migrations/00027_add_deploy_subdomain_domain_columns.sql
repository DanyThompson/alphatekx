
ALTER TABLE guardian_projects
  ADD COLUMN IF NOT EXISTS provisioned_subdomain text,
  ADD COLUMN IF NOT EXISTS custom_domain text,
  ADD COLUMN IF NOT EXISTS dns_verification_status text DEFAULT 'pending';
