
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('builder-apps', 'builder-apps', true, 5242880, ARRAY['text/html', 'application/octet-stream'])
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "builder_apps_storage_all"
ON storage.objects FOR ALL
USING (bucket_id = 'builder-apps')
WITH CHECK (bucket_id = 'builder-apps');
