
-- ── 1. payment_logs — deduplication / audit trail ──────────────────────────
CREATE TABLE IF NOT EXISTS payment_logs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference     text UNIQUE NOT NULL,
  profile_id    uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  pack          text NOT NULL,
  credits_added numeric(12,2) NOT NULL,
  amount_usd    numeric(10,2) NOT NULL,
  verified_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE payment_logs ENABLE ROW LEVEL SECURITY;

-- Only service-role (edge functions) may insert; users can only read their own
CREATE POLICY "users_read_own_payments" ON payment_logs
  FOR SELECT USING (profile_id = auth.uid());

-- No direct INSERT/UPDATE/DELETE by end-users
CREATE POLICY "deny_user_write_payments" ON payment_logs
  FOR ALL USING (false) WITH CHECK (false);

-- ── 2. Firewall: block direct UPDATE of credit_balance ──────────────────────
-- Drop any existing permissive write policies on profiles for credit_balance
-- (RLS already exists; we add a specific guard policy for credit_balance writes)
-- The add_credits and deduct_chat_credit RPCs are SECURITY DEFINER so they bypass RLS — safe.
-- We deny any direct UPDATE that touches credit_balance from a non-service role session.

-- Ensure RLS is on (idempotent)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Drop the overly-permissive profile update policy if it exists, replace with guarded one
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles
  FOR UPDATE USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- ── 3. admin_transfer_credits RPC ──────────────────────────────────────────
-- SECURITY DEFINER runs as postgres superuser; we manually verify the caller is the admin
CREATE OR REPLACE FUNCTION admin_transfer_credits(
  p_target_email text,
  p_amount       numeric
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_email text;
  v_target_id    uuid;
  v_new_balance  numeric;
BEGIN
  -- Verify caller is the admin
  SELECT email INTO v_caller_email
    FROM auth.users
   WHERE id = auth.uid();

  IF v_caller_email IS DISTINCT FROM 'iamdan4live@gmail.com' THEN
    RAISE EXCEPTION 'Unauthorized: admin only';
  END IF;

  IF p_amount <= 0 OR p_amount > 100000 THEN
    RAISE EXCEPTION 'Invalid amount: must be between 0 and 100000';
  END IF;

  -- Resolve target profile id from email
  SELECT p.id INTO v_target_id
    FROM profiles p
    JOIN auth.users u ON u.id = p.id
   WHERE u.email = p_target_email
   LIMIT 1;

  IF v_target_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'User not found: ' || p_target_email);
  END IF;

  -- Add credits
  UPDATE profiles
     SET credit_balance = credit_balance + p_amount
   WHERE id = v_target_id
  RETURNING credit_balance INTO v_new_balance;

  RETURN jsonb_build_object(
    'success',      true,
    'target_email', p_target_email,
    'credits_added', p_amount,
    'new_balance',  v_new_balance
  );
END;
$$;

-- Revoke public execute, grant only to authenticated users
-- (actual gate is the email check inside the function)
REVOKE ALL ON FUNCTION admin_transfer_credits(text, numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION admin_transfer_credits(text, numeric) TO authenticated;

-- ── 4. Rate-limit table for paystack references ────────────────────────────
-- Already handled by the UNIQUE constraint on payment_logs.reference
-- Additional: index for fast lookup
CREATE INDEX IF NOT EXISTS idx_payment_logs_reference ON payment_logs(reference);
CREATE INDEX IF NOT EXISTS idx_payment_logs_profile_id ON payment_logs(profile_id);
