-- ── Transaction history ───────────────────────────────────────────
CREATE TABLE public.transaction_history (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type        text NOT NULL CHECK (type IN ('credit','debit')),
  amount      integer NOT NULL,
  action_type text NOT NULL,
  reference   text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.transaction_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own transactions" ON public.transaction_history
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- ── Site deployments ─────────────────────────────────────────────
CREATE TABLE public.site_deployments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  subdomain     text NOT NULL,
  file_paths    jsonb NOT NULL DEFAULT '[]',
  live_url      text NOT NULL,
  status        text NOT NULL DEFAULT 'active' CHECK (status IN ('active','failed','rolled_back')),
  custom_domain text,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX site_deployments_subdomain_idx ON public.site_deployments (subdomain);
ALTER TABLE public.site_deployments ENABLE ROW LEVEL SECURITY;

-- Anon can check subdomain availability
CREATE POLICY "Anyone can check subdomain" ON public.site_deployments
  FOR SELECT TO anon USING (true);

CREATE POLICY "Authenticated users can check subdomain" ON public.site_deployments
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can insert own site deployments" ON public.site_deployments
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own site deployments" ON public.site_deployments
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- ── Storage bucket: sites (public) ───────────────────────────────
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('sites', 'sites', true, 52428800)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public read site files" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'sites');

CREATE POLICY "Service role upload site files" ON storage.objects
  FOR INSERT TO service_role WITH CHECK (bucket_id = 'sites');

CREATE POLICY "Service role update site files" ON storage.objects
  FOR UPDATE TO service_role USING (bucket_id = 'sites');

CREATE POLICY "Service role delete site files" ON storage.objects
  FOR DELETE TO service_role USING (bucket_id = 'sites');

-- ── Update handle_new_user to log signup bonus ────────────────────
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.email),
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  -- Log signup bonus (only if profile was just created)
  IF NOT EXISTS (SELECT 1 FROM public.transaction_history WHERE user_id = NEW.id AND action_type = 'signup_bonus') THEN
    INSERT INTO public.transaction_history (user_id, type, amount, action_type, reference)
    VALUES (NEW.id, 'credit', 20, 'signup_bonus', 'initial');
  END IF;
  RETURN NEW;
END;
$$;
