
-- Ensure the generated-media storage bucket exists and is public
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'generated-media',
  'generated-media',
  true,
  52428800,
  ARRAY['audio/mpeg','audio/wav','audio/mp3','audio/ogg','image/png','image/jpeg','image/webp','video/mp4']
)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Drop and recreate policies cleanly
DROP POLICY IF EXISTS "Public read generated-media" ON storage.objects;
DROP POLICY IF EXISTS "Service insert generated-media" ON storage.objects;

CREATE POLICY "Public read generated-media"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'generated-media');

CREATE POLICY "Service insert generated-media"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'generated-media');
