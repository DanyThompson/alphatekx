
-- Storage bucket for AI-generated videos
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('generated-media', 'generated-media', true, 209715200, ARRAY['video/mp4','video/webm','video/quicktime','application/octet-stream'])
ON CONFLICT (id) DO NOTHING;

-- RLS: public read, service role write
CREATE POLICY "generated_media_public_read" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'generated-media');

CREATE POLICY "generated_media_service_write" ON storage.objects
  FOR INSERT TO service_role WITH CHECK (bucket_id = 'generated-media');
