
-- 1. Update column default to 20
ALTER TABLE public.profiles ALTER COLUMN credit_balance SET DEFAULT 20;

-- 2. Replace upsert_phone_user with correct signature and 20 credits
CREATE OR REPLACE FUNCTION public.upsert_phone_user(
  p_full_name  text,
  p_phone      text,
  p_device_id  text  DEFAULT NULL,
  p_claim_trial boolean DEFAULT true
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_profile   public.profiles%ROWTYPE;
  v_credits   integer;
  v_message   text;
  v_is_new    boolean := false;
  v_cheat     boolean := false;
BEGIN
  -- Check if phone already registered
  SELECT * INTO v_profile FROM public.profiles WHERE phone_number = p_phone LIMIT 1;

  IF FOUND THEN
    -- Existing user: just return their current data (login)
    RETURN json_build_object(
      'id',             v_profile.id,
      'full_name',      v_profile.full_name,
      'phone_number',   v_profile.phone_number,
      'credit_balance', v_profile.credit_balance,
      'is_new',         false,
      'message',        'Welcome back, ' || COALESCE(v_profile.full_name, 'User') || '!'
    );
  ELSE
    -- New user registration
    v_is_new := true;

    IF p_claim_trial AND public.device_has_claimed_credits(p_device_id) THEN
      v_credits := 0;
      v_cheat   := true;
      v_message := 'Trial already claimed on this device.';
    ELSIF p_claim_trial THEN
      v_credits := 20;
      v_message := 'Welcome! You have been awarded 20 free credits.';
    ELSE
      v_credits := 0;
      v_message := 'Account created.';
    END IF;

    INSERT INTO public.profiles (
      id, full_name, phone_number, credit_balance, device_id, role
    ) VALUES (
      gen_random_uuid(), p_full_name, p_phone, v_credits,
      CASE WHEN v_cheat THEN NULL ELSE p_device_id END,
      'user'
    )
    RETURNING * INTO v_profile;

    RETURN json_build_object(
      'id',             v_profile.id,
      'full_name',      v_profile.full_name,
      'phone_number',   v_profile.phone_number,
      'credit_balance', v_profile.credit_balance,
      'is_new',         true,
      'cheat_detected', v_cheat,
      'message',        v_message
    );
  END IF;
END;
$$;
