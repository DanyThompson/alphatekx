-- Atomic credit deduction RPC (avoids race conditions)
CREATE OR REPLACE FUNCTION public.deduct_credits(
  p_user_id    uuid,
  p_amount     integer,
  p_action_type text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_balance integer;
BEGIN
  SELECT credit_balance INTO v_balance FROM profiles WHERE id = p_user_id FOR UPDATE;
  IF v_balance IS NULL THEN
    RETURN jsonb_build_object('success', false, 'balance', 0, 'message', 'User not found');
  END IF;
  IF v_balance < p_amount THEN
    RETURN jsonb_build_object('success', false, 'balance', v_balance, 'message', 'Insufficient credits');
  END IF;
  UPDATE profiles SET credit_balance = credit_balance - p_amount WHERE id = p_user_id;
  INSERT INTO transaction_history (user_id, type, amount, action_type)
    VALUES (p_user_id, 'debit', p_amount, p_action_type);
  RETURN jsonb_build_object('success', true, 'balance', v_balance - p_amount);
END;
$$;
