
CREATE TABLE builder_apps (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id   uuid NOT NULL,
  app_name     text NOT NULL DEFAULT 'Untitled App',
  description  text,
  html_code    text NOT NULL DEFAULT '',
  deployed     boolean NOT NULL DEFAULT false,
  share_url    text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE builder_apps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "builder_apps_all" ON builder_apps FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE video_studio_projects (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id       uuid NOT NULL,
  project_name     text NOT NULL DEFAULT 'Untitled Project',
  scenes           jsonb NOT NULL DEFAULT '[]',
  final_video_url  text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE video_studio_projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "video_studio_all" ON video_studio_projects FOR ALL USING (true) WITH CHECK (true);
