
-- Rename amount_usd to amount_ngn and make it nullable for backward-compat
ALTER TABLE payment_logs RENAME COLUMN amount_usd TO amount_ngn;
ALTER TABLE payment_logs ALTER COLUMN amount_ngn DROP NOT NULL;
