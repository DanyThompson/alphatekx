-- Make user_id nullable on notes so anon users can create notes
ALTER TABLE notes ALTER COLUMN user_id DROP NOT NULL;

-- Same for exam_attempts
ALTER TABLE exam_attempts ALTER COLUMN user_id DROP NOT NULL;