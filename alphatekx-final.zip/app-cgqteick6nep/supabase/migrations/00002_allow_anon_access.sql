-- Drop old user-scoped RLS policies on notes
DROP POLICY IF EXISTS "Users can view own notes" ON notes;
DROP POLICY IF EXISTS "Users can insert own notes" ON notes;
DROP POLICY IF EXISTS "Users can update own notes" ON notes;
DROP POLICY IF EXISTS "Users can delete own notes" ON notes;

-- Open anon access for notes (platform-level, no auth required)
CREATE POLICY "Anon can view notes" ON notes FOR SELECT USING (true);
CREATE POLICY "Anon can insert notes" ON notes FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon can update notes" ON notes FOR UPDATE USING (true);
CREATE POLICY "Anon can delete notes" ON notes FOR DELETE USING (true);

-- Drop old user-scoped RLS policies on exam_attempts
DROP POLICY IF EXISTS "Users can view own attempts" ON exam_attempts;
DROP POLICY IF EXISTS "Users can insert own attempts" ON exam_attempts;

-- Open anon access for exam_attempts
CREATE POLICY "Anon can view exam attempts" ON exam_attempts FOR SELECT USING (true);
CREATE POLICY "Anon can insert exam attempts" ON exam_attempts FOR INSERT WITH CHECK (true);