
-- ══════════════════════════════════════════════════════════════
-- DEPLOYMENT GUARDIAN TABLES
-- ══════════════════════════════════════════════════════════════

-- ── guardian_projects ───────────────────────────────────────────
CREATE TABLE guardian_projects (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  project_name    text NOT NULL,
  repo_url        text NOT NULL,
  audit_status    text NOT NULL DEFAULT 'pending'
    CHECK (audit_status IN ('pending','scanning','scanned','deploying','deployed','failed')),
  last_audit_score integer NOT NULL DEFAULT 0
    CHECK (last_audit_score >= 0 AND last_audit_score <= 100),
  deployment_url  text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, repo_url)
);

-- ── guardian_audit_reports ──────────────────────────────────────
CREATE TABLE guardian_audit_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id      uuid NOT NULL REFERENCES guardian_projects(id) ON DELETE CASCADE,
  user_id         uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  repo_url        text NOT NULL,
  audit_score     integer NOT NULL DEFAULT 0
    CHECK (audit_score >= 0 AND audit_score <= 100),
  findings        jsonb NOT NULL DEFAULT '[]'::jsonb,
  critical_count  integer NOT NULL DEFAULT 0,
  high_count      integer NOT NULL DEFAULT 0,
  medium_count    integer NOT NULL DEFAULT 0,
  low_count       integer NOT NULL DEFAULT 0,
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- ── guardian_deployments ────────────────────────────────────────
CREATE TABLE guardian_deployments (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id          uuid NOT NULL REFERENCES guardian_projects(id) ON DELETE CASCADE,
  user_id             uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  audit_report_id     uuid REFERENCES guardian_audit_reports(id) ON DELETE SET NULL,
  audit_score         integer NOT NULL DEFAULT 0,
  status              text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','running','success','failed')),
  commit_hash         text NOT NULL DEFAULT '',
  branch              text NOT NULL DEFAULT 'main',
  deployment_url      text,
  webhook_payload     jsonb,
  webhook_response    jsonb,
  duration_ms         integer,
  findings_snapshot   jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at          timestamptz NOT NULL DEFAULT now(),
  completed_at        timestamptz
);

-- ── Indexes ──────────────────────────────────────────────────────
CREATE INDEX idx_gprojects_user      ON guardian_projects(user_id);
CREATE INDEX idx_gaudit_project      ON guardian_audit_reports(project_id);
CREATE INDEX idx_gaudit_user         ON guardian_audit_reports(user_id);
CREATE INDEX idx_gdeploy_project     ON guardian_deployments(project_id);
CREATE INDEX idx_gdeploy_user        ON guardian_deployments(user_id);

-- ── updated_at trigger ───────────────────────────────────────────
CREATE OR REPLACE FUNCTION guardian_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER trg_gprojects_updated_at
  BEFORE UPDATE ON guardian_projects
  FOR EACH ROW EXECUTE FUNCTION guardian_set_updated_at();

-- ══════════════════════════════════════════════════════════════
-- RLS
-- ══════════════════════════════════════════════════════════════
ALTER TABLE guardian_projects       ENABLE ROW LEVEL SECURITY;
ALTER TABLE guardian_audit_reports  ENABLE ROW LEVEL SECURITY;
ALTER TABLE guardian_deployments    ENABLE ROW LEVEL SECURITY;

-- guardian_projects
CREATE POLICY "gp_select" ON guardian_projects FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gp_insert" ON guardian_projects FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "gp_update" ON guardian_projects FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "gp_delete" ON guardian_projects FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gp_anon"   ON guardian_projects FOR SELECT TO anon USING (false);

-- guardian_audit_reports
CREATE POLICY "gar_select" ON guardian_audit_reports FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gar_insert" ON guardian_audit_reports FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "gar_update" ON guardian_audit_reports FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gar_delete" ON guardian_audit_reports FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gar_anon"   ON guardian_audit_reports FOR SELECT TO anon USING (false);

-- guardian_deployments
CREATE POLICY "gd_select" ON guardian_deployments FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gd_insert" ON guardian_deployments FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "gd_update" ON guardian_deployments FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gd_delete" ON guardian_deployments FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "gd_anon"   ON guardian_deployments FOR SELECT TO anon USING (false);
