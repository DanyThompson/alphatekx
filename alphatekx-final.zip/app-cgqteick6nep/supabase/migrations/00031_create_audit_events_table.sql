
CREATE TABLE IF NOT EXISTS audit_events (
  id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     uuid        REFERENCES auth.users(id) ON DELETE CASCADE,
  subdomain   text        NOT NULL DEFAULT '',
  action      text        NOT NULL,
  actor       text        NOT NULL DEFAULT 'System',
  details     text        NOT NULL DEFAULT '',
  status      text        NOT NULL DEFAULT 'Success',
  security_score integer,
  manual_flags text[],
  created_at  timestamptz DEFAULT now()
);

ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own audit events"
  ON audit_events FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own audit events"
  ON audit_events FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS audit_events_user_id_created_at_idx
  ON audit_events (user_id, created_at DESC);
