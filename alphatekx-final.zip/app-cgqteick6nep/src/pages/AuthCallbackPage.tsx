/**
 * /auth/callback  — handles Google OAuth redirect
 *
 * Supabase JS (detectSessionInUrl: true) automatically exchanges the ?code=
 * or #access_token= in the URL as soon as any page loads.  This page just
 * listens for the resulting SIGNED_IN event and navigates to /dashboard.
 * It is also the safety net for any future PKCE-explicit redirects.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function AuthCallbackPage() {
  const navigate = useNavigate();
  const [error, setError] = useState('');

  useEffect(() => {
    let settled = false;

    const finish = (path = '/dashboard') => {
      if (!settled) {
        settled = true;
        navigate(path, { replace: true });
      }
    };

    const checkSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) {
          console.warn('[auth] callback session check failed:', error.message);
          setError('We could not finish sign-in. Please try again.');
          return;
        }

        if (session?.user) {
          finish();
          return;
        }

        const { data: { subscription } } = supabase.auth.onAuthStateChange((event, nextSession) => {
          if (event === 'SIGNED_IN' && nextSession?.user) {
            finish();
          } else if (event === 'SIGNED_OUT') {
            finish('/login');
          } else if (event === 'TOKEN_REFRESHED' && nextSession?.user) {
            finish();
          }
        });

        const timer = window.setTimeout(() => {
          if (!settled) {
            setError('Sign-in timed out. Please try again.');
          }
        }, 8000);

        return () => {
          subscription.unsubscribe();
          window.clearTimeout(timer);
        };
      } catch (err) {
        console.warn('[auth] callback failed:', err);
        setError('We could not finish sign-in. Please try again.');
      }
    };

    const cleanup = checkSession();

    return () => {
      if (typeof cleanup === 'function') {
        cleanup();
      }
    };
  }, [navigate]);

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center gap-4"
      style={{ background: '#050d1a' }}>
      {error ? (
        <>
          <div className="flex items-start gap-2 rounded-xl px-4 py-3 max-w-sm"
            style={{ background: 'rgba(248,81,73,0.08)', border: '1px solid rgba(248,81,73,0.22)' }}>
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#f85149' }} />
            <p className="text-sm text-pretty" style={{ color: '#f85149' }}>{error}</p>
          </div>
          <button
            onClick={() => navigate('/login', { replace: true })}
            className="text-sm underline"
            style={{ color: '#58a6ff' }}>
            Back to sign in
          </button>
        </>
      ) : (
        <>
          <Loader2 className="w-7 h-7 animate-spin" style={{ color: '#58a6ff' }} />
          <p className="text-sm" style={{ color: '#8b949e' }}>Signing you in with Google…</p>
        </>
      )}
    </div>
  );
}
