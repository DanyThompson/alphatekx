/**
 * LiveSitePage — full-screen renderer for deployed sites.
 *
 * Supabase Edge Functions cannot serve text/html without the platform forcing
 * `Content-Security-Policy: default-src 'none'; sandbox` on the response.
 * CSS/JS served via serve-site work fine (correct MIME + permissive CSP).
 *
 * Strategy:
 *   1. Fetch HTML as text/plain from serve-site (works)
 *   2. Rewrite relative asset URLs to absolute serve-site proxy URLs
 *   3. Create a Blob with type text/html → URL.createObjectURL()
 *   4. Set iframe src to the Blob URL — no platform CSP restriction on blobs
 *
 * Route: /live/:subdomain
 * Used as the shareable live link returned by create-site.
 */

import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Loader2, AlertCircle, ArrowLeft, ExternalLink, Copy, Check } from 'lucide-react';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SERVE_BASE   = `${SUPABASE_URL}/functions/v1/serve-site`;

/** Rewrite all relative asset references in HTML to absolute serve-site URLs */
function rewriteAssets(html: string, subdomain: string): string {
  const base = `${SERVE_BASE}/${subdomain}`;

  // <link rel="stylesheet" href="...">  and  <script src="...">  and  <img src="...">
  return html
    .replace(/(href|src)="(?!https?:\/\/|\/\/|data:|blob:|#)([^"]+)"/gi, (_match, attr, path) => {
      const clean = path.replace(/^\.\//, '');
      return `${attr}="${base}/${clean}"`;
    })
    .replace(/(href|src)='(?!https?:\/\/|\/\/|data:|blob:|#)([^']+)'/gi, (_match, attr, path) => {
      const clean = path.replace(/^\.\//, '');
      return `${attr}='${base}/${clean}'`;
    });
}

export default function LiveSitePage() {
  const { subdomain } = useParams<{ subdomain: string }>();
  const navigate = useNavigate();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const blobUrlRef = useRef<string>('');

  const [status,   setStatus]   = useState<'loading' | 'ready' | 'error'>('loading');
  const [errorMsg, setErrorMsg] = useState('');
  const [blobUrl,  setBlobUrl]  = useState('');
  const [copied,   setCopied]   = useState(false);
  const [barVisible, setBarVisible] = useState(true);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  /* Auto-hide the bar after 4 s; re-show on mouse move */
  useEffect(() => {
    const show = () => {
      setBarVisible(true);
      if (hideTimer.current) clearTimeout(hideTimer.current);
      hideTimer.current = setTimeout(() => setBarVisible(false), 4000);
    };
    show();
    window.addEventListener('mousemove', show, { passive: true });
    window.addEventListener('touchstart', show, { passive: true });
    return () => {
      window.removeEventListener('mousemove', show);
      window.removeEventListener('touchstart', show);
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!subdomain) { setStatus('error'); setErrorMsg('No subdomain provided.'); return; }

    let cancelled = false;

    async function loadSite() {
      try {
        const res = await fetch(`${SERVE_BASE}/${subdomain}/index.html`, {
          headers: { 'Accept': '*/*' },
          signal: AbortSignal.timeout(15_000),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const rawHtml = await res.text();
        const rewritten = rewriteAssets(rawHtml, subdomain!);

        if (cancelled) return;

        if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current);

        const blob = new Blob([rewritten], { type: 'text/html; charset=utf-8' });
        const url  = URL.createObjectURL(blob);
        blobUrlRef.current = url;
        setBlobUrl(url);
        setStatus('ready');
      } catch (e) {
        if (cancelled) return;
        const msg = e instanceof Error ? e.message : String(e);
        setErrorMsg(msg);
        setStatus('error');
      }
    }

    loadSite();
    return () => { cancelled = true; };
  }, [subdomain]);

  useEffect(() => {
    return () => { if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current); };
  }, []);

  // Primary shareable URL = branded alphatekx.name.ng domain
  const shareUrl = `https://${subdomain}.alphatekx.name.ng`;
  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (status === 'loading') {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: '12px',
        background: '#0d1117', color: '#8b949e',
      }}>
        <Loader2 style={{ width: 32, height: 32, animation: 'spin 1s linear infinite', color: '#58a6ff' }} />
        <p style={{ fontSize: '0.875rem', fontFamily: 'system-ui, sans-serif' }}>
          Loading {subdomain}.alphatekx.name.ng…
        </p>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: '16px',
        background: '#0d1117', color: '#c9d1d9',
        fontFamily: 'system-ui, sans-serif', padding: '2rem', textAlign: 'center',
      }}>
        <AlertCircle style={{ width: 40, height: 40, color: '#f85149' }} />
        <h1 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Site not found</h1>
        <p style={{ fontSize: '0.875rem', color: '#8b949e', maxWidth: 360 }}>{errorMsg}</p>
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <button onClick={() => navigate(-1)}
            style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#58a6ff', fontSize: '0.875rem', background: 'none', border: 'none', cursor: 'pointer' }}>
            ← Go Back
          </button>
          <a href="/" style={{ color: '#8b949e', fontSize: '0.875rem' }}>← Back to AlphaTekx</a>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: '#000' }}>
      {/* ── Floating top bar ───────────────────────────────────── */}
      <div
        style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 9999,
          height: 48,
          display: 'flex', alignItems: 'center', gap: 8, padding: '0 12px',
          background: 'rgba(3,7,17,0.90)',
          backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(88,166,255,0.12)',
          transition: 'opacity 0.4s ease, transform 0.4s ease',
          opacity: barVisible ? 1 : 0,
          transform: barVisible ? 'translateY(0)' : 'translateY(-100%)',
          pointerEvents: barVisible ? 'auto' : 'none',
        }}>
        {/* Back */}
        <button onClick={() => navigate(-1)}
          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 10px', borderRadius: 10, fontSize: '0.75rem', fontWeight: 600, color: 'rgba(139,148,158,0.75)', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', cursor: 'pointer', flexShrink: 0, fontFamily: 'system-ui, sans-serif' }}>
          <ArrowLeft style={{ width: 13, height: 13 }} /> Back
        </button>

        {/* Live badge + URL */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 0, justifyContent: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 10px', borderRadius: 20, background: 'rgba(126,231,135,0.08)', border: '1px solid rgba(126,231,135,0.20)', flexShrink: 0 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#7ee787', boxShadow: '0 0 6px #7ee787', animation: 'pulse 2s ease-in-out infinite' }} />
            <span style={{ fontSize: '0.65rem', fontWeight: 700, color: '#7ee787', letterSpacing: '0.08em', textTransform: 'uppercase', fontFamily: 'system-ui, sans-serif' }}>LIVE</span>
          </div>
          <span style={{ fontSize: '0.75rem', fontFamily: 'monospace', color: 'rgba(201,209,217,0.55)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 280 }}>
            {subdomain}.alphatekx.name.ng
          </span>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
          <button onClick={handleCopy}
            style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 8, fontSize: '0.7rem', fontWeight: 600, color: copied ? '#7ee787' : '#58a6ff', background: copied ? 'rgba(126,231,135,0.08)' : 'rgba(88,166,255,0.08)', border: `1px solid ${copied ? 'rgba(126,231,135,0.22)' : 'rgba(88,166,255,0.22)'}`, cursor: 'pointer', fontFamily: 'system-ui, sans-serif', transition: 'all 0.2s' }}>
            {copied
              ? <Check style={{ width: 12, height: 12 }} />
              : <Copy style={{ width: 12, height: 12 }} />}
            {copied ? 'Copied!' : 'Copy'}
          </button>
          <a href={shareUrl} target="_blank" rel="noopener noreferrer"
            style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 8, fontSize: '0.7rem', fontWeight: 600, color: '#8b949e', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', textDecoration: 'none', fontFamily: 'system-ui, sans-serif' }}>
            <ExternalLink style={{ width: 12, height: 12 }} /> Open
          </a>
        </div>

        <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }`}</style>
      </div>

      {/* ── The site iframe ─────────────────────────────────────── */}
      <iframe
        ref={iframeRef}
        src={blobUrl}
        title={`${subdomain} — AlphaTekx`}
        style={{
          position: 'absolute', inset: 0,
          width: '100%', height: '100%',
          border: 'none', margin: 0, padding: 0,
          background: '#ffffff',
        }}
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads"
      />
    </div>
  );
}


