import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, ArrowRight, ArrowLeft, CheckCircle2, XCircle, Loader2, Zap, LogOut } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import TopUpModal from '@/components/TopUpModal';

/* ── helpers ──────────────────────────────────────────────── */
function validateFormat(name: string): string | null {
  if (!name) return null;
  if (name.length < 3) return 'At least 3 characters';
  if (name.length > 30) return 'At most 30 characters';
  if (/--/.test(name)) return 'No consecutive hyphens';
  if (name.startsWith('-') || name.endsWith('-'))
    return 'Cannot start or end with a hyphen';
  return null;
}

type SubmitStatus = 'idle' | 'checking' | 'taken' | 'error';

/* ── ambient orb ──────────────────────────────────────────── */
function Orb({ cls }: { cls: string }) {
  return <div className={`pointer-events-none absolute rounded-full blur-3xl opacity-[0.18] ${cls}`} />;
}

/* ── Welcome Page ─────────────────────────────────────────── */
export default function WelcomePage() {
  const navigate = useNavigate();
  const { user, profile, loading, signOut, refreshCredits } = useAuth();
  const [name,         setName]         = useState('');
  const [submitStatus, setSubmitStatus] = useState<SubmitStatus>('idle');
  const [showTopUp,    setShowTopUp]    = useState(false);

  // Redirect unauthenticated users to login
  useEffect(() => {
    if (!loading && !user) navigate('/login', { replace: true });
  }, [user, loading, navigate]);

  // Derived: format error shown inline while typing
  const formatErr = name ? validateFormat(name) : null;
  const isFormatOk = name.length > 0 && !formatErr;

  const handleContinue = useCallback(async () => {
    if (!isFormatOk || submitStatus === 'checking') return;

    setSubmitStatus('checking');

    // Hard 3-second timeout — if Supabase doesn't respond, proceed optimistically.
    // The edge function enforces uniqueness server-side, so duplicates are safe to let through here.
    const timeout = new Promise<'timeout'>(res => setTimeout(() => res('timeout'), 3000));

    try {
      const result = await Promise.race([
        supabase
          .from('site_deployments')
          .select('subdomain')
          .eq('subdomain', name)
          .maybeSingle(),
        timeout,
      ]);

      if (result === 'timeout') {
        console.warn('[claim] availability check timed out — proceeding optimistically');
        navigate('/deploy', { state: { subdomain: name } });
        return;
      }

      const { data, error } = result;

      if (error && error.code !== 'PGRST116') {
        console.warn('[claim] availability check error, proceeding:', error.message);
        navigate('/deploy', { state: { subdomain: name } });
        return;
      }

      if (data) {
        setSubmitStatus('taken');
        return;
      }

      navigate('/deploy', { state: { subdomain: name } });
    } catch (err) {
      console.warn('[claim] availability check threw, proceeding:', err);
      navigate('/deploy', { state: { subdomain: name } });
    }
  }, [isFormatOk, submitStatus, name, navigate]);

  /* inline feedback shown while typing */
  const inlineMsg = (() => {
    if (!name) return null;
    if (formatErr) return <span className="flex items-center gap-1.5 text-xs" style={{ color: '#e3b341' }}><XCircle className="w-3.5 h-3.5" /> {formatErr}</span>;
    if (submitStatus === 'taken') return <span className="flex items-center gap-1.5 text-xs" style={{ color: '#f85149' }}><XCircle className="w-3.5 h-3.5" /> Already taken — try a different name</span>;
    if (submitStatus === 'checking') return <span className="flex items-center gap-1.5 text-xs" style={{ color: '#58a6ff' }}><Loader2 className="w-3.5 h-3.5 animate-spin" /> Checking availability…</span>;
    return <span className="flex items-center gap-1.5 text-xs" style={{ color: '#7ee787' }}><CheckCircle2 className="w-3.5 h-3.5" /> Looks good!</span>;
  })();

  const borderColor = !name
    ? 'rgba(88,166,255,0.22)'
    : submitStatus === 'taken' || formatErr
      ? 'rgba(248,81,73,0.40)'
      : submitStatus === 'checking'
        ? 'rgba(88,166,255,0.40)'
        : isFormatOk
          ? 'rgba(126,231,135,0.40)'
          : 'rgba(88,166,255,0.22)';

  const canSubmit = isFormatOk && submitStatus !== 'checking';

  return (
    <>
    {showTopUp && <TopUpModal onClose={() => setShowTopUp(false)} onSuccess={() => { refreshCredits(); setShowTopUp(false); }} />}
    <div className="relative min-h-screen w-full overflow-x-hidden flex flex-col items-center justify-center px-4 py-16"
      style={{ background: '#050d1a' }}>
      <Orb cls="w-[500px] h-[500px] bg-blue-600 top-[-140px] left-[-120px] anim-orb-float" />
      <Orb cls="w-[380px] h-[380px] bg-indigo-700 bottom-[-100px] right-[-80px] anim-orb-float delay-500" />

      {/* Auth nav strip */}
      {profile && (
        <div className="fixed top-0 left-0 right-0 z-40 h-12 flex items-center justify-between px-4 md:px-8"
          style={{ background: 'rgba(5,13,26,0.85)', backdropFilter: 'blur(16px)', borderBottom: '1px solid rgba(88,166,255,0.08)' }}>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.22)' }}>
              <Shield className="w-3 h-3" style={{ color: '#58a6ff' }} />
            </div>
            <span className="text-xs font-bold tracking-widest uppercase hidden sm:block" style={{ color: 'rgba(88,166,255,0.70)' }}>AlphaTekx</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setShowTopUp(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold hover:opacity-80 transition-opacity"
              style={{ background: 'rgba(240,136,62,0.10)', border: '1px solid rgba(240,136,62,0.25)', color: '#f0883e' }}>
              <Zap className="w-3 h-3" />
              {profile.credit_balance} credits
            </button>
            {profile.avatar_url
              ? <img src={profile.avatar_url} alt="avatar" className="w-7 h-7 rounded-full object-cover shrink-0" style={{ border: '1px solid rgba(88,166,255,0.25)' }} />
              : <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold"
                  style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
                  {(profile.full_name ?? profile.email ?? 'U')[0].toUpperCase()}
                </div>
            }
            <button onClick={signOut} className="p-1 rounded-lg transition-opacity hover:opacity-70" title="Sign out" style={{ color: '#8b949e' }}>
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Back to home */}
      <button onClick={() => navigate('/')}
        className="relative z-10 fixed top-4 left-4 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all hover:opacity-80"
        style={{ color: 'rgba(139,148,158,0.65)', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <ArrowLeft className="w-3.5 h-3.5" /> Home
      </button>

      {/* Logo */}
      <div className="relative z-10 flex items-center gap-2.5 mb-12 anim-fade-up">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.28)' }}>
          <Shield className="w-4 h-4" style={{ color: '#58a6ff' }} />
        </div>
        <span className="text-sm font-semibold tracking-wider uppercase" style={{ color: 'rgba(88,166,255,0.80)' }}>AlphaTekx</span>
      </div>

      {/* Headline */}
      <h1 className="relative z-10 text-center font-black text-balance leading-tight mb-3 anim-fade-up delay-100"
        style={{ fontSize: 'clamp(2rem, 5.5vw, 4rem)', color: '#e6edf3', letterSpacing: '-0.03em' }}>
        Your files. Online.<br />In seconds.
      </h1>
      <p className="relative z-10 text-center text-pretty text-base md:text-lg mb-10 max-w-sm anim-fade-up delay-200"
        style={{ color: '#8b949e', lineHeight: 1.65 }}>
        Choose a web address for your project.
      </p>

      {/* Glass card */}
      <div className="relative z-10 glass-strong rounded-2xl w-full max-w-md p-6 md:p-8 anim-fade-up delay-300">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-normal mb-2" style={{ color: '#8b949e' }}>
              Choose a name for your project's web address
            </label>

            {/* Subdomain input row */}
            <div className="flex items-stretch rounded-xl overflow-hidden transition-all duration-200"
              style={{ background: 'rgba(4,10,24,0.72)', border: `1px solid ${borderColor}` }}>
              <input
                type="text"
                value={name}
                onChange={e => { setSubmitStatus('idle'); setName(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '')); }}
                onKeyDown={e => { if (e.key === 'Enter') handleContinue(); }}
                placeholder="my-portfolio"
                autoComplete="off"
                spellCheck={false}
                className="flex-1 min-w-0 px-4 py-3 text-sm bg-transparent outline-none font-mono"
                style={{ color: '#e6edf3', caretColor: '#58a6ff' }}
              />
              <div className="flex items-center px-2 shrink-0"
                style={{ borderLeft: '1px solid rgba(88,166,255,0.12)', background: 'rgba(88,166,255,0.04)' }}>
                <span className="text-[10px] font-mono whitespace-nowrap" style={{ color: 'rgba(88,166,255,0.55)' }}>
                  <span className="hidden sm:inline">.alphatekx</span>.name.ng
                </span>
              </div>
            </div>

            {/* Inline feedback */}
            <div className="mt-2 h-5">{inlineMsg}</div>
          </div>

          {/* URL preview */}
          {isFormatOk && submitStatus !== 'taken' && (
            <div className="rounded-xl px-4 py-3 anim-fade-in"
              style={{ background: 'rgba(74,168,110,0.08)', border: '1px solid rgba(126,231,135,0.18)' }}>
              <p className="text-xs" style={{ color: 'rgba(139,148,158,0.80)' }}>Your project will live at</p>
              <p className="text-sm font-mono mt-0.5 break-all" style={{ color: '#7ee787' }}>
                https://{name}.alphatekx.name.ng
              </p>
            </div>
          )}

          {/* CTA */}
          <button
            onClick={handleContinue}
            disabled={!canSubmit}
            className="w-full flex items-center justify-center gap-2 rounded-xl py-3.5 font-bold transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, #1d4ed8, #2563eb)',
              color: '#e0e7ff',
              border: '1px solid rgba(88,166,255,0.30)',
              boxShadow: canSubmit ? '0 4px 24px rgba(37,99,235,0.35)' : 'none',
              fontSize: '1rem',
            }}>
            {submitStatus === 'checking'
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Checking…</>
              : <>Claim My Address <ArrowRight className="w-4 h-4" /></>}
          </button>
        </div>

        {/* Hint */}
        <p className="mt-5 text-xs text-center" style={{ color: 'rgba(139,148,158,0.50)' }}>
          Letters, numbers, and hyphens only · 3–30 characters
        </p>
      </div>

      <p className="relative z-10 mt-8 text-xs text-center anim-fade-up delay-500"
        style={{ color: 'rgba(139,148,158,0.40)' }}>
        No config needed · We handle all the technical stuff for you
      </p>
    </div>
    </>
  );
}
