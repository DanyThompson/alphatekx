import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield, Rocket, ArrowRight, CheckCircle2,
  Globe, Zap, Lock, KeyRound, Terminal, Wifi, Eye,
  CloudUpload, Twitter, Github, Linkedin, Star,
  Activity, Users, Clock, RefreshCw, Code2, Layers,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

/* ─── Scroll-in reveal ────────────────────────────────────── */
function useInView(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el); return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function Reveal({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, visible } = useInView();
  return (
    <div ref={ref}
      className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ─── Gradient text helper ────────────────────────────────── */
function G({ children, from = '#58a6ff', to = '#7ee787' }: { children: React.ReactNode; from?: string; to?: string }) {
  return (
    <span style={{ background: `linear-gradient(135deg,${from},${to})`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
      {children}
    </span>
  );
}

/* ─── Subdomain URL preview (animated typing) ─────────────── */
const DEMO_NAMES = ['my-portfolio', 'school-project', 'jane-blog', 'startup-landing', 'class-website'];

function SubdomainPreview() {
  const [nameIdx, setNameIdx]     = useState(0);
  const [typed,   setTyped]       = useState('');
  const [deleting, setDeleting]   = useState(false);
  const full = DEMO_NAMES[nameIdx];

  useEffect(() => {
    let t: ReturnType<typeof setTimeout>;
    if (!deleting && typed.length < full.length) {
      t = setTimeout(() => setTyped(full.slice(0, typed.length + 1)), 80);
    } else if (!deleting && typed.length === full.length) {
      t = setTimeout(() => setDeleting(true), 1800);
    } else if (deleting && typed.length > 0) {
      t = setTimeout(() => setTyped(typed.slice(0, -1)), 45);
    } else if (deleting && typed.length === 0) {
      setDeleting(false);
      setNameIdx(i => (i + 1) % DEMO_NAMES.length);
    }
    return () => clearTimeout(t);
  }, [typed, deleting, full]);

  return (
    <div className="flex items-center gap-0 rounded-xl overflow-hidden mx-auto"
      style={{ background: 'rgba(4,10,24,0.80)', border: '1px solid rgba(88,166,255,0.25)', maxWidth: 420, width: '100%' }}>
      <div className="flex items-center gap-2 px-3 py-2.5 flex-1 min-w-0">
        <div className="w-2 h-2 rounded-full shrink-0 animate-pulse" style={{ background: '#7ee787' }} />
        <span className="text-sm font-mono" style={{ color: '#58a6ff' }}>{typed}</span>
        <span className="inline-block w-[2px] h-[16px] rounded-sm" style={{ background: '#58a6ff', animation: 'blink 1s step-end infinite' }} />
      </div>
      <div className="px-3 py-2.5 shrink-0"
        style={{ background: 'rgba(88,166,255,0.06)', borderLeft: '1px solid rgba(88,166,255,0.15)' }}>
        <span className="text-sm font-mono" style={{ color: 'rgba(88,166,255,0.60)' }}>.alphatekx.name.ng</span>
      </div>
    </div>
  );
}

/* ─── Terminal demo ───────────────────────────────────────── */
const LINES = [
  { text: '$ drop ./my-portfolio  →  AlphaTekx',    color: '#c9d1d9', delay: 0    },
  { text: '  ✓ Scanning for exposed secrets…',       color: '#8b949e', delay: 700  },
  { text: '  ⚠  Found: API_KEY hardcoded on ln 12',  color: '#f0883e', delay: 1400 },
  { text: '  ✓ Auto-fixed → process.env.API_KEY',    color: '#7ee787', delay: 2100 },
  { text: '  ✓ Uploading 23 files to edge network…', color: '#8b949e', delay: 2800 },
  { text: '  ✓ SSL ready · CDN active',              color: '#8b949e', delay: 3500 },
  { text: '',                                        color: '',         delay: 3900 },
  { text: '  🚀  LIVE → my-portfolio.alphatekx.name.ng', color: '#58a6ff', delay: 4300 },
  { text: '  ⏱   Total: 47 seconds',                color: '#a5b4fc', delay: 4900 },
];

function TerminalDemo() {
  const [shown, setShown] = useState(0);
  const [cursor, setCursor] = useState(true);
  const { ref, visible } = useInView(0.2);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isLive = shown >= LINES.length;

  useEffect(() => {
    if (!visible) return;
    let cancelled = false;
    function next(i: number) {
      if (cancelled || i >= LINES.length) {
        timer.current = setTimeout(() => { if (!cancelled) { setShown(0); next(0); } }, 2800);
        return;
      }
      const wait = i === 0 ? 400 : LINES[i].delay - LINES[i - 1].delay;
      timer.current = setTimeout(() => { if (!cancelled) { setShown(i + 1); next(i + 1); } }, wait);
    }
    next(0);
    const curIv = setInterval(() => setCursor(c => !c), 530);
    return () => { cancelled = true; if (timer.current) clearTimeout(timer.current); clearInterval(curIv); };
  }, [visible]);

  return (
    <div ref={ref} className="rounded-2xl overflow-hidden font-mono text-xs w-full"
      style={{ background: 'rgba(3,7,17,0.92)', border: '1px solid rgba(88,166,255,0.18)', boxShadow: '0 24px 80px rgba(0,0,0,0.60)' }}>
      {/* Title bar */}
      <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.02)' }}>
        <div className="flex gap-1.5">
          {['rgba(248,81,73,0.7)', 'rgba(227,179,65,0.7)', 'rgba(126,231,135,0.7)'].map((c, i) => (
            <div key={i} className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />
          ))}
        </div>
        <div className="flex-1 flex justify-center">
          <span className="text-[11px]" style={{ color: 'rgba(139,148,158,0.40)' }}>alphatekx — terminal</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full" style={{ background: isLive ? '#7ee787' : '#f0883e', boxShadow: isLive ? '0 0 5px #7ee787' : '0 0 5px #f0883e' }} />
          <span className="text-[10px] font-bold" style={{ color: isLive ? '#7ee787' : '#f0883e' }}>{isLive ? 'LIVE' : 'DEPLOYING'}</span>
        </div>
      </div>
      {/* Lines */}
      <div className="p-5 flex flex-col gap-1.5" style={{ minHeight: 200 }}>
        {LINES.slice(0, shown).map((l, i) => (
          <div key={i} style={{ animation: 'fadeInUp 0.22s ease both' }}>
            <span style={{ color: l.color || 'transparent', whiteSpace: 'pre' }}>{l.text || '\u00A0'}</span>
          </div>
        ))}
        {shown < LINES.length && (
          <div className="flex items-center gap-1" style={{ color: '#c9d1d9' }}>
            <span>{LINES[shown]?.text?.slice(0, 2) ?? '$ '}</span>
            <span className="inline-block w-[7px] h-[14px] rounded-sm ml-0.5"
              style={{ background: cursor ? '#58a6ff' : 'transparent', transition: 'background 0.1s' }} />
          </div>
        )}
      </div>
      <style>{`
        @keyframes fadeInUp { from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:none} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
      `}</style>
    </div>
  );
}

/* ─── Pipeline step card (animated) ──────────────────────── */
const STEPS = [
  { icon: Lock,         label: 'Claim your address',    detail: 'yourname.alphatekx.name.ng is reserved',    color: '#58a6ff' },
  { icon: CloudUpload,  label: 'Drop your files',        detail: 'HTML · CSS · JS · React builds — any stack', color: '#a5b4fc' },
  { icon: Shield,       label: 'Guardian scans & fixes', detail: 'Secrets auto-patched · 0 vulnerabilities',   color: '#7ee787' },
  { icon: Rocket,       label: 'Your site goes live',    detail: 'Permanent URL · HTTPS · Global CDN',          color: '#f0883e' },
];

function PipelinePreview() {
  const [active, setActive] = useState(0);
  const [done, setDone]     = useState<number[]>([]);
  const { ref, visible }    = useInView();

  useEffect(() => {
    if (!visible) return;
    let i = 0;
    const iv = setInterval(() => {
      setActive(i);
      if (i > 0) setDone(d => [...d, i - 1]);
      i++;
      if (i >= STEPS.length) setTimeout(() => { setActive(0); setDone([]); i = 0; }, 1600);
    }, 1500);
    return () => clearInterval(iv);
  }, [visible]);

  return (
    <div ref={ref} className="rounded-2xl overflow-hidden"
      style={{ background: 'rgba(7,14,31,0.90)', border: '1px solid rgba(88,166,255,0.14)' }}>
      {/* Chrome bar */}
      <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: '1px solid rgba(88,166,255,0.08)', background: 'rgba(4,10,24,0.70)' }}>
        <div className="flex gap-1.5">
          {['rgba(248,81,73,0.6)', 'rgba(227,179,65,0.6)', 'rgba(126,231,135,0.6)'].map((c, i) => (
            <div key={i} className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />
          ))}
        </div>
        <div className="flex-1 flex justify-center">
          <div className="flex items-center gap-2 px-3 py-1 rounded-md"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#7ee787' }} />
            <span className="text-xs font-mono" style={{ color: 'rgba(139,148,158,0.55)' }}>AlphaTekx Deployment Pipeline</span>
          </div>
        </div>
      </div>
      {/* Steps */}
      <div className="p-5 flex flex-col gap-2.5">
        {STEPS.map((step, i) => {
          const Icon = step.icon;
          const isActive = active === i;
          const isDone   = done.includes(i);
          return (
            <div key={i} className="flex items-center gap-3 rounded-xl px-4 py-3 transition-all duration-500"
              style={{
                background: isActive ? `${step.color}10` : isDone ? 'rgba(126,231,135,0.04)' : 'rgba(255,255,255,0.015)',
                border: `1px solid ${isActive ? step.color + '30' : isDone ? 'rgba(126,231,135,0.15)' : 'rgba(255,255,255,0.04)'}`,
              }}>
              <div className="shrink-0 w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-400"
                style={{
                  background: isDone ? 'rgba(126,231,135,0.12)' : isActive ? `${step.color}18` : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${isDone ? 'rgba(126,231,135,0.30)' : isActive ? step.color + '40' : 'rgba(255,255,255,0.06)'}`,
                }}>
                {isDone
                  ? <CheckCircle2 className="w-4 h-4" style={{ color: '#7ee787' }} />
                  : <Icon className={`w-4 h-4 ${isActive ? 'animate-pulse' : ''}`} style={{ color: isActive ? step.color : 'rgba(139,148,158,0.25)' }} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate"
                  style={{ color: isActive ? '#f0f6fc' : isDone ? 'rgba(201,209,217,0.55)' : 'rgba(139,148,158,0.35)' }}>
                  {step.label}
                </p>
                <p className="text-xs truncate" style={{ color: 'rgba(139,148,158,0.35)' }}>{step.detail}</p>
              </div>
              {isDone && <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: 'rgba(126,231,135,0.12)', color: '#7ee787' }}>✓</span>}
              {isActive && (
                <div className="shrink-0 flex gap-1">
                  {[0, 1, 2].map(d => (
                    <div key={d} className="w-1.5 h-1.5 rounded-full animate-bounce"
                      style={{ background: step.color, animationDelay: `${d * 140}ms` }} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {/* Live result */}
        <div className="flex items-center gap-3 mt-1 px-4 py-2.5 rounded-xl transition-all duration-700"
          style={{
            background: done.length === 3 ? 'rgba(126,231,135,0.07)' : 'rgba(255,255,255,0.02)',
            border: `1px solid ${done.length === 3 ? 'rgba(126,231,135,0.25)' : 'rgba(255,255,255,0.04)'}`,
          }}>
          <div className="w-2 h-2 rounded-full shrink-0"
            style={{ background: done.length === 3 ? '#7ee787' : 'rgba(139,148,158,0.25)', boxShadow: done.length === 3 ? '0 0 8px #7ee787' : 'none' }} />
          <span className="text-xs font-mono flex-1 truncate"
            style={{ color: done.length === 3 ? '#7ee787' : 'rgba(139,148,158,0.25)' }}>
            {done.length === 3 ? 'https://my-portfolio.alphatekx.name.ng' : 'awaiting deployment…'}
          </span>
          {done.length === 3 && (
            <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full"
              style={{ background: 'rgba(126,231,135,0.15)', color: '#7ee787' }}>LIVE</span>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Security code scanner ───────────────────────────────── */
const CODE_LINES = [
  { text: 'const key = "sk_live_xYz789abcDEF";', bad: true  },
  { text: 'const openai = new OpenAI({',          bad: false },
  { text: '  apiKey: "sk-abc123def456",',          bad: true  },
  { text: '});',                                   bad: false },
  { text: 'app.listen(3000);',                     bad: false },
];

function SecurityScanner() {
  const [phase, setPhase] = useState<0 | 1 | 2>(0);
  const { ref, visible }  = useInView();

  const reset = useCallback(() => {
    setPhase(0);
    const t1 = setTimeout(() => setPhase(1), 900);
    const t2 = setTimeout(() => setPhase(2), 2400);
    const t3 = setTimeout(() => reset(), 5200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  useEffect(() => { if (visible) return reset(); }, [visible, reset]);

  return (
    <div ref={ref} className="rounded-2xl overflow-hidden font-mono text-xs"
      style={{ background: 'rgba(7,14,31,0.90)', border: '1px solid rgba(126,231,135,0.14)' }}>
      <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <Terminal className="w-3.5 h-3.5 shrink-0" style={{ color: '#7ee787' }} />
        <span className="flex-1 text-[11px]" style={{ color: 'rgba(139,148,158,0.55)' }}>guardian-scan · app.js</span>
        {phase === 0 && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: 'rgba(139,148,158,0.08)', color: 'rgba(139,148,158,0.45)' }}>READY</span>}
        {phase === 1 && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse" style={{ background: 'rgba(240,136,62,0.15)', color: '#f0883e' }}>SCANNING…</span>}
        {phase === 2 && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: 'rgba(126,231,135,0.15)', color: '#7ee787' }}>SECURED ✓</span>}
      </div>
      <div className="p-4 flex flex-col gap-1">
        {CODE_LINES.map((l, i) => {
          const flagged = l.bad && phase >= 1;
          const fixed   = l.bad && phase === 2;
          return (
            <div key={i} className="flex items-center gap-2 px-2 py-1 rounded-md transition-all duration-500"
              style={{
                background: flagged && !fixed ? 'rgba(248,81,73,0.09)' : fixed ? 'rgba(126,231,135,0.07)' : 'transparent',
                border: flagged && !fixed ? '1px solid rgba(248,81,73,0.20)' : fixed ? '1px solid rgba(126,231,135,0.15)' : '1px solid transparent',
              }}>
              <span className="text-[10px] select-none tabular-nums w-4 shrink-0 text-right" style={{ color: 'rgba(139,148,158,0.25)' }}>{i + 1}</span>
              <span style={{ color: flagged && !fixed ? '#f85149' : fixed ? '#7ee787' : '#8b949e', flex: 1 }}>
                {fixed ? l.text.replace(/"[^"]{8,}"/g, 'process.env.SECRET_KEY') : l.text}
              </span>
              {flagged && !fixed && <span className="shrink-0 text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ background: 'rgba(248,81,73,0.15)', color: '#f85149' }}>EXPOSED</span>}
              {fixed && <span className="shrink-0 text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ background: 'rgba(126,231,135,0.12)', color: '#7ee787' }}>FIXED</span>}
            </div>
          );
        })}
      </div>
      {phase >= 1 && (
        <div className="px-4 pb-4">
          <div className="px-3 py-2 rounded-lg text-[11px]"
            style={{ background: phase === 2 ? 'rgba(126,231,135,0.07)' : 'rgba(248,81,73,0.07)', border: `1px solid ${phase === 2 ? 'rgba(126,231,135,0.15)' : 'rgba(248,81,73,0.15)'}`, color: phase === 2 ? '#7ee787' : '#f85149' }}>
            {phase === 2 ? '✓ 2 secrets auto-patched with env vars — site is safe to deploy' : '⚠  2 hardcoded secrets detected — auto-patching…'}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Pricing ─────────────────────────────────────────────── */
const PLANS = [
  {
    name: 'Starter', price: '₦500', credits: 10, popular: false, color: '#58a6ff',
    features: ['10 deployments', 'Guardian security scan', 'yourname.alphatekx.name.ng', 'Audit log', '24h support'],
  },
  {
    name: 'Pro', price: '₦2,000', credits: 50, popular: true, color: '#7ee787',
    features: ['50 deployments', 'Everything in Starter', 'Version history & rollback', 'Compliance rules', 'Priority support'],
  },
  {
    name: 'Enterprise', price: '₦5,000', credits: 150, popular: false, color: '#a5b4fc',
    features: ['150 deployments', 'Everything in Pro', 'Team collaboration', 'Runtime protection', 'Dedicated support'],
  },
];

/* ─── Main Page ───────────────────────────────────────────── */
export default function LandingPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  // Logged-in users skip landing and go to dashboard
  useEffect(() => {
    if (!loading && user) navigate('/dashboard', { replace: true });
  }, [user, loading, navigate]);

  return (
    <div className="min-h-screen w-full overflow-x-hidden" style={{ background: '#050d1a', color: '#e6edf3' }}>

      {/* ══ NAVBAR ══════════════════════════════════════════════ */}
      <nav className="sticky top-0 z-50 flex items-center justify-between px-4 md:px-10 h-14 shrink-0"
        style={{ background: 'rgba(5,13,26,0.88)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(88,166,255,0.08)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.28)' }}>
            <Shield className="w-3.5 h-3.5" style={{ color: '#58a6ff' }} />
          </div>
          <span className="text-sm font-black tracking-widest uppercase" style={{ color: '#f0f6fc' }}>AlphaTekx</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          {['How it works', 'Features', 'Security', 'Pricing'].map(t => (
            <button key={t} className="text-sm transition-colors hover:opacity-100"
              style={{ color: 'rgba(139,148,158,0.65)' }}>
              {t}
            </button>
          ))}
        </div>
        <button onClick={() => navigate('/login')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all hover:opacity-80"
          style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
          Get Started Free
        </button>
      </nav>

      {/* ══ HERO ════════════════════════════════════════════════ */}
      <section className="relative flex flex-col items-center justify-center text-center px-4 pt-20 pb-16 md:pt-28 md:pb-24 overflow-hidden">
        {/* Background orbs */}
        <div className="pointer-events-none absolute top-[-120px] left-1/2 -translate-x-1/2 rounded-full blur-3xl"
          style={{ width: 700, height: 700, background: 'radial-gradient(circle,rgba(37,99,235,0.18) 0%,transparent 70%)' }} />
        <div className="pointer-events-none absolute bottom-0 right-[-100px] rounded-full blur-3xl"
          style={{ width: 400, height: 400, background: 'radial-gradient(circle,rgba(16,185,129,0.10) 0%,transparent 70%)' }} />

        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8"
          style={{ background: 'rgba(88,166,255,0.07)', border: '1px solid rgba(88,166,255,0.20)' }}>
          <Zap className="w-3.5 h-3.5" style={{ color: '#58a6ff' }} />
          <span className="text-xs font-bold tracking-widest uppercase" style={{ color: '#58a6ff' }}>
            Deploy in 60 seconds · Free to start
          </span>
        </div>

        {/* Headline */}
        <h1 className="font-black text-balance leading-tight mb-6 relative z-10"
          style={{ fontSize: 'clamp(2.4rem,8vw,6.5rem)', letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
          Get your website<br />
          <G from="#58a6ff" to="#7ee787">live on the internet</G><br />
          in 60 seconds.
        </h1>

        {/* Sub-headline */}
        <p className="text-base md:text-xl text-pretty max-w-xl mx-auto mb-8 relative z-10"
          style={{ color: 'rgba(201,209,217,0.65)', lineHeight: 1.75 }}>
          Drop your HTML/CSS/JS files. AlphaTekx scans for security issues, fixes them automatically,
          and publishes your site to a{' '}
          <span style={{ color: '#7ee787' }}>yourname.alphatekx.name.ng</span>{' '}
          address — no server, no CLI, no setup.
        </p>

        {/* Animated subdomain preview */}
        <div className="relative z-10 w-full max-w-md mx-auto mb-8">
          <SubdomainPreview />
        </div>

        {/* CTAs */}
        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4 mb-10">
          <button onClick={() => navigate('/login')}
            className="flex items-center gap-2.5 px-8 py-4 rounded-2xl font-bold text-base transition-all hover:opacity-90 active:scale-[0.97]"
            style={{ background: 'linear-gradient(135deg,#1a56db,#2563eb)', color: '#e0e7ff', border: '1px solid rgba(88,166,255,0.40)', boxShadow: '0 4px 32px rgba(37,99,235,0.40)' }}>
            Deploy My Website Free <ArrowRight className="w-5 h-5" />
          </button>
          <button onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
            className="flex items-center gap-2 px-6 py-4 rounded-2xl font-semibold text-sm transition-all hover:opacity-80"
            style={{ color: 'rgba(201,209,217,0.65)', border: '1px solid rgba(255,255,255,0.10)', background: 'rgba(255,255,255,0.02)' }}>
            See how it works
          </button>
        </div>

        {/* Social proof strip */}
        <div className="relative z-10 grid grid-cols-2 md:flex md:flex-wrap items-center justify-center gap-x-8 gap-y-3">
          {[
            { val: '20,000+', lbl: 'sites deployed'      },
            { val: '< 60s',   lbl: 'average deploy time'  },
            { val: '100%',    lbl: 'auto-secured'         },
            { val: 'Free',    lbl: '20 starter credits'   },
          ].map(({ val, lbl }) => (
            <div key={lbl} className="flex items-baseline gap-2 justify-center">
              <span className="text-xl md:text-2xl font-black" style={{ color: '#58a6ff', letterSpacing: '-0.03em' }}>{val}</span>
              <span className="text-xs" style={{ color: 'rgba(139,148,158,0.50)' }}>{lbl}</span>
            </div>
          ))}
        </div>

        {/* Terminal demo */}
        <div className="relative z-10 mt-16 w-full max-w-2xl mx-auto">
          <TerminalDemo />
        </div>
      </section>

      {/* ══ LOGO STRIP ══════════════════════════════════════════ */}
      <div className="py-10 px-4 text-center"
        style={{ borderTop: '1px solid rgba(88,166,255,0.06)', borderBottom: '1px solid rgba(88,166,255,0.06)', background: 'rgba(88,166,255,0.015)' }}>
        <p className="text-xs font-semibold uppercase tracking-widest mb-6" style={{ color: 'rgba(139,148,158,0.30)' }}>
          Works with every stack
        </p>
        <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10 opacity-40">
          {[
            { name: 'React', letter: 'Re', color: '#61dafb' }, { name: 'Next.js', letter: 'N', color: '#fff' },
            { name: 'Stripe', letter: 'S', color: '#635bff' }, { name: 'Supabase', letter: 'SB', color: '#3ecf8e' },
            { name: 'Tailwind', letter: 'TW', color: '#38bdf8' }, { name: 'TypeScript', letter: 'TS', color: '#3178c6' },
            { name: 'GitHub', letter: 'GH', color: '#c9d1d9' }, { name: 'Vite', letter: 'V', color: '#a259ff' },
          ].map(({ name, letter, color }) => (
            <div key={name} className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-black shrink-0"
                style={{ background: `${color}18`, border: `1px solid ${color}28`, color }}>
                {letter}
              </div>
              <span className="text-xs font-semibold hidden sm:block" style={{ color: 'rgba(201,209,217,0.55)' }}>{name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ══ HOW IT WORKS ════════════════════════════════════════ */}
      <section id="how-it-works" className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="pointer-events-none absolute right-[-150px] top-0 rounded-full blur-3xl opacity-[0.08]"
          style={{ width: 600, height: 600, background: '#4f46e5' }} />
        <div className="max-w-6xl mx-auto relative z-10">
          <Reveal>
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6"
                style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.20)' }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#58a6ff' }} />
                <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: '#58a6ff' }}>How it works</span>
              </div>
              <h2 className="text-2xl md:text-5xl font-black text-balance mb-5" style={{ letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
                From files to <G from="#58a6ff" to="#7ee787">live website</G> in 4 steps
              </h2>
              <p className="text-base md:text-lg text-pretty max-w-xl mx-auto" style={{ color: '#8b949e', lineHeight: 1.75 }}>
                No commands to type. No config files to write. No server to manage.
                Just drop your code and watch it go live.
              </p>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            {/* Steps list */}
            <div className="flex flex-col gap-5">
              {[
                { num: '01', icon: Lock,        color: '#58a6ff', title: 'Pick your web address', desc: 'Choose a name like "my-portfolio" and it becomes yourname.alphatekx.name.ng — your permanent address on the internet.' },
                { num: '02', icon: CloudUpload,  color: '#a5b4fc', title: 'Drop your website files', desc: 'Upload a folder, paste a GitHub URL, or drag a ZIP file. Works with plain HTML, React builds, Vue apps — anything with an index.html.' },
                { num: '03', icon: Shield,       color: '#7ee787', title: 'Guardian auto-secures it', desc: 'AlphaTekx scans every file for exposed API keys, passwords, and secrets. Found issues are fixed automatically before the site goes live.' },
                { num: '04', icon: Rocket,       color: '#f0883e', title: 'Your site is live', desc: 'In under 60 seconds your website is publicly accessible at yourname.alphatekx.name.ng — shareable, permanent, and secure.' },
              ].map(({ num, icon: Icon, color, title, desc }, i) => (
                <Reveal key={num} delay={i * 80}>
                  <div className="flex items-start gap-4 p-5 rounded-2xl transition-all duration-300 hover:-translate-y-0.5"
                    style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)' }}>
                    <div className="shrink-0 w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm"
                      style={{ background: `linear-gradient(135deg,${color}cc,${color}55)`, color: '#030711' }}>
                      {num}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Icon className="w-4 h-4 shrink-0" style={{ color }} />
                        <p className="text-sm font-bold" style={{ color: '#f0f6fc' }}>{title}</p>
                      </div>
                      <p className="text-sm text-pretty leading-relaxed" style={{ color: '#8b949e' }}>{desc}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>

            {/* Animated pipeline */}
            <Reveal delay={100}>
              <PipelinePreview />
            </Reveal>
          </div>
        </div>
      </section>

      {/* ══ FEATURES ════════════════════════════════════════════ */}
      <section className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="pointer-events-none absolute left-[-150px] top-1/4 rounded-full blur-3xl opacity-[0.08]"
          style={{ width: 600, height: 600, background: '#0ea5e9' }} />
        <div className="max-w-6xl mx-auto relative z-10">
          <Reveal>
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6"
                style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.20)' }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#58a6ff' }} />
                <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: '#58a6ff' }}>Platform Features</span>
              </div>
              <h2 className="text-2xl md:text-5xl font-black text-balance mb-5" style={{ letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
                Everything you need,<br /><G from="#a5b4fc" to="#58a6ff">nothing you don't</G>
              </h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              { icon: CloudUpload, color: '#58a6ff', title: 'Zero-Config Deployment',  desc: 'Drop a folder, paste a GitHub URL, or upload a ZIP. No build commands, no config files — AlphaTekx figures everything out automatically.', span: 'md:col-span-2' },
              { icon: Shield,      color: '#7ee787', title: 'Automatic Security Scan', desc: 'Every file scanned for secrets, XSS, and vulnerabilities before going live. Issues fixed automatically.', span: '' },
              { icon: Zap,         color: '#f0883e', title: 'Sub-60s Live URL',        desc: 'Scan, fix, upload, and serve — fully parallelised. Faster than making a coffee.', span: '' },
              { icon: Globe,       color: '#a5b4fc', title: 'yourname.alphatekx.name.ng', desc: 'Every site gets a permanent branded subdomain. Share it, bookmark it, present it.', span: '' },
              { icon: Layers,      color: '#34d399', title: 'Version History',         desc: 'Every deployment saved. Roll back to any previous version in one click from your dashboard.', span: 'md:col-span-2' },
              { icon: Code2,       color: '#fb7185', title: 'Any Stack',               desc: 'Plain HTML, React, Vue, Angular, Svelte — if it has an index.html, it deploys.', span: '' },
            ].map(({ icon: Icon, color, title, desc, span }, i) => (
              <Reveal key={title} delay={i * 60}>
                <div className={`rounded-2xl p-6 flex flex-col gap-4 h-full transition-all duration-300 hover:-translate-y-0.5 ${span}`}
                  style={{ background: 'rgba(255,255,255,0.025)', backdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.07)' }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: `${color}12`, border: `1px solid ${color}28` }}>
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold mb-1.5" style={{ color: '#f0f6fc' }}>{title}</h3>
                    <p className="text-sm text-pretty leading-relaxed" style={{ color: '#8b949e' }}>{desc}</p>
                  </div>
                  <div className="mt-auto pt-3 flex items-center gap-1.5" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                    <div className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
                    <span className="text-xs font-semibold" style={{ color }}>Included in all plans</span>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══ SECURITY DEEP DIVE ══════════════════════════════════ */}
      <section className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="pointer-events-none absolute right-[-100px] top-0 rounded-full blur-3xl opacity-[0.09]"
          style={{ width: 600, height: 600, background: '#10b981' }} />
        <div className="max-w-6xl mx-auto relative z-10">
          <Reveal>
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6"
                style={{ background: 'rgba(126,231,135,0.08)', border: '1px solid rgba(126,231,135,0.20)' }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#7ee787' }} />
                <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: '#7ee787' }}>Guardian Security</span>
              </div>
              <h2 className="text-2xl md:text-5xl font-black text-balance mb-5" style={{ letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
                Your site is secured<br /><G from="#7ee787" to="#34d399">before it goes live</G>
              </h2>
              <p className="text-base md:text-lg text-pretty max-w-xl mx-auto" style={{ color: '#8b949e', lineHeight: 1.75 }}>
                Most developers accidentally leak secrets in their code. AlphaTekx catches and fixes them automatically — no embarrassing data breaches, no security audits.
              </p>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="flex flex-col gap-5">
              {[
                { icon: KeyRound, color: '#7ee787', title: 'Exposed secret detection',  desc: 'AWS keys, Stripe live keys, OpenAI tokens, GitHub PATs, private keys — all caught before a single byte touches the internet.' },
                { icon: Terminal, color: '#58a6ff', title: 'Instant auto-fix',           desc: 'Detected secrets are automatically replaced with environment variable references. No manual steps. No downtime.' },
                { icon: Wifi,     color: '#a5b4fc', title: '24/7 runtime protection',    desc: 'SQL injection, XSS, and DDoS blocked in real time. Self-healing rules fire without any action from you.' },
                { icon: Eye,      color: '#f0883e', title: 'Full audit trail',            desc: 'Every scan, fix, and deployment logged with timestamp. Immutable, searchable, always available.' },
              ].map(({ icon: Icon, color, title, desc }, i) => (
                <Reveal key={title} delay={i * 80}>
                  <div className="flex items-start gap-4 p-5 rounded-2xl transition-all duration-300 hover:-translate-y-0.5"
                    style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)' }}>
                    <div className="shrink-0 w-10 h-10 rounded-xl flex items-center justify-center mt-0.5"
                      style={{ background: `${color}14`, border: `1px solid ${color}28` }}>
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <div>
                      <p className="text-sm font-bold mb-1.5" style={{ color: '#f0f6fc' }}>{title}</p>
                      <p className="text-sm text-pretty leading-relaxed" style={{ color: '#8b949e' }}>{desc}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
            <Reveal delay={100}>
              <SecurityScanner />
            </Reveal>
          </div>
        </div>
      </section>

      {/* ══ STATS ═══════════════════════════════════════════════ */}
      <section className="py-16 px-4 md:px-8"
        style={{ borderTop: '1px solid rgba(88,166,255,0.07)', borderBottom: '1px solid rgba(88,166,255,0.07)', background: 'rgba(88,166,255,0.018)' }}>
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Rocket,    val: '20,000+', lbl: 'Sites Deployed',    color: '#58a6ff' },
              { icon: Users,     val: '5,000+',  lbl: 'Developers',        color: '#7ee787' },
              { icon: Activity,  val: '99.9%',   lbl: 'Platform Uptime',   color: '#a5b4fc' },
              { icon: Clock,     val: '< 60s',   lbl: 'Avg Deploy Time',   color: '#f0883e' },
            ].map(({ icon: Icon, val, lbl, color }, i) => (
              <Reveal key={lbl} delay={i * 80}>
                <div className="flex flex-col items-center gap-2 py-6 px-4 rounded-2xl text-center"
                  style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background: `${color}12`, border: `1px solid ${color}20` }}>
                    <Icon className="w-4 h-4" style={{ color }} />
                  </div>
                  <div className="text-2xl md:text-3xl font-black" style={{ color: '#f0f6fc', letterSpacing: '-0.04em' }}>{val}</div>
                  <div className="text-xs font-medium" style={{ color: '#8b949e' }}>{lbl}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══ COMPARISON ══════════════════════════════════════════ */}
      <section className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="max-w-5xl mx-auto relative z-10">
          <Reveal>
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6"
                style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.20)' }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#58a6ff' }} />
                <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: '#58a6ff' }}>Why AlphaTekx</span>
              </div>
              <h2 className="text-2xl md:text-5xl font-black text-balance mb-5" style={{ letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
                The only platform that<br /><G from="#58a6ff" to="#7ee787">does it all</G>
              </h2>
            </div>
          </Reveal>
          <Reveal delay={80}>
            <div className="rounded-2xl overflow-hidden"
              style={{ background: 'rgba(7,14,31,0.80)', backdropFilter: 'blur(28px)', border: '1px solid rgba(88,166,255,0.12)' }}>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[500px]">
                  <thead>
                    <tr style={{ borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
                      <th className="text-left px-6 py-4 text-xs font-black uppercase tracking-widest" style={{ color: 'rgba(139,148,158,0.45)', width: '40%' }}>Feature</th>
                      <th className="px-4 py-4 text-center" style={{ width: '20%' }}>
                        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full"
                          style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.25)' }}>
                          <Shield className="w-3 h-3" style={{ color: '#58a6ff' }} />
                          <span className="text-xs font-black" style={{ color: '#58a6ff' }}>AlphaTekx</span>
                        </div>
                      </th>
                      <th className="px-4 py-4 text-center text-xs font-semibold" style={{ color: 'rgba(139,148,158,0.40)', width: '20%' }}>Netlify</th>
                      <th className="px-4 py-4 text-center text-xs font-semibold" style={{ color: 'rgba(139,148,158,0.40)', width: '20%' }}>Vercel</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { feat: 'Zero-config deploy',        at: true,  nl: true,  vc: true  },
                      { feat: 'Sub-60s to live URL',        at: true,  nl: false, vc: false },
                      { feat: 'Automated secret scanning',  at: true,  nl: false, vc: false },
                      { feat: 'Auto-fix vulnerabilities',   at: true,  nl: false, vc: false },
                      { feat: 'No CLI required',            at: true,  nl: false, vc: false },
                      { feat: 'Custom subdomain on signup', at: true,  nl: true,  vc: true  },
                      { feat: 'Free starter credits',       at: true,  nl: false, vc: false },
                      { feat: 'Full audit trail',           at: true,  nl: false, vc: false },
                    ].map(({ feat, at, nl, vc }, i, arr) => (
                      <tr key={feat} style={{ borderBottom: i < arr.length - 1 ? '1px solid rgba(255,255,255,0.04)' : 'none', background: i % 2 === 0 ? 'rgba(255,255,255,0.012)' : 'transparent' }}>
                        <td className="px-6 py-3.5 text-sm font-medium" style={{ color: '#c9d1d9' }}>{feat}</td>
                        {[at, nl, vc].map((has, j) => (
                          <td key={j} className="px-4 py-3.5 text-center">
                            {has
                              ? <span className="inline-flex items-center justify-center w-6 h-6 rounded-full" style={{ background: j === 0 ? 'rgba(126,231,135,0.12)' : 'rgba(126,231,135,0.06)' }}>
                                  <CheckCircle2 className="w-3.5 h-3.5" style={{ color: j === 0 ? '#7ee787' : 'rgba(126,231,135,0.45)' }} />
                                </span>
                              : <span style={{ color: 'rgba(248,81,73,0.40)', fontSize: '1rem' }}>✕</span>}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ══ TESTIMONIALS ════════════════════════════════════════ */}
      <section className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="pointer-events-none absolute right-[-100px] bottom-0 rounded-full blur-3xl opacity-[0.08]"
          style={{ width: 500, height: 500, background: '#7c3aed' }} />
        <div className="max-w-6xl mx-auto relative z-10">
          <Reveal>
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6"
                style={{ background: 'rgba(165,180,252,0.08)', border: '1px solid rgba(165,180,252,0.20)' }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#a5b4fc' }} />
                <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: '#a5b4fc' }}>Wall of Love</span>
              </div>
              <h2 className="text-2xl md:text-5xl font-black text-balance" style={{ letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
                Developers who shipped <G from="#a5b4fc" to="#7ee787">faster</G>
              </h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            {[
              { name: 'Emeka Okafor', role: 'Frontend Engineer', co: 'Paystack', initials: 'EO', color: '#58a6ff', stars: 5, text: 'I dropped my React build folder and had a live URL in 38 seconds. The Guardian scan caught a leaked Stripe API key I had completely forgotten about. Would have been a disaster without it.' },
              { name: 'Aisha Mohammed', role: 'CTO', co: 'BuildFast Labs', initials: 'AM', color: '#7ee787', stars: 5, text: 'We evaluated Vercel, Netlify, and AlphaTekx. AlphaTekx is the only one that combines instant deployment with automated security scanning in a single zero-config workflow. Not even close.' },
              { name: 'Chidi Nwachukwu', role: 'Bootcamp Director', co: 'AltSchool Africa', initials: 'CN', color: '#a5b4fc', stars: 5, text: '40 students deploy projects every week. AlphaTekx removed the "it works on my machine" problem entirely. The zero-configuration experience is exactly what learners need.' },
            ].map(({ name, role, co, initials, color, stars, text }, i) => (
              <Reveal key={name} delay={i * 80}>
                <div className={`rounded-2xl p-6 flex flex-col gap-4 transition-all duration-300 hover:-translate-y-0.5 ${i === 1 ? 'md:mt-6' : ''}`}
                  style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)' }}>
                  <div className="text-5xl leading-none select-none font-black" style={{ color: `${color}25`, fontFamily: 'Georgia,serif' }}>"</div>
                  <div className="flex gap-0.5 -mt-3">
                    {Array.from({ length: stars }).map((_, j) => <Star key={j} className="w-3.5 h-3.5" style={{ color: '#f0883e', fill: '#f0883e' }} />)}
                  </div>
                  <p className="text-sm text-pretty leading-relaxed flex-1" style={{ color: '#c9d1d9', lineHeight: 1.8 }}>{text}</p>
                  <div className="flex items-center gap-3 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xs font-black shrink-0"
                      style={{ background: `linear-gradient(135deg,${color}30,${color}18)`, color, border: `1px solid ${color}28` }}>
                      {initials}
                    </div>
                    <div>
                      <p className="text-sm font-bold" style={{ color: '#f0f6fc' }}>{name}</p>
                      <p className="text-xs" style={{ color: '#8b949e' }}>{role} · <span style={{ color }}>{co}</span></p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══ PRICING ═════════════════════════════════════════════ */}
      <section className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl opacity-[0.08]"
          style={{ width: 700, height: 700, background: '#6d28d9' }} />
        <div className="max-w-6xl mx-auto relative z-10">
          <Reveal>
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6"
                style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.20)' }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#58a6ff' }} />
                <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: '#58a6ff' }}>Pricing</span>
              </div>
              <h2 className="text-2xl md:text-5xl font-black text-balance mb-4" style={{ letterSpacing: '-0.04em', color: '#f0f6fc', lineHeight: 1.06 }}>
                Simple, <G from="#a5b4fc" to="#58a6ff">transparent</G> pricing
              </h2>
              <p className="text-base text-pretty max-w-md mx-auto" style={{ color: '#8b949e' }}>
                Start free with 20 credits on sign-up. No credit card required.
              </p>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PLANS.map(({ name, price, credits, popular, color, features }, i) => (
              <Reveal key={name} delay={i * 80}>
                <div className={`relative rounded-2xl p-7 flex flex-col gap-6 h-full transition-all duration-300 hover:-translate-y-1 ${popular ? 'ring-1' : ''}`}
                  style={{
                    background: popular ? 'rgba(126,231,135,0.06)' : 'rgba(255,255,255,0.025)',
                    border: `1px solid ${popular ? 'rgba(126,231,135,0.30)' : 'rgba(255,255,255,0.07)'}`,
                    boxShadow: popular ? '0 0 0 1px rgba(126,231,135,0.30)' : undefined,
                  }}>
                  {popular && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest"
                      style={{ background: 'linear-gradient(135deg,#7ee787,#34d399)', color: '#030711' }}>
                      Most Popular
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-black uppercase tracking-widest mb-1" style={{ color }}>{name}</p>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-4xl font-black" style={{ color: '#f0f6fc', letterSpacing: '-0.04em' }}>{price}</span>
                      <span className="text-sm" style={{ color: '#8b949e' }}>/ top-up</span>
                    </div>
                    <p className="text-xs mt-1" style={{ color }}>Includes {credits} deployments</p>
                  </div>
                  <div className="flex flex-col gap-2.5 flex-1">
                    {features.map(f => (
                      <div key={f} className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" style={{ color }} />
                        <span className="text-sm" style={{ color: '#c9d1d9' }}>{f}</span>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => navigate('/login')}
                    className="w-full py-3 rounded-xl text-sm font-bold transition-all hover:opacity-80 active:scale-[0.97]"
                    style={{
                      background: popular ? `linear-gradient(135deg,${color}cc,${color}88)` : `${color}14`,
                      color: popular ? '#030711' : color,
                      border: `1px solid ${color}40`,
                    }}>
                    Get started
                  </button>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={200}>
            <p className="text-center text-xs mt-8" style={{ color: 'rgba(139,148,158,0.40)' }}>
              All plans start with 20 free credits on sign-up · No credit card required · Cancel anytime
            </p>
          </Reveal>
        </div>
      </section>

      {/* ══ FINAL CTA ═══════════════════════════════════════════ */}
      <section className="py-24 px-4 md:px-8 relative overflow-hidden">
        <div className="max-w-5xl mx-auto">
          <Reveal>
            <div className="relative rounded-3xl overflow-hidden p-8 md:p-16 text-center"
              style={{
                background: 'linear-gradient(135deg,rgba(26,86,219,0.26) 0%,rgba(109,40,217,0.22) 50%,rgba(16,185,129,0.14) 100%)',
                border: '1px solid rgba(88,166,255,0.20)',
                boxShadow: '0 0 120px rgba(37,99,235,0.20), 0 40px 100px rgba(0,0,0,0.50)',
              }}>
              <div className="pointer-events-none absolute rounded-full blur-3xl opacity-40" style={{ background: '#2563eb', width: 480, height: 480, top: -80, left: -80 }} />
              <div className="pointer-events-none absolute rounded-full blur-3xl opacity-25" style={{ background: '#7c3aed', width: 380, height: 380, bottom: -60, right: -60 }} />
              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8"
                  style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.28)' }}>
                  <Zap className="w-3.5 h-3.5" style={{ color: '#58a6ff' }} />
                  <span className="text-xs font-bold tracking-widest uppercase" style={{ color: '#58a6ff' }}>Join 5,000+ developers</span>
                </div>
                <h2 className="font-black text-balance mb-6"
                  style={{ fontSize: 'clamp(1.9rem,6vw,5rem)', letterSpacing: '-0.045em', lineHeight: 1.06, color: '#f0f6fc' }}>
                  Your website.<br />
                  <G from="#58a6ff" to="#7ee787">Live in 60 seconds.</G>
                </h2>
                <p className="text-base md:text-xl text-pretty max-w-xl mx-auto mb-10" style={{ color: 'rgba(201,209,217,0.65)', lineHeight: 1.8 }}>
                  Sign in with Google. Choose a name. Drop your files.
                  Your site is live at <span style={{ color: '#7ee787', fontFamily: 'monospace' }}>yourname.alphatekx.name.ng</span> before you finish reading this sentence.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
                  <button onClick={() => navigate('/login')}
                    className="flex items-center gap-2.5 px-10 py-4 rounded-2xl font-bold transition-all hover:opacity-90 active:scale-[0.97]"
                    style={{ background: 'linear-gradient(135deg,#1a56db,#2563eb)', color: '#e0e7ff', border: '1px solid rgba(88,166,255,0.45)', fontSize: '1.05rem', boxShadow: '0 4px 32px rgba(37,99,235,0.45)' }}>
                    Start Deploying — It's Free <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-6">
                  {[
                    { icon: CheckCircle2, label: 'No credit card'  },
                    { icon: Zap,          label: 'Live in 60s'      },
                    { icon: Shield,       label: 'Auto-secured'     },
                    { icon: RefreshCw,    label: 'Free rollback'    },
                  ].map(({ icon: Icon, label }) => (
                    <div key={label} className="flex items-center gap-1.5">
                      <Icon className="w-3.5 h-3.5" style={{ color: '#7ee787' }} />
                      <span className="text-xs font-medium" style={{ color: 'rgba(139,148,158,0.60)' }}>{label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ══ FOOTER ══════════════════════════════════════════════ */}
      <footer className="pb-12 pt-16 px-4 md:px-8" style={{ borderTop: '1px solid rgba(88,166,255,0.07)' }}>
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-10 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                  style={{ background: 'linear-gradient(135deg,rgba(88,166,255,0.22),rgba(165,180,252,0.22))', border: '1px solid rgba(88,166,255,0.35)' }}>
                  <Shield className="w-4 h-4" style={{ color: '#58a6ff' }} />
                </div>
                <span className="text-sm font-black tracking-widest uppercase" style={{ color: '#f0f6fc' }}>AlphaTekx</span>
              </div>
              <p className="text-sm text-pretty leading-relaxed mb-6 max-w-xs" style={{ color: 'rgba(139,148,158,0.65)' }}>
                Get your website live on the internet in 60 seconds. No server. No CLI. Just drop and go.
              </p>
              <div className="flex items-center gap-2.5">
                {([
                  { Icon: Twitter, label: 'twitter' }, { Icon: Github, label: 'github' }, { Icon: Linkedin, label: 'linkedin' },
                ] as { Icon: React.ElementType; label: string }[]).map(({ Icon, label }) => (
                  <a key={label} href="#"
                    className="w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:opacity-80"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: 'rgba(139,148,158,0.65)' }}>
                    <Icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>
            {[
              { heading: 'Product', links: ['Features', 'Security', 'Pricing', 'Changelog'] },
              { heading: 'Company', links: ['About', 'Blog', 'Careers', 'Contact'] },
              { heading: 'Legal',   links: ['Terms of Service', 'Privacy Policy', 'Security'] },
            ].map(({ heading, links }) => (
              <div key={heading}>
                <p className="text-xs font-black uppercase tracking-widest mb-5" style={{ color: 'rgba(139,148,158,0.45)' }}>{heading}</p>
                <div className="flex flex-col gap-3">
                  {links.map(l => (
                    <button key={l} className="text-sm text-left transition-colors hover:opacity-100"
                      style={{ color: 'rgba(139,148,158,0.60)' }}>{l}</button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8"
            style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
            <p className="text-xs" style={{ color: 'rgba(139,148,158,0.35)' }}>© 2026 AlphaTekx · alphatekx.name.ng · All rights reserved</p>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full"
              style={{ background: 'rgba(126,231,135,0.06)', border: '1px solid rgba(126,231,135,0.14)' }}>
              <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#7ee787' }} />
              <span className="text-xs font-medium" style={{ color: 'rgba(126,231,135,0.70)' }}>All systems operational</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
