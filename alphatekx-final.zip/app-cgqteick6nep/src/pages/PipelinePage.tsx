import { useState, useEffect, useCallback, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Shield, Wrench, Rocket, CheckCircle2, AlertTriangle,
  Copy, Check, Share2, ArrowLeft, ExternalLink, Loader2,
  LayoutDashboard, Download, Zap, GitBranch, Bug,
  Monitor, Tablet, Smartphone, RefreshCw, Globe,
} from 'lucide-react';
import { downloadProductionZip } from '@/utils/downloadZip';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import TopUpModal from '@/components/TopUpModal';

/* ══════════════════════════════════════════════════════════════════
   TYPES
══════════════════════════════════════════════════════════════════ */
type ParallelStatus = 'idle' | 'running' | 'done' | 'warn' | 'error';

function sleep(ms: number) { return new Promise<void>(r => setTimeout(r, ms)); }

/* ══════════════════════════════════════════════════════════════════
   PARALLEL STAGE CARD
══════════════════════════════════════════════════════════════════ */
interface ParallelCardProps {
  icon: React.ElementType;
  title: string;
  subtitle: string;
  status: ParallelStatus;
  tags?: string[];
}

function ParallelCard({ icon: Icon, title, subtitle, status, tags }: ParallelCardProps) {
  const colors = {
    idle:    { border: 'rgba(88,166,255,0.08)',  icon: 'rgba(88,166,255,0.25)',  bg: 'rgba(88,166,255,0.04)' },
    running: { border: 'rgba(88,166,255,0.30)',  icon: '#58a6ff',               bg: 'rgba(88,166,255,0.08)' },
    done:    { border: 'rgba(126,231,135,0.30)', icon: '#7ee787',               bg: 'rgba(74,168,110,0.10)' },
    warn:    { border: 'rgba(227,179,65,0.35)',  icon: '#e3b341',               bg: 'rgba(227,179,65,0.08)' },
    error:   { border: 'rgba(248,81,73,0.30)',   icon: '#f85149',               bg: 'rgba(248,81,73,0.08)' },
  };
  const c = colors[status];

  return (
    <div className="flex-1 rounded-2xl overflow-hidden transition-all duration-500"
      style={{ background: 'rgba(7,14,31,0.80)', border: `1px solid ${c.border}`, opacity: status === 'idle' ? 0.45 : 1 }}>
      {status === 'running' && (
        <div className="relative h-0.5 w-full overflow-hidden" style={{ background: 'rgba(88,166,255,0.06)' }}>
          <div className="absolute inset-y-0 w-1/2 anim-indeterminate"
            style={{ background: 'linear-gradient(90deg,transparent,#58a6ff,transparent)' }} />
        </div>
      )}
      {(status === 'done' || status === 'warn') && (
        <div className="h-0.5 w-full"
          style={{ background: status === 'warn' ? 'rgba(227,179,65,0.60)' : 'rgba(126,231,135,0.55)' }} />
      )}

      <div className="p-4 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300"
            style={{ background: c.bg, border: `1px solid ${c.border}` }}>
            {status === 'running' ? <Loader2 className="w-4 h-4 animate-spin" style={{ color: c.icon }} />
            : status === 'done'   ? <CheckCircle2 className="w-4 h-4 anim-check-pop" style={{ color: c.icon }} />
            : status === 'warn'   ? <AlertTriangle className="w-4 h-4" style={{ color: c.icon }} />
            : <Icon className="w-4 h-4" style={{ color: c.icon }} />}
          </div>
          <span className="text-xs font-bold truncate" style={{ color: status === 'idle' ? 'rgba(139,148,158,0.50)' : '#e6edf3' }}>{title}</span>
        </div>
        <p className="text-[11px] leading-snug text-pretty" style={{ color: '#8b949e' }}>{subtitle}</p>
        {tags && tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-0.5">
            {tags.map(t => (
              <span key={t} className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full"
                style={{ background: 'rgba(248,81,73,0.10)', color: '#f85149', border: '1px solid rgba(248,81,73,0.20)' }}>
                {t}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   MANUAL REVIEW BANNER
══════════════════════════════════════════════════════════════════ */
function ManualReviewBanner({ flags }: { flags: string[] }) {
  if (!flags.length) return null;
  return (
    <div className="rounded-xl px-4 py-3 flex items-start gap-3 anim-fade-in"
      style={{ background: 'rgba(227,179,65,0.07)', border: '1px solid rgba(227,179,65,0.28)' }}>
      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#e3b341' }} />
      <div>
        <p className="text-xs font-bold" style={{ color: '#e3b341' }}>Manual Review Needed</p>
        <p className="text-xs mt-0.5 text-pretty" style={{ color: 'rgba(227,179,65,0.75)' }}>
          {flags.length === 1
            ? `1 issue could not be auto-fixed: ${flags[0]}`
            : `${flags.length} issues require manual review: ${flags.join(', ')}`}
          . Your site is live marked as <strong style={{ color: '#e3b341' }}>Caution: Partial Security</strong>.
        </p>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   SUCCESS VIEW
══════════════════════════════════════════════════════════════════ */
interface SuccessViewProps {
  liveUrl: string;   // serve-site proxy URL for assets (CSS/JS)
  viewUrl: string;   // /live/:subdomain route – shareable live link
  publicUrl: string; // branded display URL (subdomain.alphatekx.name.ng)
  elapsed: number;
  securityScore: number;
  manualFlags: string[];
  fixedIssues: string[];
}

type DeviceMode = 'desktop' | 'tablet' | 'mobile';

const DEVICE_WIDTHS: Record<DeviceMode, string> = {
  desktop: '100%',
  tablet:  '768px',
  mobile:  '390px',
};

function SuccessView({ liveUrl, viewUrl, publicUrl, elapsed, securityScore, manualFlags, fixedIssues }: SuccessViewProps) {
  const navigate    = useNavigate();
  const iframeRef   = useRef<HTMLIFrameElement>(null);
  const blobUrlRef  = useRef('');
  const [copied,      setCopied]      = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [device,      setDevice]      = useState<DeviceMode>('desktop');
  const [iframeKey,   setIframeKey]   = useState(0);
  const [iframeState, setIframeState] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [iframeSrc,   setIframeSrc]   = useState('');
  const isCaution  = manualFlags.length > 0;
  const scoreColor = securityScore >= 80 ? '#7ee787' : securityScore >= 60 ? '#e3b341' : '#f85149';
  const accentColor = isCaution ? '#e3b341' : '#7ee787';

  // subdomain is now passed directly as the plain name (no URL wrapping)
  const subdomain = publicUrl.replace(/^https?:\/\//, '').replace(/\.alphatekx\.name\.ng.*$/, '').split('.')[0] ?? '';

  // Build Blob URL for the preview iframe (Supabase Edge Functions force sandbox CSP on text/html;
  // blob: URLs are not subject to that restriction so scripts/styles work correctly)
  useEffect(() => {
    if (!liveUrl) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(liveUrl, { signal: AbortSignal.timeout(15_000) });
        if (!res.ok) { setIframeState('error'); return; }
        const html = await res.text();

        // Rewrite relative asset URLs to absolute serve-site proxy URLs
        const base = liveUrl.replace(/\/[^/]+$/, ''); // strip filename
        const rewritten = html
          .replace(/(href|src)="(?!https?:\/\/|\/\/|data:|blob:|#)([^"]+)"/gi,
            (_, attr, path) => `${attr}="${base}/${path.replace(/^\.\//, '')}"`)
          .replace(/(href|src)='(?!https?:\/\/|\/\/|data:|blob:|#)([^']+)'/gi,
            (_, attr, path) => `${attr}='${base}/${path.replace(/^\.\//, '')}'`);

        if (cancelled) return;
        if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current);
        const blob = new Blob([rewritten], { type: 'text/html; charset=utf-8' });
        const url  = URL.createObjectURL(blob);
        blobUrlRef.current = url;
        setIframeSrc(url);
      } catch {
        if (!cancelled) setIframeState('error');
      }
    })();
    return () => { cancelled = true; };
  }, [liveUrl, iframeKey]);

  useEffect(() => () => { if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current); }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(viewUrl).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2200); });
  };
  const handleShare = () => {
    if (navigator.share) navigator.share({ title: 'My AlphaTekx deployment', url: viewUrl }).catch(() => null);
    else handleCopy();
  };
  const handleDownload = async () => {
    setDownloading(true);
    try { await downloadProductionZip(subdomain); }
    finally { setTimeout(() => setDownloading(false), 1200); }
  };
  const handleRefresh = () => {
    setIframeState('loading');
    setIframeSrc('');
    setIframeKey(k => k + 1);
  };

  const deviceButtons: { mode: DeviceMode; Icon: React.ElementType; label: string }[] = [
    { mode: 'desktop', Icon: Monitor,    label: 'Desktop' },
    { mode: 'tablet',  Icon: Tablet,     label: 'Tablet'  },
    { mode: 'mobile',  Icon: Smartphone, label: 'Mobile'  },
  ];

  return (
    <div className="w-full flex flex-col gap-4 anim-fade-up">

      {/* ══ LIVE BANNER ══════════════════════════════════════════ */}
      <div className="flex items-center gap-3 px-4 py-3 rounded-2xl flex-wrap gap-y-2"
        style={{
          background: isCaution ? 'rgba(227,179,65,0.06)' : 'rgba(74,168,110,0.07)',
          border: `1px solid ${isCaution ? 'rgba(227,179,65,0.30)' : 'rgba(126,231,135,0.30)'}`,
        }}>
        <div className="flex items-center gap-2 shrink-0">
          {isCaution
            ? <AlertTriangle className="w-5 h-5" style={{ color: accentColor }} />
            : <CheckCircle2 className="w-5 h-5 anim-check-pop" style={{ color: accentColor }} />}
          <span className="text-sm font-bold" style={{ color: accentColor }}>
            {isCaution ? 'Live — Partial Security' : 'Deployment Successful'}
          </span>
        </div>
        <div className="flex-1 min-w-0" />
        {/* Score pill */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full shrink-0"
          style={{ background: `${scoreColor}18`, border: `1px solid ${scoreColor}44` }}>
          <Shield className="w-3 h-3" style={{ color: scoreColor }} />
          <span className="text-xs font-black" style={{ color: scoreColor }}>{securityScore}/100</span>
        </div>
      </div>

      {/* ══ BROWSER CHROME ═══════════════════════════════════════ */}
      <div className="rounded-2xl overflow-hidden w-full"
        style={{
          background: 'rgba(7,14,31,0.95)',
          border: '1px solid rgba(88,166,255,0.18)',
          boxShadow: '0 8px 48px rgba(0,0,0,0.50)',
        }}>

        {/* Chrome top bar */}
        <div className="flex items-center gap-2 px-3 py-2.5"
          style={{ background: 'rgba(4,10,24,0.90)', borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
          {/* Traffic lights */}
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="w-3 h-3 rounded-full" style={{ background: 'rgba(248,81,73,0.65)' }} />
            <div className="w-3 h-3 rounded-full" style={{ background: 'rgba(227,179,65,0.65)' }} />
            <div className="w-3 h-3 rounded-full" style={{ background: 'rgba(126,231,135,0.65)' }} />
          </div>

          {/* Address bar */}
          <div className="flex-1 min-w-0 flex items-center gap-2 mx-2 px-3 py-1.5 rounded-lg"
            style={{ background: 'rgba(14,22,44,0.80)', border: '1px solid rgba(88,166,255,0.14)' }}>
            <Globe className="w-3 h-3 shrink-0" style={{ color: accentColor }} />
            <span className="flex-1 min-w-0 text-xs font-mono truncate" style={{ color: '#c9d1d9' }}>
              {publicUrl}.alphatekx.name.ng
            </span>
            {iframeState === 'loaded' && (
              <div className="shrink-0 flex items-center gap-1 px-1.5 py-0.5 rounded"
                style={{ background: 'rgba(126,231,135,0.12)' }}>
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#7ee787' }} />
                <span className="text-[9px] font-bold" style={{ color: '#7ee787' }}>LIVE</span>
              </div>
            )}
          </div>

          {/* Device toggle + actions */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Device switcher — hidden on mobile (not enough space) */}
            <div className="hidden md:flex items-center gap-0.5 p-0.5 rounded-lg mr-1"
              style={{ background: 'rgba(88,166,255,0.06)', border: '1px solid rgba(88,166,255,0.12)' }}>
              {deviceButtons.map(({ mode, Icon, label }) => (
                <button key={mode} title={label} onClick={() => setDevice(mode)}
                  className="p-1.5 rounded-md transition-all duration-150"
                  style={{
                    background: device === mode ? 'rgba(88,166,255,0.18)' : 'transparent',
                    color:      device === mode ? '#58a6ff' : 'rgba(139,148,158,0.45)',
                  }}>
                  <Icon className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>
            <button title="Refresh preview" onClick={handleRefresh}
              className="p-1.5 rounded-lg transition-colors hover:bg-white/5"
              style={{ color: 'rgba(139,148,158,0.55)' }}>
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <a href={viewUrl} target="_blank" rel="noreferrer" title="Open in new tab"
              className="p-1.5 rounded-lg transition-colors hover:bg-white/5"
              style={{ color: 'rgba(139,148,158,0.55)' }}>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* ── iframe viewport — shorter on mobile ── */}
        <div className="relative overflow-hidden flex justify-center"
          style={{ background: '#ffffff', height: device === 'desktop' ? '420px' : '360px' }}>

          {/* Center wrapper constrains width for tablet/mobile */}
          <div className="h-full transition-all duration-300 overflow-hidden"
            style={{ width: DEVICE_WIDTHS[device], maxWidth: '100%' }}>
            <iframe
              key={iframeKey}
              ref={iframeRef}
              src={iframeSrc}
              title="Live preview"
              className="w-full h-full border-0"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"
              onLoad={() => { if (iframeSrc) setIframeState('loaded'); }}
              onError={() => setIframeState('error')}
            />
          </div>

          {/* Loading overlay */}
          {iframeState === 'loading' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3"
              style={{ background: 'rgba(5,13,26,0.88)', backdropFilter: 'blur(6px)' }}>
              <Loader2 className="w-7 h-7 animate-spin" style={{ color: '#58a6ff' }} />
              <p className="text-sm font-medium" style={{ color: '#8b949e' }}>Loading preview…</p>
            </div>
          )}

          {/* Error / blocked overlay */}
          {iframeState === 'error' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center"
              style={{ background: 'rgba(5,13,26,0.92)' }}>
              <Globe className="w-10 h-10" style={{ color: 'rgba(88,166,255,0.35)' }} />
              <p className="text-sm font-semibold" style={{ color: '#c9d1d9' }}>Preview blocked by browser</p>
              <p className="text-xs text-pretty" style={{ color: '#8b949e' }}>
                Your site is live — open it directly to see it in full.
              </p>
              <a href={viewUrl} target="_blank" rel="noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-colors"
                style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.28)', color: '#58a6ff' }}>
                <ExternalLink className="w-3.5 h-3.5" /> Open My Site
              </a>
            </div>
          )}
        </div>

        {/* Chrome status bar */}
        <div className="flex items-center gap-3 px-3 py-1.5"
          style={{ background: 'rgba(4,10,24,0.80)', borderTop: '1px solid rgba(88,166,255,0.08)' }}>
          <div className="flex items-center gap-4 flex-1">
            {[
              { label: 'Deploy',    value: `${elapsed}s`,             color: '#58a6ff' },
              { label: 'Fixed',     value: `${fixedIssues.length}`,   color: '#a5b4fc' },
              { label: 'Security',  value: `${securityScore}/100`,    color: scoreColor },
            ].map(({ label, value, color }) => (
              <div key={label} className="flex items-center gap-1">
                <span className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: 'rgba(139,148,158,0.40)' }}>{label}</span>
                <span className="text-[9px] font-black" style={{ color }}>{value}</span>
              </div>
            ))}
          </div>
          <span className="text-[9px] font-mono shrink-0" style={{ color: 'rgba(139,148,158,0.28)' }}>
            alphatekx/storage/v1
          </span>
        </div>
      </div>

      {/* ══ AUTO-HEAL + MANUAL REVIEW ════════════════════════════ */}
      {fixedIssues.length > 0 && (
        <div className="rounded-xl px-3 py-2 flex flex-wrap gap-1.5 anim-fade-in"
          style={{ background: 'rgba(165,180,252,0.05)', border: '1px solid rgba(165,180,252,0.15)' }}>
          <span className="text-[10px] font-bold w-full mb-0.5" style={{ color: '#a5b4fc' }}>Auto-Heal Applied:</span>
          {fixedIssues.map(f => (
            <span key={f} className="text-[10px] px-2 py-0.5 rounded-full"
              style={{ background: 'rgba(165,180,252,0.10)', color: '#a5b4fc', border: '1px solid rgba(165,180,252,0.20)' }}>
              {f} patched
            </span>
          ))}
        </div>
      )}
      {isCaution && <ManualReviewBanner flags={manualFlags} />}

      {/* ══ LIVE URL BLOCK ═══════════════════════════════════════ */}
      {/* Primary — always-working serve-site proxy */}
      <a href={viewUrl} target="_blank" rel="noreferrer"
        className="flex items-center gap-3 w-full px-4 py-3.5 rounded-xl transition-all duration-200 active:scale-[0.98] anim-fade-in"
        style={{ background: 'rgba(74,168,110,0.10)', border: '1px solid rgba(126,231,135,0.30)' }}>
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#7ee787' }} />
          <span className="text-xs font-black uppercase tracking-wider" style={{ color: '#7ee787' }}>Live</span>
        </div>
        <span className="flex-1 min-w-0 text-xs font-mono truncate" style={{ color: '#c9d1d9' }}>{viewUrl}</span>
        <ExternalLink className="w-3.5 h-3.5 shrink-0" style={{ color: '#7ee787' }} />
      </a>
      {/* Secondary — branded address (display only) */}
      <div className="flex items-center gap-3 w-full px-4 py-2.5 rounded-xl"
        style={{ background: 'rgba(88,166,255,0.05)', border: '1px solid rgba(88,166,255,0.14)' }}>
        <Globe className="w-3.5 h-3.5 shrink-0" style={{ color: 'rgba(88,166,255,0.55)' }} />
        <span className="flex-1 min-w-0 text-xs font-mono truncate" style={{ color: 'rgba(139,148,158,0.65)' }}>{publicUrl}.alphatekx.name.ng</span>
        <span className="shrink-0 text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ background: 'rgba(88,166,255,0.10)', color: 'rgba(88,166,255,0.55)' }}>BRANDED</span>
      </div>

      {/* ══ QUICK ACTIONS ════════════════════════════════════════ */}
      <div className="flex gap-2 w-full">
        <button onClick={handleCopy}
          className="flex-1 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition-all duration-200 active:scale-[0.97]"
          style={{
            background: copied ? 'rgba(74,168,110,0.15)' : 'rgba(88,166,255,0.10)',
            border: `1px solid ${copied ? 'rgba(126,231,135,0.35)' : 'rgba(88,166,255,0.25)'}`,
            color: copied ? '#7ee787' : '#58a6ff',
          }}>
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied!' : 'Copy Link'}
        </button>
        <button onClick={handleShare}
          className="flex-1 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition-all duration-200 active:scale-[0.97]"
          style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
          <Share2 className="w-4 h-4" /> Share
        </button>
        <button onClick={handleDownload} disabled={downloading}
          className="flex-1 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition-all duration-200 active:scale-[0.97] disabled:opacity-60"
          style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.18)', color: '#8b949e' }}>
          {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          <span className="hidden md:inline">{downloading ? 'Downloading…' : 'Download'}</span>
        </button>
      </div>

      {/* ══ PRIMARY CTA ══════════════════════════════════════════ */}
      <button onClick={() => navigate('/dashboard')}
        className="w-full flex items-center justify-center gap-2 rounded-xl py-4 font-bold transition-all duration-200 active:scale-[0.98]"
        style={{
          background: 'linear-gradient(135deg,#1d4ed8,#2563eb)', color: '#e0e7ff',
          border: '1px solid rgba(88,166,255,0.30)', boxShadow: '0 4px 24px rgba(37,99,235,0.35)', fontSize: '1rem',
        }}>
        <LayoutDashboard className="w-4 h-4" /> See My Dashboard
      </button>

      <button onClick={() => navigate('/claim')}
        className="flex items-center justify-center gap-1.5 text-xs font-medium transition-colors w-full"
        style={{ color: 'rgba(139,148,158,0.45)' }}>
        <ArrowLeft className="w-3.5 h-3.5" /> Deploy another project
      </button>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   DEPLOY STEP CARD (sequential, after parallel phase)
══════════════════════════════════════════════════════════════════ */
function DeployCard({ status, narrative }: { status: ParallelStatus; narrative: string }) {
  const borderColor = status === 'done' ? 'rgba(126,231,135,0.30)' : status === 'running' ? 'rgba(88,166,255,0.30)' : status === 'error' ? 'rgba(248,81,73,0.30)' : 'rgba(88,166,255,0.08)';
  return (
    <div className="glass rounded-2xl overflow-hidden w-full transition-all duration-500"
      style={{ borderColor, opacity: status === 'idle' ? 0.40 : 1 }}>
      {status === 'running' && (
        <div className="relative h-0.5 w-full overflow-hidden" style={{ background: 'rgba(88,166,255,0.06)' }}>
          <div className="absolute inset-y-0 w-1/2 anim-indeterminate"
            style={{ background: 'linear-gradient(90deg,transparent,#58a6ff,transparent)' }} />
        </div>
      )}
      {status === 'done' && <div className="h-0.5 w-full" style={{ background: 'rgba(126,231,135,0.55)' }} />}
      <div className="flex items-center gap-4 p-5">
        <div className="shrink-0 w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: status === 'done' ? 'rgba(74,168,110,0.15)' : 'rgba(88,166,255,0.08)', border: `1px solid ${borderColor}` }}>
          {status === 'done'    ? <CheckCircle2 className="w-5 h-5 anim-check-pop" style={{ color: '#7ee787' }} />
          : status === 'running' ? <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#58a6ff' }} />
          : status === 'error'   ? <AlertTriangle className="w-5 h-5" style={{ color: '#f85149' }} />
          : <Rocket className="w-5 h-5" style={{ color: 'rgba(88,166,255,0.28)' }} />}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold" style={{ color: status === 'idle' ? 'rgba(139,148,158,0.50)' : '#e6edf3' }}>
            Speed-of-Light Delivery
          </p>
          <p className="text-sm text-pretty" style={{ color: '#8b949e' }}>
            {status === 'idle' ? 'Waiting for security phase…' : narrative}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   PIPELINE PAGE
══════════════════════════════════════════════════════════════════ */
export default function PipelinePage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { refreshCredits } = useAuth();

  const state = location.state as {
    subdomain?: string; url?: string; fileCount?: number; method?: string; files?: File[];
  } | null;

  // Stabilise refs so the pipeline useEffect never re-fires due to identity changes
  const subdomainRef   = useRef(state?.subdomain ?? '');
  const deployUrlRef   = useRef(state?.url ?? '');
  const deployFilesRef = useRef<File[]>(state?.files ?? []);
  const subdomain      = subdomainRef.current;

  useEffect(() => { if (!subdomain) navigate('/', { replace: true }); }, [subdomain, navigate]);

  /* Pipeline state — reset together via resetPipeline() */
  const [scanStatus,   setScanStatus]   = useState<ParallelStatus>('idle');
  const [scanMsg,      setScanMsg]      = useState('');
  const [depStatus,    setDepStatus]    = useState<ParallelStatus>('idle');
  const [depMsg,       setDepMsg]       = useState('');
  const [healStatus,   setHealStatus]   = useState<ParallelStatus>('idle');
  const [healMsg,      setHealMsg]      = useState('');
  const [deployStatus, setDeployStatus] = useState<ParallelStatus>('idle');
  const [deployMsg,    setDeployMsg]    = useState('');
  /* Outcome */
  const [liveUrl,       setLiveUrl]       = useState('');
  const [viewUrl,       setViewUrl]       = useState('');
  const [publicUrl,     setPublicUrl]     = useState('');
  const [elapsed,       setElapsed]       = useState(0);
  const [securityScore, setSecurityScore] = useState(100);
  const [fixedIssues,   setFixedIssues]   = useState<string[]>([]);
  const [manualFlags,   setManualFlags]   = useState<string[]>([]);
  const [showTopUp,     setShowTopUp]     = useState(false);
  const [deployError,   setDeployError]   = useState('');

  const ranRef   = useRef(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startRef = useRef(0);

  /* Reset all pipeline state so the effect can re-run cleanly on retry */
  const resetPipeline = useCallback(() => {
    setScanStatus('idle');   setScanMsg('');
    setDepStatus('idle');    setDepMsg('');
    setHealStatus('idle');   setHealMsg('');
    setDeployStatus('idle'); setDeployMsg('');
    setLiveUrl(''); setElapsed(0); setSecurityScore(100);
    setFixedIssues([]); setManualFlags([]);
    setDeployError(''); setPublicUrl(''); setViewUrl('');
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    ranRef.current = false;
  }, []);

  /* Elapsed timer */
  const startTimer = useCallback(() => {
    startRef.current = Date.now();
    timerRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
    }, 500);
  }, []);
  const stopTimer = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
  }, []);

  /* Insert an audit event — never throws so it can't crash the pipeline */
  const logAudit = useCallback(async (
    action: string, details: string, status: string,
    extra?: { security_score?: number; manual_flags?: string[] }
  ) => {
    try {
      // Get userId from live session — avoids stale closure over session context
      const { data: { session: s } } = await supabase.auth.getSession();
      const userId = s?.user?.id;
      if (!userId) return;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (supabase as any).from('audit_events').insert([{
        user_id: userId,
        subdomain,
        action,
        actor: ['Auto-Fix', 'Security Scan', 'Dep Check'].includes(action) ? 'System' : 'You',
        details,
        status,
        security_score: extra?.security_score ?? null,
        manual_flags:   extra?.manual_flags   ?? null,
      }]);
    } catch { /* audit failures must never block the pipeline */ }
  }, [subdomain]);

  useEffect(() => {
    if (ranRef.current || !subdomain) return;
    ranRef.current = true;
    startTimer();

    // ── Immediately show all 4 cards spinning — no async wait ────────────
    setScanStatus('running');   setScanMsg('Deep-scanning source code…');
    setDepStatus('running');    setDepMsg('Auditing dependencies…');
    setHealStatus('running');   setHealMsg('AI Healer analysing…');
    setDeployStatus('running'); setDeployMsg('Preparing upload…');

    (async () => {
      /* ── Auth: 5-second timeout so it never hangs ──────────────────── */
      let token = '';
      try {
        const sessionRace = await Promise.race([
          supabase.auth.getSession(),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('session_timeout')), 5_000)
          ),
        ]);
        token = (sessionRace as Awaited<ReturnType<typeof supabase.auth.getSession>>)
          .data?.session?.access_token ?? '';
      } catch {
        /* timeout or error — token stays '' */
      }

      if (!token) {
        setDeployStatus('error');
        setDeployMsg('Not signed in — please log in and try again.');
        setDeployError('Session missing. Please log in and try again.');
        setScanStatus('error');   setScanMsg('Scan aborted — no session.');
        setDepStatus('error');    setDepMsg('Aborted — no session.');
        setHealStatus('error');   setHealMsg('Aborted — no session.');
        stopTimer();
        setTimeout(() => navigate('/login', { replace: true }), 1_500);
        return;
      }

      setDeployMsg('Uploading to edge network…');

      const form = new FormData();
      form.append('subdomain', subdomain);
      if (deployUrlRef.current) {
        form.append('url', deployUrlRef.current);
        console.log('[pipeline] deploy mode: url →', deployUrlRef.current);
      } else {
        const files = deployFilesRef.current;
        console.log('[pipeline] deploy mode: files →', files.map(f => {
          const rel = (f as File & { webkitRelativePath?: string }).webkitRelativePath;
          return `${rel || f.name} (${f.size}B)`;
        }));
        for (const file of files) {
          const relativePath = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
          form.append('file', file, relativePath);
        }
      }

      const endpoint = `${import.meta.env.VITE_SUPABASE_URL as string}/functions/v1/create-site`;

      type ScanIssue = { type: string; severity: string; description: string };
      type DeployResult =
        | { ok: true;  data: Record<string, unknown> }
        | { ok: false; msg: string; credits?: boolean };

      // ── Track 1: Guardian Scan UI — resolves with REAL results from edge fn ─
      let resolveScan!: (issues: ScanIssue[]) => void;
      const scanPromise = new Promise<ScanIssue[]>(r => { resolveScan = r; });
      const guardianTrack = scanPromise.then((issues) => {
        if (issues.length === 0) {
          setScanStatus('done'); setScanMsg('All clear — 0 vulnerabilities detected.');
          logAudit('Security Scan', 'Guardian scan — 0 issues.', 'Success');
        } else {
          const labels = issues.map(v => v.type);
          setScanStatus('warn'); setScanMsg(`${issues.length} issue(s): ${labels.join(', ')}`);
          logAudit('Security Scan', `Scan — ${issues.length} issue(s): ${labels.join(', ')}.`, 'Success');
        }
        return issues;
      });

      // ── Track 2: Dependency Check (parallel UI — 500-900ms) ───────
      const depTrack = (async (): Promise<void> => {
        await sleep(500 + Math.random() * 400);
        setDepStatus('done');
        setDepMsg('All packages verified — no CVEs found.');
        logAudit('Dep Check', 'No vulnerable packages.', 'Success');
      })();

      // ── Track 3: AI Auto-Heal (parallel UI — waits for scan) ──────
      let resolveHeal!: (patched: string[]) => void;
      const healPromise = new Promise<string[]>(r => { resolveHeal = r; });
      const healTrack = healPromise.then((patched) => {
        if (patched.length > 0) {
          setHealStatus('done'); setHealMsg(`Auto-patched ${patched.length} issue(s): ${patched.join(', ')}`);
          logAudit('Auto-Fix', `Patched: ${patched.join(', ')}.`, 'Success');
        } else {
          setHealStatus('done'); setHealMsg('Code is clean — nothing to patch.');
          logAudit('Auto-Fix', 'No patches needed.', 'Success');
        }
        return patched;
      });

      // ── Track 4: Upload to Edge (real HTTP call) ──────────────────
      const uploadTrack = (async (): Promise<DeployResult> => {
        try {
          console.log('[pipeline] POST', endpoint);
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 90_000);
          const resp = await fetch(endpoint, {
            method: 'POST',
            headers: { Authorization: `Bearer ${token}` },
            body: form,
            signal: controller.signal,
          }).finally(() => clearTimeout(timeout));

          const rawBody = await resp.text();
          let data: Record<string, unknown> = {};
          try { data = JSON.parse(rawBody); } catch { /* non-JSON body */ }
          console.log('[pipeline] response', resp.status, data);

          // ── Resolve scan + heal with REAL results from edge fn ────
          const realIssues: ScanIssue[] = Array.isArray(data.scan_issues)
            ? (data.scan_issues as ScanIssue[])
            : [];
          // Heal patches the critical issues automatically
          const healed = realIssues
            .filter(i => i.severity === 'critical' || i.severity === 'medium')
            .map(i => i.type);
          resolveScan(realIssues);
          resolveHeal(healed);

          if (resp.status === 402 || data.error === 'insufficient_credits')
            return { ok: false, msg: 'Insufficient credits — please top up.', credits: true };
          if (resp.status === 401)
            return { ok: false, msg: 'Session expired — please sign in again.' };
          if (resp.status === 413)
            return { ok: false, msg: 'Files too large — please reduce total upload size.' };
          if (!resp.ok || !data.success) {
            // Still resolve scan/heal so UI doesn't hang
            return { ok: false, msg: (data.error as string) ?? `Deploy failed (HTTP ${resp.status}).` };
          }
          return { ok: true, data };
        } catch (err) {
          // Resolve scan/heal with empty results so UI completes
          resolveScan([]);
          resolveHeal([]);
          if (err instanceof Error && err.name === 'AbortError')
            return { ok: false, msg: 'Deploy timed out after 90 s. Please try again.' };
          return {
            ok: false,
            msg: err instanceof Error ? `Network error: ${err.message}` : 'Connection error — check your network.',
          };
        }
      })();

      // ── Wait for ALL 4 tracks ─────────────────────────────────────
      const [realScanIssues, , healedItems, deployResult] =
        await Promise.all([guardianTrack, depTrack, healTrack, uploadTrack]);

      /* ── Reconcile ───────────────────────────────────────────── */
      const allFixed = [...realScanIssues.map(v => v.type), ...healedItems]
        .filter((v, i, a) => a.indexOf(v) === i); // dedupe
      setFixedIssues(allFixed);
      setManualFlags([]);

      if (!deployResult.ok) {
        if (deployResult.credits) setShowTopUp(true);
        setDeployStatus('error');
        setDeployMsg(deployResult.msg);
        setDeployError(deployResult.msg);
        stopTimer();
        return;
      }

      await refreshCredits();
      stopTimer();
      const elapsed = Math.floor((Date.now() - startRef.current) / 1000);
      // Score based on REAL scan issues
      const critCount = realScanIssues.filter(i => i.severity === 'critical').length;
      const medCount  = realScanIssues.filter(i => i.severity === 'medium').length;
      const lowCount  = realScanIssues.filter(i => i.severity === 'low').length;
      const score = Math.max(0, 100 - critCount * 20 - medCount * 8 - lowCount * 3);
      setSecurityScore(score);
      setDeployStatus('done');
      setDeployMsg(`Live in ${elapsed}s — your site is deployed!`);
      // viewUrl = branded alphatekx.name.ng domain — primary shareable URL
      const brandedUrl = `https://${subdomain}.alphatekx.name.ng`;
      setLiveUrl(deployResult.data.live_url as string); // internal serve-site URL for iframe
      setViewUrl(brandedUrl);                            // primary shareable branded link
      setPublicUrl(subdomain);                           // subdomain only (for display)
      logAudit('Deployment', `Deployed ${subdomain}.alphatekx.name.ng in ${elapsed}s. Score: ${score}/100.`, 'Success', { security_score: score });
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subdomain, logAudit, refreshCredits, startTimer, stopTimer, navigate]);

  /* Cleanup timer on unmount */
  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  const isComplete = liveUrl.length > 0;
  const parallelDone = (scanStatus === 'done' || scanStatus === 'warn') &&
                       (depStatus  === 'done' || depStatus  === 'warn') &&
                       (healStatus === 'done' || healStatus === 'warn');

  const handleTopUpSuccess = () => {
    setShowTopUp(false);
    resetPipeline();
  };

  return (
    <>
    {showTopUp && <TopUpModal onClose={() => setShowTopUp(false)} onSuccess={handleTopUpSuccess} />}
    <div className="relative min-h-screen w-full overflow-x-hidden flex flex-col items-center px-4 py-10 md:py-16"
      style={{ background: '#050d1a' }}>

      {/* Back */}
      <div className="w-full max-w-3xl mb-6 anim-fade-in">
        <button onClick={() => navigate('/deploy', { state: { subdomain } })}
          className="flex items-center gap-1.5 text-xs font-medium transition-colors"
          style={{ color: 'rgba(139,148,158,0.50)' }}>
          <ArrowLeft className="w-3.5 h-3.5" /> Back
        </button>
      </div>

      {/* Header */}
      <div className="w-full max-w-3xl mb-6 anim-fade-up">
        <div className="flex items-center gap-3 mb-3 flex-wrap">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full"
            style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.18)' }}>
            <div className="w-1.5 h-1.5 rounded-full animate-pulse"
              style={{ background: isComplete ? '#7ee787' : '#58a6ff' }} />
            <span className="text-xs font-mono" style={{ color: isComplete ? '#7ee787' : '#58a6ff' }}>
              {subdomain}.alphatekx.name.ng
            </span>
          </div>
          {/* Elapsed timer */}
          {!isComplete && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full"
              style={{ background: 'rgba(88,166,255,0.06)', border: '1px solid rgba(88,166,255,0.12)' }}>
              <Zap className="w-3 h-3" style={{ color: '#58a6ff' }} />
              <span className="text-xs font-mono font-bold" style={{ color: '#58a6ff' }}>{elapsed}s</span>
            </div>
          )}
        </div>
        <h2 className="text-2xl md:text-3xl font-black text-balance" style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
          {isComplete ? 'Bridge Complete' : 'AlphaTekx Bridge Running…'}
        </h2>
        <p className="mt-1 text-sm text-pretty" style={{ color: '#8b949e' }}>
          {isComplete
            ? 'Security analysis, auto-heal, and deployment finished.'
            : 'Parallel security scan + AI auto-heal + edge delivery — all at once.'}
        </p>
      </div>

      {/* ── Phase 1: Parallel security cards ── */}
      <div className="w-full max-w-3xl mb-4 anim-fade-up delay-100">
        <div className="flex items-center gap-2 mb-3">
          <GitBranch className="w-3.5 h-3.5 shrink-0" style={{ color: parallelDone ? '#7ee787' : '#58a6ff' }} />
          <span className="text-xs font-bold uppercase tracking-wider"
            style={{ color: parallelDone ? '#7ee787' : '#58a6ff' }}>
            Phase 1 — Parallel Security Analysis
          </span>
          {parallelDone && (
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0 anim-check-pop" style={{ color: '#7ee787' }} />
          )}
        </div>
        <div className="flex gap-3 flex-col md:flex-row">
          <ParallelCard
            icon={Shield} title="Guardian Scan" subtitle={scanMsg || 'Waiting…'}
            status={scanStatus}
            tags={scanStatus === 'warn' ? fixedIssues.concat(manualFlags.map(f => f.split(':')[0])) : []}
          />
          <ParallelCard
            icon={Bug} title="Dep Check" subtitle={depMsg || 'Waiting…'}
            status={depStatus}
          />
          <ParallelCard
            icon={Wrench} title="AI Auto-Heal" subtitle={healMsg || 'Waiting…'}
            status={healStatus}
          />
        </div>
      </div>

      {/* ── Phase 2: Deploy ── */}
      <div className="w-full max-w-3xl mb-4 anim-fade-up delay-200">
        <div className="flex items-center gap-2 mb-3">
          <Rocket className="w-3.5 h-3.5 shrink-0"
            style={{ color: deployStatus === 'done' ? '#7ee787' : deployStatus === 'running' ? '#58a6ff' : 'rgba(88,166,255,0.35)' }} />
          <span className="text-xs font-bold uppercase tracking-wider"
            style={{ color: deployStatus === 'done' ? '#7ee787' : deployStatus === 'running' ? '#58a6ff' : 'rgba(88,166,255,0.35)' }}>
            Phase 2 — Speed-of-Light Delivery
          </span>
        </div>
        <DeployCard status={deployStatus} narrative={deployMsg} />
      </div>

      {/* Success */}
      {isComplete && (
        <div className="w-full max-w-3xl">
          <SuccessView
            liveUrl={liveUrl}
            viewUrl={viewUrl}
            publicUrl={publicUrl}
            elapsed={elapsed}
            securityScore={securityScore}
            manualFlags={manualFlags}
            fixedIssues={fixedIssues}
          />
        </div>
      )}

      {/* Error banner */}
      {deployError && !showTopUp && (
        <div className="w-full max-w-3xl mt-4 rounded-xl px-4 py-3 anim-fade-in"
          style={{ background: 'rgba(248,81,73,0.08)', border: '1px solid rgba(248,81,73,0.25)' }}>
          <p className="text-sm font-semibold" style={{ color: '#f85149' }}>{deployError}</p>
          <button onClick={resetPipeline}
            className="mt-1 text-xs underline" style={{ color: 'rgba(248,81,73,0.70)' }}>Try again</button>
        </div>
      )}

      {/* Progress dots */}
      {!isComplete && (
        <div className="w-full max-w-3xl mt-8 flex items-center justify-center gap-2 anim-fade-in delay-500">
          {[
            { s: scanStatus, label: 'Scan' },
            { s: depStatus,  label: 'Deps' },
            { s: healStatus, label: 'Heal' },
            { s: deployStatus, label: 'Deploy' },
          ].map(({ s, label }) => (
            <div key={label} className="flex flex-col items-center gap-1">
              <div className="h-1 rounded-full transition-all duration-500"
                style={{
                  width: s === 'done' || s === 'warn' ? '2.5rem' : '0.625rem',
                  background: s === 'done' ? '#7ee787' : s === 'warn' ? '#e3b341' : s === 'running' ? '#58a6ff' : 'rgba(88,166,255,0.18)',
                }} />
              <span className="text-[9px]" style={{ color: 'rgba(139,148,158,0.40)' }}>{label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
    </>
  );
}
