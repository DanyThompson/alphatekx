import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, AlertCircle, Loader2, ArrowLeft } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useState } from 'react';

function GoogleIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 18 18" fill="none">
      <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z" fill="#4285F4"/>
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18Z" fill="#34A853"/>
      <path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332Z" fill="#FBBC05"/>
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58Z" fill="#EA4335"/>
    </svg>
  );
}

export default function LoginPage() {
  const navigate = useNavigate();
  const { user, loading, signInWithGoogle } = useAuth();
  const [busy,  setBusy]  = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!loading && user) navigate('/dashboard', { replace: true });
  }, [user, loading, navigate]);

  const handleGoogle = async () => {
    setError('');
    setBusy(true);
    try {
      await signInWithGoogle();
      // signInWithGoogle redirects the page — if we reach here it errored
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : '';
      const detail = message.includes('provider is not enabled')
        ? 'Google sign-in is not enabled for this Supabase project yet.'
        : 'Google sign-in failed. Please try again.';
      setError(detail);
      setBusy(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center px-4 overflow-hidden"
      style={{ background: '#050d1a' }}>
      {/* Back to home */}
      <button onClick={() => navigate('/')}
        className="absolute top-4 left-4 z-20 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all hover:opacity-80"
        style={{ color: 'rgba(139,148,158,0.65)', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <ArrowLeft className="w-3.5 h-3.5" /> Back to home
      </button>
      {/* Background orbs */}
      <div className="pointer-events-none absolute rounded-full blur-3xl opacity-[0.15] w-[500px] h-[500px] bg-blue-700 top-[-150px] left-1/2 -translate-x-1/2" />
      <div className="pointer-events-none absolute rounded-full blur-3xl opacity-[0.10] w-[300px] h-[300px] bg-indigo-700 bottom-0 right-0" />

      {/* Card */}
      <div className="relative z-10 w-full max-w-sm rounded-3xl p-8 anim-fade-up flex flex-col items-center"
        style={{
          background: 'rgba(13,17,31,0.90)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          border: '1px solid rgba(88,166,255,0.16)',
          boxShadow: '0 24px 80px rgba(0,0,0,0.55)',
        }}>

        {/* Logo */}
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-5"
          style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.28)' }}>
          <Shield className="w-8 h-8" style={{ color: '#58a6ff' }} />
        </div>

        {/* Heading */}
        <h1 className="text-2xl font-black mb-2 text-balance text-center" style={{ color: '#e6edf3' }}>
          Welcome to AlphaTekx
        </h1>
        <p className="text-sm text-center mb-8 text-pretty" style={{ color: '#8b949e' }}>
          Deploy your first project in 60&nbsp;seconds.
          <br />
          <span style={{ color: '#7ee787' }}>20 free credits</span> when you sign up.
        </p>

        {/* Error */}
        {error && (
          <div className="w-full flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4 anim-fade-in"
            style={{ background: 'rgba(248,81,73,0.08)', border: '1px solid rgba(248,81,73,0.22)' }}>
            <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" style={{ color: '#f85149' }} />
            <p className="text-xs text-pretty" style={{ color: '#f85149' }}>{error}</p>
          </div>
        )}

        {/* Google Sign-In */}
        <button
          onClick={handleGoogle}
          disabled={busy}
          className="w-full flex items-center justify-center gap-3 rounded-xl py-3.5 font-bold text-sm transition-all duration-200 hover:opacity-92 active:scale-[0.97] disabled:opacity-60 disabled:cursor-not-allowed"
          style={{
            background: busy ? 'rgba(255,255,255,0.90)' : '#ffffff',
            color: '#1f2937',
            border: '1px solid rgba(255,255,255,0.12)',
            boxShadow: '0 2px 16px rgba(0,0,0,0.35)',
          }}>
          {busy
            ? <Loader2 className="w-5 h-5 animate-spin text-gray-500" />
            : <GoogleIcon />}
          {busy ? 'Redirecting to Google…' : 'Continue with Google'}
        </button>

        {/* Trust badges */}
        <div className="mt-6 flex items-center justify-center gap-4 flex-wrap">
          {['256-bit encrypted', 'No spam', 'Cancel anytime'].map(t => (
            <span key={t} className="text-[10px] font-medium" style={{ color: 'rgba(139,148,158,0.45)' }}>
              ✓ {t}
            </span>
          ))}
        </div>

        {/* Legal */}
        <div className="mt-5 pt-5 w-full text-center" style={{ borderTop: '1px solid rgba(88,166,255,0.08)' }}>
          <p className="text-[11px] leading-relaxed text-pretty" style={{ color: 'rgba(139,148,158,0.40)' }}>
            By continuing, you agree to our{' '}
            <button className="underline hover:opacity-80" style={{ color: 'rgba(88,166,255,0.55)' }}>Terms</button>
            {' '}and{' '}
            <button className="underline hover:opacity-80" style={{ color: 'rgba(88,166,255,0.55)' }}>Privacy Policy</button>.
          </p>
        </div>
      </div>
    </div>
  );
}
