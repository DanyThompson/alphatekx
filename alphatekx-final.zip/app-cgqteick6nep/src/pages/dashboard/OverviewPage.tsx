import { useNavigate } from 'react-router-dom';
import {
  Plus, ExternalLink, Rocket, ShieldCheck, Zap, Globe,
  LayoutDashboard, Copy, Check, Download, Loader2, Trash2, AlertTriangle,
} from 'lucide-react';
import { useState } from 'react';
import { useDash, Deployment } from '@/layouts/DashboardLayout';
import { useAuth } from '@/contexts/AuthContext';
import { downloadProductionZip } from '@/utils/downloadZip';
import { supabase } from '@/lib/supabase';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;

/* ── Helpers ──────────────────────────────────────────────── */
function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 2)   return 'just now';
  if (mins < 60)  return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

/* ── Delete confirm modal ─────────────────────────────────── */
interface DeleteModalProps {
  subdomain: string;
  onConfirm: () => void;
  onCancel: () => void;
  deleting: boolean;
}

function DeleteModal({ subdomain, onConfirm, onCancel, deleting }: DeleteModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.70)', backdropFilter: 'blur(6px)' }}
      onClick={onCancel}>
      <div className="w-full max-w-sm rounded-2xl p-6 flex flex-col gap-5"
        style={{ background: '#0d1117', border: '1px solid rgba(248,81,73,0.25)', boxShadow: '0 24px 80px rgba(0,0,0,0.70)' }}
        onClick={e => e.stopPropagation()}>
        {/* Icon */}
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background: 'rgba(248,81,73,0.10)', border: '1px solid rgba(248,81,73,0.25)' }}>
            <AlertTriangle className="w-6 h-6" style={{ color: '#f85149' }} />
          </div>
          <h3 className="text-base font-black text-balance" style={{ color: '#e6edf3' }}>
            Delete project?
          </h3>
          <p className="text-sm text-pretty leading-relaxed" style={{ color: '#8b949e' }}>
            This permanently removes{' '}
            <span className="font-mono font-semibold" style={{ color: '#f85149' }}>
              {subdomain}.alphatekx.name.ng
            </span>{' '}
            and all its files. This cannot be undone.
          </p>
        </div>
        {/* Actions */}
        <div className="flex gap-3">
          <button onClick={onCancel} disabled={deleting}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all hover:opacity-80 disabled:opacity-40"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', color: '#8b949e' }}>
            Cancel
          </button>
          <button onClick={onConfirm} disabled={deleting}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-80 disabled:opacity-50"
            style={{ background: 'rgba(248,81,73,0.12)', border: '1px solid rgba(248,81,73,0.30)', color: '#f85149' }}>
            {deleting
              ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Deleting…</>
              : <><Trash2 className="w-3.5 h-3.5" /> Delete</>}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Deployment card ──────────────────────────────────────── */
function DeployCard({ dep, onDeleted }: { dep: Deployment; onDeleted: () => void }) {
  const [copied,        setCopied]        = useState(false);
  const [downloading,   setDownloading]   = useState(false);
  const [showDeleteDlg, setShowDeleteDlg] = useState(false);
  const [deleting,      setDeleting]      = useState(false);
  const [deleteError,   setDeleteError]   = useState('');

  /* Primary link is the branded domain */
  const brandedUrl = `https://${dep.subdomain}.alphatekx.name.ng`;
  /* Fallback proxy link (always HTTPS via our app) */
  const fallbackUrl = `${window.location.origin}/live/${dep.subdomain}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(brandedUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleDownload = async () => {
    setDownloading(true);
    try { await downloadProductionZip(dep.subdomain); }
    finally { setTimeout(() => setDownloading(false), 1200); }
  };

  const handleDelete = async () => {
    setDeleting(true);
    setDeleteError('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      if (!token) throw new Error('Not authenticated');

      const res = await fetch(`${SUPABASE_URL}/functions/v1/delete-site`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY as string,
        },
        body: JSON.stringify({ subdomain: dep.subdomain }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? `Delete failed (${res.status})`);

      setShowDeleteDlg(false);
      onDeleted();
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Delete failed');
    } finally {
      setDeleting(false);
    }
  };

  const isLive = dep.status === 'live' || dep.status === 'deployed';

  return (
    <>
      {showDeleteDlg && (
        <DeleteModal
          subdomain={dep.subdomain}
          onConfirm={handleDelete}
          onCancel={() => { if (!deleting) { setShowDeleteDlg(false); setDeleteError(''); } }}
          deleting={deleting}
        />
      )}

      <div className="rounded-2xl p-5 flex flex-col gap-4 h-full transition-all duration-200 hover:-translate-y-0.5"
        style={{
          background: 'rgba(13,17,31,0.70)',
          border: '1px solid rgba(88,166,255,0.12)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.30)',
        }}>

        {/* Header row */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-sm font-bold truncate" style={{ color: '#e6edf3' }}>
                {dep.subdomain}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0"
                style={{
                  background: isLive ? 'rgba(126,231,135,0.10)' : 'rgba(88,166,255,0.10)',
                  color: isLive ? '#7ee787' : '#58a6ff',
                  border: `1px solid ${isLive ? 'rgba(126,231,135,0.25)' : 'rgba(88,166,255,0.25)'}`,
                }}>
                {isLive && <span className="w-1.5 h-1.5 rounded-full inline-block animate-pulse mr-1"
                  style={{ background: '#7ee787' }} />}
                {isLive ? 'Live' : dep.status}
              </span>
            </div>
            {/* Branded URL as primary display */}
            <a href={brandedUrl} target="_blank" rel="noreferrer"
              className="text-xs font-mono truncate block hover:opacity-80 transition-opacity"
              style={{ color: '#58a6ff' }}>
              {dep.subdomain}.alphatekx.name.ng
            </a>
          </div>
          {/* Open external link */}
          <a href={brandedUrl} target="_blank" rel="noreferrer"
            className="shrink-0 p-2 rounded-xl transition-all hover:opacity-80"
            style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.18)', color: '#58a6ff' }}
            title={`Open ${dep.subdomain}.alphatekx.name.ng`}>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Deployed at */}
        <p className="text-xs" style={{ color: 'rgba(139,148,158,0.55)' }}>
          Deployed {relativeTime(dep.created_at)} ·{' '}
          <a href={fallbackUrl} target="_blank" rel="noreferrer"
            className="hover:opacity-80 transition-opacity"
            style={{ color: 'rgba(139,148,158,0.40)' }}>
            mirror link
          </a>
        </p>

        {/* Delete error */}
        {deleteError && (
          <p className="text-xs px-2 py-1.5 rounded-lg" style={{ background: 'rgba(248,81,73,0.08)', color: '#f85149', border: '1px solid rgba(248,81,73,0.20)' }}>
            {deleteError}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2 mt-auto">
          <button onClick={handleCopy}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold transition-all hover:opacity-80"
            style={{
              background: copied ? 'rgba(126,231,135,0.10)' : 'rgba(88,166,255,0.08)',
              border: `1px solid ${copied ? 'rgba(126,231,135,0.25)' : 'rgba(88,166,255,0.18)'}`,
              color: copied ? '#7ee787' : '#58a6ff',
            }}>
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy Link'}
          </button>
          <button onClick={handleDownload} disabled={downloading}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold transition-all hover:opacity-80 disabled:opacity-50"
            style={{
              background: 'rgba(88,166,255,0.08)',
              border: '1px solid rgba(88,166,255,0.18)',
              color: '#8b949e',
            }}>
            {downloading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            {downloading ? 'Preparing…' : 'Download'}
          </button>
          {/* Delete button */}
          <button onClick={() => setShowDeleteDlg(true)}
            className="shrink-0 p-2 rounded-xl transition-all hover:opacity-80"
            style={{ background: 'rgba(248,81,73,0.07)', border: '1px solid rgba(248,81,73,0.18)', color: '#f85149' }}
            title="Delete project">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </>
  );
}

/* ── Empty state ──────────────────────────────────────────── */
function EmptyState() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center justify-center text-center py-20 px-4">
      <div className="w-20 h-20 rounded-3xl flex items-center justify-center mb-6"
        style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.18)' }}>
        <Rocket className="w-10 h-10" style={{ color: 'rgba(88,166,255,0.45)' }} />
      </div>
      <h3 className="text-xl font-black text-balance mb-3" style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
        No deployments yet
      </h3>
      <p className="text-sm text-pretty max-w-xs mb-8" style={{ color: '#8b949e' }}>
        Deploy your first project and it will show up here. It only takes 60 seconds.
      </p>
      <button
        onClick={() => navigate('/claim')}
        className="flex items-center gap-2 px-8 py-3.5 rounded-2xl font-bold text-sm transition-all duration-200 hover:scale-[1.03] active:scale-[0.97]"
        style={{
          background: 'linear-gradient(135deg, #1a4fbd, #2563eb)',
          color: '#e0e7ff',
          border: '1px solid rgba(88,166,255,0.35)',
          boxShadow: '0 6px 32px rgba(37,99,235,0.40)',
        }}>
        <Rocket className="w-4 h-4" />
        Deploy Your First Project
      </button>
    </div>
  );
}

/* ── Quick stat card ──────────────────────────────────────── */
function StatCard({ icon: Icon, label, value, color }: {
  icon: React.ElementType; label: string; value: string | number; color: string;
}) {
  return (
    <div className="rounded-2xl p-5 flex items-center gap-4"
      style={{
        background: 'rgba(13,17,31,0.70)',
        border: '1px solid rgba(88,166,255,0.10)',
      }}>
      <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
        style={{ background: `${color}14`, border: `1px solid ${color}28` }}>
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div>
        <p className="text-2xl font-black" style={{ color: '#e6edf3', letterSpacing: '-0.03em' }}>{value}</p>
        <p className="text-xs" style={{ color: '#8b949e' }}>{label}</p>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   OVERVIEW PAGE
══════════════════════════════════════════════════════════════ */
export default function OverviewPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { deployments, loading, reload: loadDeployments } = useDash();

  const firstName = profile?.full_name?.split(' ')[0] ?? profile?.email?.split('@')[0] ?? 'there';
  const liveCount  = deployments.filter(d => d.status === 'live' || d.status === 'deployed').length;

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-8">

      {/* ── Welcome header ──────────────────────────────────── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <LayoutDashboard className="w-5 h-5" style={{ color: '#58a6ff' }} />
            <h1 className="text-xl font-black text-balance" style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
              Welcome back, {firstName} 👋
            </h1>
          </div>
          <p className="text-sm text-pretty" style={{ color: '#8b949e' }}>
            Here's everything happening with your projects.
          </p>
        </div>
        <button onClick={() => navigate('/claim')}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 hover:scale-[1.03] active:scale-[0.97] shrink-0"
          style={{
            background: 'linear-gradient(135deg, #1a4fbd, #2563eb)',
            color: '#e0e7ff',
            border: '1px solid rgba(88,166,255,0.35)',
            boxShadow: '0 4px 20px rgba(37,99,235,0.35)',
          }}>
          <Plus className="w-4 h-4" /> Deploy New Project
        </button>
      </div>

      {/* ── Stats row ───────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Globe}       label="Total Projects"    value={loading ? '—' : deployments.length} color="#58a6ff" />
        <StatCard icon={ShieldCheck} label="Live Sites"        value={loading ? '—' : liveCount}           color="#7ee787" />
        <StatCard icon={Zap}         label="Credits Remaining" value={profile?.credit_balance ?? '—'}       color="#f0883e" />
        <StatCard icon={Rocket}      label="Free Deployments"  value="20"                                   color="#a78bfa" />
      </div>

      {/* ── Credits banner (show if low) ─────────────────────── */}
      {!loading && profile && profile.credit_balance <= 3 && (
        <div className="rounded-2xl px-5 py-4 flex items-center justify-between gap-4 flex-wrap"
          style={{ background: 'rgba(240,136,62,0.08)', border: '1px solid rgba(240,136,62,0.25)' }}>
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 shrink-0" style={{ color: '#f0883e' }} />
            <p className="text-sm" style={{ color: '#f0883e' }}>
              <strong>Low credits:</strong> you have {profile.credit_balance} deployment{profile.credit_balance !== 1 ? 's' : ''} left.
            </p>
          </div>
          <button
            onClick={() => navigate('/dashboard')}
            className="text-xs font-bold px-3 py-1.5 rounded-xl shrink-0 transition-opacity hover:opacity-80"
            style={{ background: 'rgba(240,136,62,0.15)', color: '#f0883e', border: '1px solid rgba(240,136,62,0.30)' }}>
            Top Up Credits
          </button>
        </div>
      )}

      {/* ── Deployments ──────────────────────────────────────── */}
      <div>
        <h2 className="text-sm font-bold mb-4" style={{ color: '#e6edf3' }}>
          Your Projects
          {!loading && deployments.length > 0 && (
            <span className="ml-2 text-xs font-normal" style={{ color: '#8b949e' }}>
              ({deployments.length} total)
            </span>
          )}
        </h2>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="rounded-2xl p-5 h-44 animate-pulse"
                style={{ background: 'rgba(13,17,31,0.50)', border: '1px solid rgba(88,166,255,0.08)' }} />
            ))}
          </div>
        ) : deployments.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {deployments.map(dep => (
              <DeployCard key={dep.id} dep={dep} onDeleted={loadDeployments} />
            ))}
          </div>
        )}
      </div>

      {/* ── Quick links to modules ───────────────────────────── */}
      {deployments.length > 0 && (
        <div>
          <h2 className="text-sm font-bold mb-4" style={{ color: '#e6edf3' }}>Platform Modules</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { to: '/dashboard/security', icon: ShieldCheck, label: 'Protection',    desc: 'Live threat feed and auto-healing security engine.', color: '#f85149' },
              { to: '/dashboard/policy',   icon: LayoutDashboard, label: 'Rules',     desc: 'Set deployment policies and compliance guardrails.', color: '#a5b4fc' },
              { to: '/dashboard/audit',    icon: LayoutDashboard, label: 'History',   desc: 'Full audit trail and one-click version rollback.',    color: '#7ee787' },
            ].map(({ to, icon: Icon, label, desc, color }) => (
              <button key={to} onClick={() => navigate(to)}
                className="text-left rounded-2xl p-5 transition-all duration-200 hover:-translate-y-0.5 hover:opacity-90"
                style={{
                  background: 'rgba(13,17,31,0.70)',
                  border: '1px solid rgba(88,166,255,0.10)',
                }}>
                <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
                  style={{ background: `${color}14`, border: `1px solid ${color}28` }}>
                  <Icon className="w-4 h-4" style={{ color }} />
                </div>
                <p className="text-sm font-bold mb-1" style={{ color: '#e6edf3' }}>{label}</p>
                <p className="text-xs text-pretty leading-relaxed" style={{ color: '#8b949e' }}>{desc}</p>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
