import { useState, useEffect, useRef } from 'react';
import { Shield, AlertTriangle, Zap, Activity, CheckCircle2, XCircle, Loader2 } from 'lucide-react';

/* ── Types ────────────────────────────────────────────────── */
type AttackType  = 'SQL Injection' | 'XSS Pattern' | 'DDoS Pattern';
type ThreatStatus = 'Blocked' | 'Rate-Limited' | 'Isolated';
type HealAction   = 'Firewall Rule Created' | 'Traffic Rate-Limited' | 'Container Isolated';

interface ThreatEntry {
  id: string;
  ts: string;
  attack: AttackType;
  ip: string;
  endpoint: string;
  status: ThreatStatus;
}

interface HealEntry {
  id: string;
  ts: string;
  action: HealAction;
  reason: string;
  detail: string;
  done: boolean;
}

/* ── Fake data generators ─────────────────────────────────── */
const ATTACK_TYPES: AttackType[] = ['SQL Injection', 'XSS Pattern', 'DDoS Pattern'];
const STATUS_MAP: Record<AttackType, ThreatStatus> = {
  'SQL Injection': 'Blocked',
  'XSS Pattern':  'Isolated',
  'DDoS Pattern': 'Rate-Limited',
};
const HEAL_MAP: Record<AttackType, { action: HealAction; detail: string }> = {
  'SQL Injection': { action: 'Firewall Rule Created',   detail: 'Temporary firewall rule added for suspicious query patterns.' },
  'XSS Pattern':  { action: 'Container Isolated',      detail: 'Affected container sandboxed to prevent script propagation.' },
  'DDoS Pattern': { action: 'Traffic Rate-Limited',    detail: 'Request rate capped at 60/min for flagged IP range.' },
};
const ENDPOINTS = ['/api/users', '/api/login', '/api/search', '/api/data', '/api/upload'];

let _id = 1;
function genThreat(): ThreatEntry {
  const attack = ATTACK_TYPES[Math.floor(Math.random() * 3)];
  const ip = `${Math.floor(Math.random()*220)+10}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
  return {
    id: String(_id++),
    ts: new Date().toLocaleTimeString(),
    attack,
    ip,
    endpoint: ENDPOINTS[Math.floor(Math.random() * ENDPOINTS.length)],
    status: STATUS_MAP[attack],
  };
}
function genHeal(attack: AttackType, ip: string): HealEntry {
  const { action, detail } = HEAL_MAP[attack];
  return {
    id: String(_id++),
    ts: new Date().toLocaleTimeString(),
    action,
    reason: `${attack} detected from ${ip}`,
    detail,
    done: false,
  };
}

/* ── Status badge ─────────────────────────────────────────── */
function ThreatBadge({ status }: { status: ThreatStatus }) {
  const cfg: Record<ThreatStatus, { bg: string; color: string }> = {
    'Blocked':      { bg: 'rgba(248,81,73,0.12)',    color: '#f85149' },
    'Rate-Limited': { bg: 'rgba(227,179,65,0.12)',   color: '#e3b341' },
    'Isolated':     { bg: 'rgba(165,180,252,0.12)',  color: '#a5b4fc' },
  };
  const { bg, color } = cfg[status];
  return (
    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0"
      style={{ background: bg, color, border: `1px solid ${color}33` }}>
      {status}
    </span>
  );
}

/* ── Attack icon ──────────────────────────────────────────── */
function AttackIcon({ type }: { type: AttackType }) {
  if (type === 'SQL Injection') return <AlertTriangle className="w-3.5 h-3.5 shrink-0" style={{ color: '#f85149' }} />;
  if (type === 'XSS Pattern')  return <Zap           className="w-3.5 h-3.5 shrink-0" style={{ color: '#a5b4fc' }} />;
  return                              <Activity       className="w-3.5 h-3.5 shrink-0" style={{ color: '#e3b341' }} />;
}

/* ══════════════════════════════════════════════════════════════════
   SECURITY SHIELD PAGE
══════════════════════════════════════════════════════════════════ */
export default function SecurityShieldPage() {
  const [threats, setThreats] = useState<ThreatEntry[]>([]);
  const [heals,   setHeals]   = useState<HealEntry[]>([]);
  const [total,   setTotal]   = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Seed initial data
  useEffect(() => {
    const initial: ThreatEntry[] = Array.from({ length: 6 }, genThreat);
    setThreats(initial);
    setTotal(initial.length);
    const initialHeals = initial.slice(0, 4).map(t => ({ ...genHeal(t.attack, t.ip), done: true }));
    setHeals(initialHeals);
  }, []);

  // Stream new threats every 3–5 seconds
  useEffect(() => {
    const tick = () => {
      const t = genThreat();
      const h = genHeal(t.attack, t.ip);
      setThreats(prev => [t, ...prev].slice(0, 50));
      setTotal(prev => prev + 1);
      // Heal resolves after 2s
      setHeals(prev => [h, ...prev].slice(0, 50));
      setTimeout(() => {
        setHeals(prev => prev.map(e => e.id === h.id ? { ...e, done: true } : e));
      }, 2000);
    };
    timerRef.current = setInterval(tick, 3200 + Math.random() * 1800);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-5 h-5" style={{ color: '#58a6ff' }} />
            <h1 className="text-xl font-black text-balance" style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
              Your Project is Protected
            </h1>
          </div>
          <p className="text-sm text-pretty" style={{ color: '#8b949e' }}>
            AlphaTekx watches your project 24/7 and blocks anything harmful — automatically.
          </p>
        </div>
        {/* Stats */}
        <div className="flex gap-3 flex-wrap">
          {[
            { label: 'Threats Blocked', value: total, color: '#f85149' },
            { label: 'Auto-Healed',     value: heals.filter(h => h.done).length, color: '#7ee787' },
            { label: 'Active Rules',    value: 3,     color: '#58a6ff' },
          ].map(s => (
            <div key={s.label} className="glass rounded-xl px-4 py-3 text-center min-w-[90px]">
              <p className="text-xl font-black" style={{ color: s.color }}>{s.value}</p>
              <p className="text-[10px] font-medium mt-0.5 text-balance" style={{ color: '#8b949e' }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Two-column feed */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Threat Feed */}
        <div className="glass rounded-2xl overflow-hidden h-full flex flex-col">
          <div className="px-5 py-4 flex items-center justify-between shrink-0"
            style={{ borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#f85149' }} />
              <span className="text-sm font-bold" style={{ color: '#e6edf3' }}>Live Threat Feed</span>
            </div>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full"
              style={{ background: 'rgba(248,81,73,0.10)', color: '#f85149', border: '1px solid rgba(248,81,73,0.20)' }}>
              LIVE
            </span>
          </div>

          <div className="flex-1 overflow-y-auto min-h-0 max-h-[420px]">
            {threats.length === 0 ? (
              <div className="flex items-center justify-center h-24 text-sm" style={{ color: '#8b949e' }}>
                No threats detected yet
              </div>
            ) : threats.map((t, i) => (
              <div key={t.id}
                className={`flex items-start gap-3 px-5 py-3 border-b transition-all duration-300 ${i === 0 ? 'anim-fade-in' : ''}`}
                style={{ borderColor: 'rgba(88,166,255,0.07)', background: i === 0 ? 'rgba(248,81,73,0.04)' : 'transparent' }}>
                <AttackIcon type={t.attack} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-semibold" style={{ color: '#c9d1d9' }}>{t.attack}</span>
                    <ThreatBadge status={t.status} />
                  </div>
                  <p className="text-xs font-mono truncate" style={{ color: '#8b949e' }}>
                    {t.ip} → {t.endpoint}
                  </p>
                </div>
                <span className="text-[10px] shrink-0 mt-0.5 font-mono" style={{ color: 'rgba(139,148,158,0.55)' }}>
                  {t.ts}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Self-Healing Log */}
        <div className="glass rounded-2xl overflow-hidden h-full flex flex-col">
          <div className="px-5 py-4 flex items-center justify-between shrink-0"
            style={{ borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#7ee787' }} />
              <span className="text-sm font-bold" style={{ color: '#e6edf3' }}>Self-Healing Log</span>
            </div>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full"
              style={{ background: 'rgba(126,231,135,0.08)', color: '#7ee787', border: '1px solid rgba(126,231,135,0.20)' }}>
              AUTO
            </span>
          </div>

          <div className="flex-1 overflow-y-auto min-h-0 max-h-[420px]">
            {heals.length === 0 ? (
              <div className="flex items-center justify-center h-24 text-sm" style={{ color: '#8b949e' }}>
                No actions taken yet
              </div>
            ) : heals.map((h, i) => (
              <div key={h.id}
                className={`flex items-start gap-3 px-5 py-3 border-b transition-all duration-300 ${i === 0 ? 'anim-fade-in' : ''}`}
                style={{ borderColor: 'rgba(88,166,255,0.07)' }}>
                <div className="shrink-0 mt-0.5">
                  {h.done
                    ? <CheckCircle2 className="w-3.5 h-3.5" style={{ color: '#7ee787' }} />
                    : <Loader2 className="w-3.5 h-3.5 animate-spin" style={{ color: '#58a6ff' }} />
                  }
                </div>
                <div className="flex-1 min-w-0 space-y-0.5">
                  <p className="text-xs font-semibold" style={{ color: h.done ? '#7ee787' : '#58a6ff' }}>
                    {h.action}
                  </p>
                  <p className="text-xs text-pretty leading-snug" style={{ color: '#8b949e' }}>{h.detail}</p>
                  <p className="text-[10px] font-mono" style={{ color: 'rgba(139,148,158,0.55)' }}>{h.reason}</p>
                </div>
                <span className="text-[10px] shrink-0 mt-0.5 font-mono" style={{ color: 'rgba(139,148,158,0.55)' }}>
                  {h.ts}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Info strip */}
      <div className="glass rounded-xl px-5 py-4 flex items-start gap-3"
        style={{ borderColor: 'rgba(88,166,255,0.12)' }}>
        <XCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: 'rgba(88,166,255,0.60)' }} />
        <p className="text-xs text-pretty leading-relaxed" style={{ color: '#8b949e' }}>
          <strong style={{ color: '#c9d1d9' }}>How it works:</strong> AlphaTekx monitors your live app continuously.
          When a threat is detected it is immediately blocked and the system heals itself — no developer action required.
          All activity is also recorded in your{' '}
          <strong style={{ color: '#c9d1d9' }}>Audit Trail</strong>.
        </p>
      </div>
    </div>
  );
}
