import { useState } from 'react';
import { ClipboardList, ToggleLeft, ToggleRight, ChevronDown, ChevronUp, Download, AlertCircle } from 'lucide-react';

/* ── Types ────────────────────────────────────────────────── */
interface PolicyRule {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

interface PolicyCategory {
  id: string;
  label: string;
  color: string;
  rules: PolicyRule[];
}

interface FixReport {
  id: string;
  ts: string;
  attempt: string;
  violations: { rule: string; why: string; fix: string }[];
}

/* ── Initial policy data ──────────────────────────────────── */
const INITIAL_CATEGORIES: PolicyCategory[] = [
  {
    id: 'security', label: 'Security', color: '#f85149',
    rules: [
      { id: 's1', label: 'Block deployments with insecure dependencies', description: 'Stops any build that relies on packages with known security vulnerabilities.', enabled: true },
      { id: 's2', label: 'Reject exposed secrets in source code',        description: 'Prevents deployment if API keys or passwords are found in plain text.', enabled: true },
      { id: 's3', label: 'Enforce HTTPS-only responses',                 description: 'Automatically rejects builds that would serve content over plain HTTP.', enabled: false },
    ],
  },
  {
    id: 'privacy', label: 'Privacy (GDPR)', color: '#a5b4fc',
    rules: [
      { id: 'p1', label: 'Enforce GDPR-compliant headers',     description: 'Checks that all responses include the required privacy and consent headers.', enabled: true },
      { id: 'p2', label: 'Block third-party tracking scripts', description: 'Prevents deployment if the code contains unapproved analytics or tracking.', enabled: false },
    ],
  },
  {
    id: 'access', label: 'Access Control', color: '#58a6ff',
    rules: [
      { id: 'a1', label: 'Require 2FA for all deployment changes', description: 'Every deployment must be confirmed by a two-factor authentication code.', enabled: false },
      { id: 'a2', label: 'Block deployments outside business hours', description: 'Prevents unplanned deployments from going live at night or on weekends.', enabled: false },
    ],
  },
  {
    id: 'performance', label: 'Performance', color: '#e3b341',
    rules: [
      { id: 'f1', label: 'Enforce max bundle size (5 MB)',       description: 'Rejects any build whose total file size exceeds 5 MB to keep load times fast.', enabled: true },
      { id: 'f2', label: 'Block unoptimized images over 2 MB',   description: 'Flags large images that would slow down your page and asks you to compress them.', enabled: false },
    ],
  },
];

const SAMPLE_REPORTS: FixReport[] = [
  {
    id: 'r1', ts: '2026-06-20 14:32', attempt: 'Deploy #7 — my-app',
    violations: [
      { rule: 'Block deployments with insecure dependencies', why: 'Package "lodash@4.17.20" has a known prototype pollution vulnerability (CVE-2021-23337).', fix: 'Upgrade lodash to version 4.17.21 or later in your package.json.' },
      { rule: 'Reject exposed secrets in source code',        why: 'An AWS Access Key was found in src/config.js at line 12.',                                   fix: 'Remove the key and use process.env.AWS_ACCESS_KEY_ID instead.' },
    ],
  },
  {
    id: 'r2', ts: '2026-06-20 11:15', attempt: 'Deploy #6 — my-app',
    violations: [
      { rule: 'Enforce GDPR-compliant headers', why: 'Response headers are missing Content-Security-Policy and X-Frame-Options.', fix: 'Add the required headers to your server configuration or use a middleware package.' },
    ],
  },
];

/* ── Toggle component ─────────────────────────────────────── */
function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button onClick={onToggle} className="shrink-0 transition-all duration-200 active:scale-95">
      {on
        ? <ToggleRight className="w-7 h-7" style={{ color: '#7ee787' }} />
        : <ToggleLeft  className="w-7 h-7" style={{ color: 'rgba(139,148,158,0.40)' }} />
      }
    </button>
  );
}

/* ── Fix-It Report Row ────────────────────────────────────── */
function ReportRow({ report }: { report: FixReport }) {
  const [open, setOpen] = useState(false);
  const handleDownload = () => {
    const text = report.violations.map(v =>
      `Rule: ${v.rule}\nWhy: ${v.why}\nHow to Fix: ${v.fix}`
    ).join('\n\n');
    const blob = new Blob([`Fix-It Report — ${report.attempt}\n${report.ts}\n\n${text}`], { type: 'text/plain' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = `fix-it-${report.id}.txt`; a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <div className="rounded-xl overflow-hidden transition-all duration-200"
      style={{ border: '1px solid rgba(248,81,73,0.18)', background: 'rgba(248,81,73,0.04)' }}>
      <button className="w-full flex items-center gap-3 px-4 py-3 text-left" onClick={() => setOpen(o => !o)}>
        <AlertCircle className="w-4 h-4 shrink-0" style={{ color: '#f85149' }} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: '#e6edf3' }}>{report.attempt}</p>
          <p className="text-xs" style={{ color: '#8b949e' }}>{report.ts} · {report.violations.length} violation{report.violations.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button onClick={e => { e.stopPropagation(); handleDownload(); }}
            className="p-1.5 rounded-lg transition-colors hover:bg-white/5" style={{ color: '#8b949e' }}>
            <Download className="w-3.5 h-3.5" />
          </button>
          {open ? <ChevronUp className="w-4 h-4" style={{ color: '#8b949e' }} /> : <ChevronDown className="w-4 h-4" style={{ color: '#8b949e' }} />}
        </div>
      </button>

      {open && (
        <div className="px-4 pb-4 space-y-3 anim-fade-in">
          {report.violations.map((v, i) => (
            <div key={i} className="rounded-xl p-3 space-y-1.5"
              style={{ background: 'rgba(4,10,24,0.55)', border: '1px solid rgba(88,166,255,0.10)' }}>
              <p className="text-xs font-semibold" style={{ color: '#f85149' }}>{v.rule}</p>
              <p className="text-xs text-pretty leading-relaxed" style={{ color: '#8b949e' }}>
                <strong style={{ color: '#c9d1d9' }}>Why it failed: </strong>{v.why}
              </p>
              <p className="text-xs text-pretty leading-relaxed" style={{ color: '#8b949e' }}>
                <strong style={{ color: '#7ee787' }}>How to fix it: </strong>{v.fix}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   POLICY ENGINE PAGE
══════════════════════════════════════════════════════════════════ */
export default function PolicyEnginePage() {
  const [categories, setCategories] = useState<PolicyCategory[]>(INITIAL_CATEGORIES);
  const [saved, setSaved] = useState(false);

  const toggleRule = (catId: string, ruleId: string) => {
    setCategories(prev => prev.map(c => c.id !== catId ? c : {
      ...c,
      rules: c.rules.map(r => r.id !== ruleId ? r : { ...r, enabled: !r.enabled }),
    }));
    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const activeCount = categories.flatMap(c => c.rules).filter(r => r.enabled).length;

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ClipboardList className="w-5 h-5" style={{ color: '#58a6ff' }} />
            <h1 className="text-xl font-black text-balance" style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
              Deployment Rules
            </h1>
          </div>
          <p className="text-sm text-pretty" style={{ color: '#8b949e' }}>
            Set simple rules for your project. We'll enforce them automatically.
          </p>
        </div>
        <button onClick={handleSave}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all duration-200 active:scale-[0.97] shrink-0"
          style={{
            background: saved ? 'rgba(74,168,110,0.18)' : 'linear-gradient(135deg,#1d4ed8,#2563eb)',
            color: saved ? '#7ee787' : '#e0e7ff',
            border: `1px solid ${saved ? 'rgba(126,231,135,0.35)' : 'rgba(88,166,255,0.30)'}`,
          }}>
          {saved ? '✓ Saved' : 'Save Rules'}
        </button>
      </div>

      {/* Active count banner */}
      {activeCount === 0 && (
        <div className="glass rounded-xl px-5 py-3 flex items-center gap-3 anim-fade-in"
          style={{ borderColor: 'rgba(227,179,65,0.30)' }}>
          <AlertCircle className="w-4 h-4 shrink-0" style={{ color: '#e3b341' }} />
          <p className="text-sm" style={{ color: '#e3b341' }}>
            No policies are active — deployments will not be checked. Turn on at least one rule.
          </p>
        </div>
      )}

      {/* Policy categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories.map(cat => (
          <div key={cat.id} className="glass rounded-2xl overflow-hidden">
            <div className="px-5 py-3 flex items-center gap-2"
              style={{ borderBottom: '1px solid rgba(88,166,255,0.08)' }}>
              <div className="w-2 h-2 rounded-full" style={{ background: cat.color }} />
              <span className="text-sm font-bold" style={{ color: cat.color }}>{cat.label}</span>
              <span className="ml-auto text-xs font-mono" style={{ color: 'rgba(139,148,158,0.55)' }}>
                {cat.rules.filter(r => r.enabled).length}/{cat.rules.length} active
              </span>
            </div>
            <div className="p-4 space-y-3">
              {cat.rules.map(rule => (
                <div key={rule.id} className="flex items-start gap-3">
                  <Toggle on={rule.enabled} onToggle={() => toggleRule(cat.id, rule.id)} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium leading-snug text-pretty"
                      style={{ color: rule.enabled ? '#e6edf3' : '#8b949e' }}>
                      {rule.label}
                    </p>
                    <p className="text-xs mt-0.5 text-pretty leading-relaxed" style={{ color: 'rgba(139,148,158,0.65)' }}>
                      {rule.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Fix-It Reports */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4" style={{ color: '#f85149' }} />
          <h2 className="text-base font-bold" style={{ color: '#e6edf3' }}>Fix-It Reports</h2>
          <span className="text-xs ml-1" style={{ color: '#8b949e' }}>— Deployments rejected by your policies</span>
        </div>

        {SAMPLE_REPORTS.length === 0 ? (
          <div className="glass rounded-xl px-5 py-6 text-center">
            <p className="text-sm" style={{ color: '#8b949e' }}>All deployments passed policy checks</p>
          </div>
        ) : (
          <div className="space-y-2">
            {SAMPLE_REPORTS.map(r => <ReportRow key={r.id} report={r} />)}
          </div>
        )}
      </div>
    </div>
  );
}
