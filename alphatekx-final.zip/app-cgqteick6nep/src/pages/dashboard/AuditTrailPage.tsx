import { useState, useEffect, useCallback } from 'react';
import {
  History, Search, RotateCcw, CheckCircle2, XCircle,
  Star, X, Loader2, AlertTriangle, RefreshCw,
  Shield, Wrench, Rocket, FileText, ClipboardList, GitBranch,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

/* ── Types ─────────────────────────────────────────────────── */
type ActionType = 'File Upload' | 'Code Paste' | 'Security Scan' | 'Auto-Fix' | 'Dep Check'
                | 'Deployment'  | 'Policy Change' | 'Rollback' | 'Manual Review Flagged';
type LogStatus  = 'Success' | 'Failed' | 'In Progress';

interface AuditEntry {
  id: string;
  created_at: string;
  subdomain: string;
  action: ActionType;
  actor: string;
  details: string;
  status: LogStatus;
  security_score: number | null;
  manual_flags: string[] | null;
}

/* ── Helpers ───────────────────────────────────────────────── */
function relativeTime(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60)   return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60)   return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24)   return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function formatTs(ts: string): string {
  const d = new Date(ts);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

const ACTION_META: Record<string, { color: string; icon: React.ElementType }> = {
  'File Upload':           { color: '#58a6ff', icon: FileText        },
  'Code Paste':            { color: '#58a6ff', icon: FileText        },
  'Security Scan':         { color: '#e3b341', icon: Shield          },
  'Auto-Fix':              { color: '#a5b4fc', icon: Wrench          },
  'Dep Check':             { color: '#a5b4fc', icon: GitBranch       },
  'Deployment':            { color: '#7ee787', icon: Rocket          },
  'Policy Change':         { color: '#f0883e', icon: ClipboardList   },
  'Rollback':              { color: '#f85149', icon: RotateCcw       },
  'Manual Review Flagged': { color: '#e3b341', icon: AlertTriangle   },
};

/* ── Badges ────────────────────────────────────────────────── */
function StatusBadge({ status }: { status: LogStatus }) {
  const cfg: Record<LogStatus, { bg: string; color: string; Icon: React.ElementType }> = {
    'Success':     { bg: 'rgba(126,231,135,0.10)', color: '#7ee787', Icon: CheckCircle2  },
    'Failed':      { bg: 'rgba(248,81,73,0.10)',   color: '#f85149', Icon: XCircle        },
    'In Progress': { bg: 'rgba(88,166,255,0.10)',  color: '#58a6ff', Icon: Loader2        },
  };
  const { bg, color, Icon } = cfg[status];
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0"
      style={{ background: bg, color, border: `1px solid ${color}33` }}>
      <Icon className="w-2.5 h-2.5" />
      {status}
    </span>
  );
}

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 80 ? '#7ee787' : score >= 60 ? '#e3b341' : '#f85149';
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0"
      style={{ background: `${color}14`, color, border: `1px solid ${color}33` }}>
      <Shield className="w-2.5 h-2.5" />
      {score}/100
    </span>
  );
}

/* ── Rollback Confirm Dialog ───────────────────────────────── */
interface RbDialogProps { targetLabel: string; onConfirm: () => void; onCancel: () => void; }
function RollbackDialog({ targetLabel, onConfirm, onCancel }: RbDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(5,13,26,0.88)', backdropFilter: 'blur(12px)' }}>
      <div className="glass-strong rounded-2xl w-full max-w-[calc(100%-2rem)] md:max-w-md p-6 space-y-4 anim-fade-up">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold" style={{ color: '#e6edf3' }}>Confirm Rollback</h3>
          <button onClick={onCancel} className="p-1 rounded-lg" style={{ color: '#8b949e' }}>
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-3 rounded-xl" style={{ background: 'rgba(126,231,135,0.06)', border: '1px solid rgba(126,231,135,0.14)' }}>
          <p className="text-xs text-pretty" style={{ color: '#8b949e' }}>
            Rolling back to: <strong style={{ color: '#7ee787' }}>{targetLabel}</strong>
          </p>
        </div>
        <p className="text-sm text-pretty leading-relaxed" style={{ color: '#8b949e' }}>
          Your live site will be replaced with this deployment. This action is recorded in your audit trail.
        </p>
        <div className="flex gap-3">
          <button onClick={onConfirm}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold transition-all active:scale-[0.97]"
            style={{ background: 'linear-gradient(135deg,#1d4ed8,#2563eb)', color: '#e0e7ff', border: '1px solid rgba(88,166,255,0.30)' }}>
            <RotateCcw className="w-4 h-4" /> Confirm Rollback
          </button>
          <button onClick={onCancel}
            className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all active:scale-[0.97]"
            style={{ background: 'rgba(88,166,255,0.06)', color: '#8b949e', border: '1px solid rgba(88,166,255,0.14)' }}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   AUDIT TRAIL PAGE
══════════════════════════════════════════════════════════════════ */
export default function AuditTrailPage() {
  const { session } = useAuth();
  const [log,            setLog]            = useState<AuditEntry[]>([]);
  const [loading,        setLoading]        = useState(true);
  const [search,         setSearch]         = useState('');
  const [rollbackTarget, setRollbackTarget] = useState<AuditEntry | null>(null);
  const [rolledBack,     setRolledBack]     = useState<string | null>(null);

  /* Load real events from Supabase */
  const loadEvents = useCallback(async () => {
    if (!session?.user?.id) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('audit_events')
      .select('id, created_at, subdomain, action, actor, details, status, security_score, manual_flags')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false })
      .limit(100);
    if (!error && data) setLog(data as AuditEntry[]);
    setLoading(false);
  }, [session?.user?.id]);

  useEffect(() => { loadEvents(); }, [loadEvents]);

  /* Deployments (for version history section) */
  const deployments = log.filter(e => e.action === 'Deployment').slice(0, 6);

  const filtered = search.trim()
    ? log.filter(e =>
        e.action.toLowerCase().includes(search.toLowerCase()) ||
        e.details.toLowerCase().includes(search.toLowerCase()) ||
        e.subdomain.toLowerCase().includes(search.toLowerCase()) ||
        e.actor.toLowerCase().includes(search.toLowerCase())
      )
    : log;

  const confirmRollback = async () => {
    if (!rollbackTarget || !session?.user?.id) return;
    const target = rollbackTarget;
    const details = `Rolled back to deployment from ${formatTs(target.created_at)} — ${target.subdomain}.`;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any).from('audit_events').insert([{
      user_id: session.user.id,
      subdomain: target.subdomain,
      action: 'Rollback',
      actor: 'You',
      details,
      status: 'Success',
    }]);
    setRolledBack(target.subdomain);
    setRollbackTarget(null);
    setTimeout(() => setRolledBack(null), 3500);
    await loadEvents();
  };

  /* Stats from real data */
  const totalDeploys  = log.filter(e => e.action === 'Deployment').length;
  const autoFixes     = log.filter(e => e.action === 'Auto-Fix').length;
  const scanIssues    = log.filter(e => e.action === 'Security Scan').length;
  const latestScore   = log.find(e => e.security_score != null)?.security_score ?? null;
  const scoreColor    = latestScore == null ? '#8b949e' : latestScore >= 80 ? '#7ee787' : latestScore >= 60 ? '#e3b341' : '#f85149';

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <History className="w-5 h-5" style={{ color: '#58a6ff' }} />
            <h1 className="text-xl font-black text-balance" style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
              Deployment History
            </h1>
          </div>
          <p className="text-sm text-pretty" style={{ color: '#8b949e' }}>
            A complete record of everything that's happened — scans, auto-fixes, deploys, and rollbacks.
          </p>
        </div>
        <button onClick={loadEvents}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all active:scale-[0.97] shrink-0"
          style={{ background: 'rgba(88,166,255,0.08)', color: '#58a6ff', border: '1px solid rgba(88,166,255,0.18)' }}>
          <RefreshCw className="w-3.5 h-3.5" /> Refresh
        </button>
      </div>

      {/* Rollback success */}
      {rolledBack && (
        <div className="glass rounded-xl px-5 py-3 flex items-center gap-2 anim-fade-in"
          style={{ borderColor: 'rgba(126,231,135,0.30)' }}>
          <CheckCircle2 className="w-4 h-4" style={{ color: '#7ee787' }} />
          <p className="text-sm font-semibold" style={{ color: '#7ee787' }}>
            Rollback logged — {rolledBack} restored.
          </p>
        </div>
      )}

      {/* Stats band */}
      {!loading && log.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Deployments',  value: totalDeploys,          color: '#7ee787', icon: Rocket      },
            { label: 'Auto-Fixes',   value: autoFixes,             color: '#a5b4fc', icon: Wrench      },
            { label: 'Scans Run',    value: scanIssues,            color: '#e3b341', icon: Shield      },
            { label: 'Security',     value: latestScore != null ? `${latestScore}/100` : '—', color: scoreColor, icon: Shield },
          ].map(({ label, value, color, icon: Ic }) => (
            <div key={label} className="glass rounded-2xl p-4 flex flex-col gap-1 h-full">
              <Ic className="w-4 h-4 mb-0.5" style={{ color }} />
              <span className="text-xl font-black" style={{ color }}>{value}</span>
              <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'rgba(139,148,158,0.60)' }}>{label}</span>
            </div>
          ))}
        </div>
      )}

      {/* ── Deployment Version History ── */}
      {deployments.length > 0 && (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="px-5 py-4" style={{ borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
            <h2 className="text-sm font-bold" style={{ color: '#e6edf3' }}>Deployment Versions</h2>
            <p className="text-xs mt-0.5" style={{ color: '#8b949e' }}>Tap Rollback to restore a previous deployment.</p>
          </div>
          <div className="divide-y" style={{ borderColor: 'rgba(88,166,255,0.07)' }}>
            {deployments.map((dep, i) => (
              <div key={dep.id} className="flex items-center gap-4 px-5 py-3.5 flex-wrap gap-y-2">
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold" style={{ color: '#e6edf3' }}>
                      {dep.subdomain}.alphatekx.name.ng
                    </span>
                    {i === 0 && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                        style={{ background: 'rgba(126,231,135,0.12)', color: '#7ee787', border: '1px solid rgba(126,231,135,0.25)' }}>
                        <Star className="w-2.5 h-2.5 inline mr-0.5" />Current
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-mono" style={{ color: '#8b949e' }}>
                    {formatTs(dep.created_at)} · {relativeTime(dep.created_at)}
                  </p>
                </div>

                {dep.security_score != null && <ScoreBadge score={dep.security_score} />}
                <StatusBadge status={dep.status as LogStatus} />

                <button
                  disabled={i === 0}
                  onClick={() => setRollbackTarget(dep)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all active:scale-[0.97] disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
                  style={{ background: 'rgba(88,166,255,0.08)', color: '#58a6ff', border: '1px solid rgba(88,166,255,0.18)' }}>
                  <RotateCcw className="w-3.5 h-3.5" />
                  {i === 0 ? 'Current' : 'Rollback'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Immutable Audit Log ── */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="px-5 py-4 flex items-center gap-3 flex-wrap"
          style={{ borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
          <h2 className="text-sm font-bold" style={{ color: '#e6edf3' }}>Immutable Audit Log</h2>
          {loading && <Loader2 className="w-3.5 h-3.5 animate-spin" style={{ color: '#58a6ff' }} />}
          <div className="ml-auto flex items-center gap-2 rounded-xl px-3 py-2"
            style={{ background: 'rgba(4,10,24,0.60)', border: '1px solid rgba(88,166,255,0.16)' }}>
            <Search className="w-3.5 h-3.5 shrink-0" style={{ color: '#8b949e' }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search actions…"
              className="bg-transparent outline-none text-xs w-36"
              style={{ color: '#e6edf3', caretColor: '#58a6ff' }}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-12">
            <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#58a6ff' }} />
            <span className="text-sm" style={{ color: '#8b949e' }}>Loading your history…</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-14 flex flex-col items-center gap-3 text-center px-4">
            <History className="w-8 h-8 opacity-30" style={{ color: '#58a6ff' }} />
            <p className="text-sm font-semibold" style={{ color: '#8b949e' }}>
              {search ? 'No matching entries' : 'No history yet'}
            </p>
            <p className="text-xs text-pretty" style={{ color: 'rgba(139,148,158,0.55)' }}>
              {search ? 'Try a different search term.' : 'Deploy a project to see your activity here.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-max">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(88,166,255,0.08)' }}>
                  {['Time', 'Action', 'Site', 'Who', 'Details', 'Status'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap"
                      style={{ color: 'rgba(88,166,255,0.55)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((e, idx) => {
                  const meta = ACTION_META[e.action] ?? { color: '#8b949e', icon: History };
                  const Ic   = meta.icon;
                  return (
                    <tr key={e.id}
                      className={idx === 0 ? 'anim-fade-in' : ''}
                      style={{ borderBottom: '1px solid rgba(88,166,255,0.06)' }}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <p className="text-xs font-mono" style={{ color: 'rgba(139,148,158,0.70)' }}>{formatTs(e.created_at)}</p>
                        <p className="text-[10px]" style={{ color: 'rgba(139,148,158,0.45)' }}>{relativeTime(e.created_at)}</p>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold" style={{ color: meta.color }}>
                          <Ic className="w-3 h-3" />{e.action}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-xs font-mono"
                        style={{ color: 'rgba(88,166,255,0.70)' }}>
                        {e.subdomain ? `${e.subdomain}` : '—'}
                      </td>
                      <td className="px-4 py-3 text-xs whitespace-nowrap" style={{ color: '#8b949e' }}>{e.actor}</td>
                      <td className="px-4 py-3 text-xs text-pretty leading-snug" style={{ color: '#c9d1d9', maxWidth: '260px' }}>
                        {e.details}
                        {e.manual_flags && e.manual_flags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {e.manual_flags.map(f => (
                              <span key={f} className="text-[9px] px-1.5 py-0.5 rounded-full"
                                style={{ background: 'rgba(227,179,65,0.10)', color: '#e3b341', border: '1px solid rgba(227,179,65,0.22)' }}>
                                {f.split(':')[0]}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap"><StatusBadge status={e.status as LogStatus} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Rollback dialog */}
      {rollbackTarget && (
        <RollbackDialog
          targetLabel={`${rollbackTarget.subdomain}.alphatekx.name.ng (${formatTs(rollbackTarget.created_at)})`}
          onConfirm={confirmRollback}
          onCancel={() => setRollbackTarget(null)}
        />
      )}
    </div>
  );
}

