import { useState, useCallback, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Rocket, ArrowLeft, FileText, FolderOpen, X,
  Link2, Zap, LogOut, Code2, Globe,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import TopUpModal from '@/components/TopUpModal';

function Orb({ cls }: { cls: string }) {
  return <div className={`pointer-events-none absolute rounded-full blur-3xl opacity-[0.15] ${cls}`} />;
}

function formatBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / (1024 * 1024)).toFixed(1)} MB`;
}

interface DroppedFile { name: string; size: number; file: File; relativePath: string; }
type InputTab = 'files' | 'code' | 'link';

/* ── Tab button ───────────────────────────────────────────── */
function Tab({ active, onClick, icon: Icon, label }: {
  active: boolean; onClick: () => void; icon: React.ElementType; label: string;
}) {
  return (
    <button onClick={onClick}
      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-semibold rounded-xl transition-all duration-200"
      style={{
        background: active ? 'rgba(88,166,255,0.12)' : 'transparent',
        color: active ? '#58a6ff' : '#8b949e',
        border: active ? '1px solid rgba(88,166,255,0.25)' : '1px solid transparent',
      }}>
      <Icon className="w-3.5 h-3.5 shrink-0" />
      {label}
    </button>
  );
}

/* ── Ingestion Page ───────────────────────────────────────── */
export default function IngestionPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile, signOut, refreshCredits } = useAuth();
  const subdomain: string = (location.state as { subdomain?: string })?.subdomain ?? '';

  useEffect(() => { if (!subdomain) navigate('/claim', { replace: true }); }, [subdomain, navigate]);

  const [tab,       setTab]       = useState<InputTab>('files');
  const [dragging,  setDragging]  = useState(false);
  const [files,     setFiles]     = useState<DroppedFile[]>([]);
  const [url,       setUrl]       = useState('');
  const [code,      setCode]      = useState('');
  const [showTopUp, setShowTopUp] = useState(false);
  const fileInputRef   = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const addFiles = useCallback((rawFiles: FileList | File[]) => {
    const items = Array.from(rawFiles).map(f => {
      const rel = (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name;
      return { name: f.name, size: f.size, file: f, relativePath: rel };
    });
    if (items.length) setFiles(prev => {
      // Merge — deduplicate by relativePath
      const map = new Map(prev.map(p => [p.relativePath, p]));
      items.forEach(i => map.set(i.relativePath, i));
      return Array.from(map.values());
    });
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    addFiles(e.dataTransfer.files);
  }, [addFiles]);

  const handleBrowseFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) addFiles(e.target.files);
    e.target.value = '';
  };

  const canDeploy =
    (tab === 'files' && files.length > 0) ||
    (tab === 'code'  && code.trim().length > 0) ||
    (tab === 'link'  && url.trim().length > 0);

  const handleDeploy = () => {
    if (!canDeploy) return;

    if (tab === 'code') {
      // Wrap bare HTML/CSS/JS in a full page if needed
      const content = code.trim();
      const html = content.startsWith('<!') || content.startsWith('<html')
        ? content
        : `<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>My Site</title>\n</head>\n<body>\n${content}\n</body>\n</html>`;
      const blob = new Blob([html], { type: 'text/html' });
      const file = new File([blob], 'index.html', { type: 'text/html' });
      navigate('/pipeline', {
        state: { subdomain, files: [file], fileCount: 1, method: 'upload', url: '' },
      });
      return;
    }

    if (tab === 'link') {
      navigate('/pipeline', {
        state: { subdomain, url, files: [], fileCount: 0, method: 'url' },
      });
      return;
    }

    // files tab
    navigate('/pipeline', {
      state: {
        subdomain,
        url: '',
        files: files.map(f => f.file),
        fileCount: files.length,
        method: 'upload',
      },
    });
  }

  return (
    <>
    {showTopUp && <TopUpModal onClose={() => setShowTopUp(false)} onSuccess={() => { refreshCredits(); setShowTopUp(false); }} />}
    <div className="relative min-h-screen w-full overflow-x-hidden flex flex-col items-center justify-center px-4 py-16"
      style={{ background: '#050d1a' }}>
      <Orb cls="w-[420px] h-[420px] bg-indigo-700 top-[-100px] right-[-80px] anim-orb-float" />
      <Orb cls="w-[320px] h-[320px] bg-blue-700 bottom-[-60px] left-[-60px] anim-orb-float delay-500" />

      {/* Auth nav strip */}
      {profile && (
        <div className="fixed top-0 left-0 right-0 z-40 h-12 flex items-center justify-between px-4 md:px-8"
          style={{ background: 'rgba(5,13,26,0.88)', backdropFilter: 'blur(16px)', borderBottom: '1px solid rgba(88,166,255,0.08)' }}>
          <span className="text-xs font-bold tracking-widest uppercase hidden sm:block"
            style={{ color: 'rgba(88,166,255,0.60)' }}>AlphaTekx</span>
          <div className="flex items-center gap-3 ml-auto">
            <button onClick={() => setShowTopUp(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold transition-opacity hover:opacity-80"
              style={{ background: 'rgba(240,136,62,0.10)', border: '1px solid rgba(240,136,62,0.25)', color: '#f0883e' }}>
              <Zap className="w-3 h-3" />
              {profile.credit_balance} credits
            </button>
            {profile.avatar_url
              ? <img src={profile.avatar_url} alt="avatar" className="w-7 h-7 rounded-full object-cover shrink-0" style={{ border: '1px solid rgba(88,166,255,0.25)' }} />
              : <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold"
                  style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
                  {(profile.full_name ?? profile.email ?? 'U')[0].toUpperCase()}
                </div>
            }
            <button onClick={signOut} className="p-1 rounded-lg transition-opacity hover:opacity-70" title="Sign out"
              style={{ color: '#8b949e' }}>
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Back */}
      <div className="relative z-10 w-full max-w-lg mb-5 mt-6 anim-fade-in">
        <button onClick={() => navigate('/claim', { state: { subdomain } })}
          className="flex items-center gap-1.5 text-xs font-medium transition-colors"
          style={{ color: 'rgba(139,148,158,0.60)' }}>
          <ArrowLeft className="w-3.5 h-3.5" /> Back
        </button>
      </div>

      {/* Subdomain badge */}
      <div className="relative z-10 w-full max-w-lg mb-4 anim-fade-up">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{ background: 'rgba(88,166,255,0.08)', border: '1px solid rgba(88,166,255,0.18)' }}>
          <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#58a6ff' }} />
          <span className="text-xs font-mono" style={{ color: '#58a6ff' }}>
            {subdomain}.alphatekx.name.ng
          </span>
        </div>
      </div>

      <h2 className="relative z-10 w-full max-w-lg text-2xl md:text-3xl font-black text-balance mb-1 anim-fade-up delay-100"
        style={{ color: '#e6edf3', letterSpacing: '-0.02em' }}>
        Add your project content
      </h2>
      <p className="relative z-10 w-full max-w-lg text-sm mb-5 text-pretty anim-fade-up delay-150"
        style={{ color: '#8b949e' }}>
        Drop files, paste your HTML/CSS/JS code, or link to an existing site.
      </p>

      {/* Glass card */}
      <div className="relative z-10 glass-strong rounded-2xl w-full max-w-lg p-5 md:p-6 anim-fade-up delay-200 space-y-4">

        {/* ── Tab selector ── */}
        <div className="flex items-center gap-1 p-1 rounded-xl"
          style={{ background: 'rgba(4,10,24,0.55)', border: '1px solid rgba(88,166,255,0.12)' }}>
          <Tab active={tab === 'files'} onClick={() => setTab('files')} icon={FolderOpen} label="Drop Files" />
          <Tab active={tab === 'code'}  onClick={() => setTab('code')}  icon={Code2}      label="Paste Code" />
          <Tab active={tab === 'link'}  onClick={() => setTab('link')}  icon={Globe}      label="Paste Link" />
        </div>

        {/* ══ FILES TAB ══ */}
        {tab === 'files' && (
          <>
            {/* Hidden inputs */}
            <input ref={fileInputRef}   type="file" multiple className="hidden" onChange={handleBrowseFiles} />
            <input ref={folderInputRef} type="file" multiple className="hidden" onChange={handleBrowseFiles}
              // @ts-expect-error – non-standard but universally supported
              webkitdirectory="true" directory="true" />

            <div
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              className="flex flex-col items-center justify-center gap-4 rounded-2xl py-8 px-4 transition-all duration-200"
              style={{
                background: dragging ? 'rgba(88,166,255,0.08)' : 'rgba(4,10,24,0.50)',
                border: `2px dashed ${dragging ? '#58a6ff' : 'rgba(88,166,255,0.28)'}`,
                minHeight: '160px',
              }}>
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{
                  background: dragging ? 'rgba(88,166,255,0.15)' : 'rgba(88,166,255,0.07)',
                  border: `1px solid ${dragging ? 'rgba(88,166,255,0.50)' : 'rgba(88,166,255,0.18)'}`,
                }}>
                <FolderOpen className="w-7 h-7" style={{ color: dragging ? '#58a6ff' : 'rgba(88,166,255,0.45)' }} />
              </div>
              <div className="text-center">
                <p className="text-sm font-bold" style={{ color: dragging ? '#58a6ff' : '#c9d1d9' }}>
                  {dragging ? 'Drop it here!' : 'Drag & drop files or a folder'}
                </p>
                <p className="text-xs mt-1" style={{ color: '#8b949e' }}>or browse below</p>
              </div>
              {/* Browse buttons */}
              <div className="flex gap-2">
                <button type="button" onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:opacity-80"
                  style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
                  <FileText className="w-3.5 h-3.5" /> Select Files
                </button>
                <button type="button" onClick={() => folderInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:opacity-80"
                  style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
                  <FolderOpen className="w-3.5 h-3.5" /> Select Folder
                </button>
              </div>
            </div>

            {files.length > 0 && (
              <div className="rounded-xl overflow-hidden anim-fade-in"
                style={{ border: '1px solid rgba(88,166,255,0.14)' }}>
                <div className="px-3 py-2 flex items-center justify-between"
                  style={{ background: 'rgba(88,166,255,0.06)', borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
                  <span className="text-xs font-semibold" style={{ color: '#58a6ff' }}>
                    {files.length} file{files.length !== 1 ? 's' : ''} ready
                  </span>
                  <button onClick={() => setFiles([])} className="p-0.5 rounded" style={{ color: '#8b949e' }}>
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="max-h-36 overflow-y-auto">
                  {files.slice(0, 30).map((f, i) => (
                    <div key={i} className="flex items-center gap-2 px-3 py-2 border-b last:border-0"
                      style={{ borderColor: 'rgba(88,166,255,0.08)' }}>
                      <FileText className="w-3.5 h-3.5 shrink-0" style={{ color: 'rgba(88,166,255,0.50)' }} />
                      <span className="flex-1 min-w-0 text-xs font-mono truncate" style={{ color: '#c9d1d9' }}>
                        {f.relativePath}
                      </span>
                      <span className="text-xs shrink-0" style={{ color: '#8b949e' }}>{formatBytes(f.size)}</span>
                    </div>
                  ))}
                  {files.length > 30 && (
                    <div className="px-3 py-2 text-xs text-center" style={{ color: '#8b949e' }}>
                      +{files.length - 30} more files
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}

        {/* ══ CODE TAB ══ */}
        {tab === 'code' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs" style={{ color: '#8b949e' }}>
                Paste your HTML, CSS, or JavaScript — we'll wrap it and deploy it.
              </p>
              {code && (
                <button onClick={() => setCode('')} className="shrink-0 p-1 rounded" style={{ color: '#8b949e' }}>
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <div className="rounded-xl overflow-hidden"
              style={{ border: `1px solid ${code ? 'rgba(88,166,255,0.40)' : 'rgba(88,166,255,0.20)'}` }}>
              {/* Fake code editor header */}
              <div className="flex items-center gap-1.5 px-3 py-2"
                style={{ background: 'rgba(4,10,24,0.80)', borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'rgba(248,81,73,0.55)' }} />
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'rgba(227,179,65,0.55)' }} />
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'rgba(126,231,135,0.55)' }} />
                <span className="ml-2 text-[10px] font-mono" style={{ color: 'rgba(139,148,158,0.50)' }}>index.html</span>
                {code && (
                  <span className="ml-auto text-[10px] font-mono" style={{ color: 'rgba(139,148,158,0.50)' }}>
                    {code.length.toLocaleString()} chars
                  </span>
                )}
              </div>
              <textarea
                value={code}
                onChange={e => setCode(e.target.value)}
                placeholder={'<!-- Paste your HTML here -->\n<h1>Hello World!</h1>\n<p>Your site is ready to go live.</p>'}
                spellCheck={false}
                className="w-full px-4 py-3 text-xs font-mono bg-transparent outline-none resize-none leading-relaxed"
                style={{
                  color: '#c9d1d9',
                  caretColor: '#58a6ff',
                  background: 'rgba(4,10,24,0.70)',
                  minHeight: '220px',
                  tabSize: 2,
                }}
              />
            </div>
            {code.trim().length > 0 && (
              <p className="text-xs anim-fade-in" style={{ color: 'rgba(126,231,135,0.70)' }}>
                Ready — your code will be saved as <code className="font-mono">index.html</code> and deployed.
              </p>
            )}
          </div>
        )}

        {/* ══ LINK TAB ══ */}
        {tab === 'link' && (
          <div className="space-y-2">
            <p className="text-xs" style={{ color: '#8b949e' }}>
              Paste a URL to a GitHub repo, a .zip file, or a live website to clone and deploy.
            </p>
            <div className="flex items-stretch rounded-xl overflow-hidden transition-all duration-200"
              style={{
                background: 'rgba(4,10,24,0.72)',
                border: `1px solid ${url ? 'rgba(88,166,255,0.45)' : 'rgba(88,166,255,0.20)'}`,
              }}>
              <div className="flex items-center px-3 shrink-0"
                style={{ borderRight: '1px solid rgba(88,166,255,0.12)' }}>
                <Link2 className="w-4 h-4" style={{ color: 'rgba(88,166,255,0.50)' }} />
              </div>
              <input
                type="url"
                value={url}
                onChange={e => setUrl(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleDeploy(); }}
                placeholder="https://github.com/user/repo  or  https://example.com"
                className="flex-1 min-w-0 px-3 py-3.5 text-sm bg-transparent outline-none"
                style={{ color: '#e6edf3', caretColor: '#58a6ff' }}
              />
              {url && (
                <button onClick={() => setUrl('')} className="flex items-center px-3 shrink-0"
                  style={{ color: '#8b949e' }}>
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            {url.trim().length > 0 && (
              <p className="text-xs anim-fade-in" style={{ color: 'rgba(126,231,135,0.70)' }}>
                We'll fetch, secure, and deploy this for you.
              </p>
            )}
          </div>
        )}

        {/* ── CTA ── */}
        <button onClick={handleDeploy} disabled={!canDeploy}
          className="w-full flex items-center justify-center gap-2 rounded-xl py-4 font-bold transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]"
          style={{
            background: 'linear-gradient(135deg, #1d4ed8, #2563eb)',
            color: '#e0e7ff',
            border: '1px solid rgba(88,166,255,0.30)',
            boxShadow: canDeploy ? '0 4px 28px rgba(37,99,235,0.40)' : 'none',
            fontSize: '1.0625rem',
          }}>
          <Rocket className="w-5 h-5" />
          Secure &amp; Deploy
        </button>
      </div>

      <p className="relative z-10 mt-5 text-xs text-center anim-fade-up delay-700"
        style={{ color: 'rgba(139,148,158,0.38)' }}>
        We lock, secure, and deploy everything automatically — nothing technical required
      </p>
    </div>
    </>
  );
}

