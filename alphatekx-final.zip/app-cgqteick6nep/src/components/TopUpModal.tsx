import { useState } from 'react';
import { X, Zap, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface Plan { key: string; name: string; price: number; credits: number; popular?: boolean; }

const PLANS: Plan[] = [
  { key: 'starter',    name: 'Starter',    price: 500,  credits: 10  },
  { key: 'pro',        name: 'Pro',        price: 2000, credits: 50, popular: true },
  { key: 'enterprise', name: 'Enterprise', price: 5000, credits: 150 },
];

interface TopUpModalProps {
  onClose: () => void;
  onSuccess?: (newBalance: number) => void;
}

declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    PaystackPop: any;
  }
}

export default function TopUpModal({ onClose, onSuccess }: TopUpModalProps) {
  const { profile, refreshCredits } = useAuth();
  const [loading, setLoading] = useState<string | null>(null);

  const PAYSTACK_KEY = import.meta.env.VITE_PAYSTACK_PUBLIC_KEY as string;

  const handleSelect = async (plan: Plan) => {
    if (!profile?.email) return;
    setLoading(plan.key);

    const reference = `atx_${plan.key}_${Date.now()}`;

    // Load Paystack inline script if not loaded
    if (!window.PaystackPop) {
      await new Promise<void>((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'https://js.paystack.co/v1/inline.js';
        s.onload = () => resolve();
        s.onerror = () => reject(new Error('Paystack script failed to load'));
        document.head.appendChild(s);
      });
    }

    const handler = window.PaystackPop.setup({
      key: PAYSTACK_KEY,
      email: profile.email,
      amount: plan.price * 100, // in kobo
      currency: 'NGN',
      ref: reference,
      metadata: {
        custom_fields: [],
        plan_key: plan.key,
        plan_name: plan.name,
        credits: plan.credits,
        user_id: profile.id,
        email: profile.email,
      },
      onSuccess: async () => {
        // Refresh balance from server (webhook updates it server-side)
        await new Promise(r => setTimeout(r, 1500)); // short wait for webhook
        await refreshCredits();
        const { data } = await supabase.from('profiles').select('credit_balance').eq('id', profile.id).maybeSingle();
        const row = data as { credit_balance: number } | null;
        onSuccess?.(row?.credit_balance ?? 0);
        setLoading(null);
        onClose();
      },
      onCancel: () => setLoading(null),
    });

    handler.openIframe();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(5,13,26,0.85)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="relative w-full max-w-[calc(100%-2rem)] md:max-w-lg rounded-3xl p-6 md:p-8 anim-fade-up"
        style={{
          background: 'rgba(13,17,31,0.96)',
          backdropFilter: 'blur(24px)',
          border: '1px solid rgba(88,166,255,0.16)',
          boxShadow: '0 24px 80px rgba(0,0,0,0.60)',
        }}>
        <button onClick={onClose} className="absolute top-4 right-4 p-1.5 rounded-lg hover:opacity-70 transition-opacity"
          style={{ color: '#8b949e' }}>
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <Zap className="w-5 h-5" style={{ color: '#f0883e' }} />
          <h2 className="text-lg font-black" style={{ color: '#e6edf3' }}>Top Up Your Credits</h2>
        </div>
        <p className="text-sm mb-6 text-pretty" style={{ color: '#8b949e' }}>
          Each deployment costs 1 credit. Choose a plan to continue.
        </p>

        {/* Current balance */}
        {profile && (
          <div className="mb-5 flex items-center gap-2 px-3 py-2 rounded-xl"
            style={{ background: 'rgba(88,166,255,0.06)', border: '1px solid rgba(88,166,255,0.12)' }}>
            <span className="text-xs" style={{ color: '#8b949e' }}>Current balance:</span>
            <span className="text-sm font-bold" style={{ color: '#58a6ff' }}>
              {profile.credit_balance} credits
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {PLANS.map(plan => (
            <div key={plan.key} className="relative flex flex-col rounded-2xl p-4 transition-all duration-200"
              style={{
                background: plan.popular ? 'rgba(88,166,255,0.08)' : 'rgba(4,10,24,0.60)',
                border: `1px solid ${plan.popular ? 'rgba(88,166,255,0.30)' : 'rgba(88,166,255,0.12)'}`,
              }}>
              {plan.popular && (
                <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[10px] font-bold"
                  style={{ background: 'rgba(88,166,255,0.20)', border: '1px solid rgba(88,166,255,0.35)', color: '#58a6ff' }}>
                  Popular
                </span>
              )}
              <p className="text-xs font-semibold mb-0.5" style={{ color: '#8b949e' }}>{plan.name}</p>
              <p className="text-xl font-black mb-0.5" style={{ color: '#e6edf3' }}>₦{plan.price.toLocaleString()}</p>
              <p className="text-sm font-semibold mb-4" style={{ color: '#58a6ff' }}>{plan.credits} credits</p>
              <button
                onClick={() => handleSelect(plan)}
                disabled={!!loading}
                className="mt-auto w-full flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-bold transition-all duration-200 hover:opacity-85 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  background: plan.popular ? 'linear-gradient(135deg,#1d4ed8,#2563eb)' : 'rgba(88,166,255,0.10)',
                  color: plan.popular ? '#e0e7ff' : '#58a6ff',
                  border: `1px solid ${plan.popular ? 'rgba(88,166,255,0.30)' : 'rgba(88,166,255,0.20)'}`,
                }}>
                {loading === plan.key
                  ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  : 'Select'}
              </button>
            </div>
          ))}
        </div>

        <p className="mt-5 text-[11px] text-center" style={{ color: 'rgba(139,148,158,0.40)' }}>
          Powered by Paystack · Secure payment · Credits added instantly after payment
        </p>
      </div>
    </div>
  );
}
