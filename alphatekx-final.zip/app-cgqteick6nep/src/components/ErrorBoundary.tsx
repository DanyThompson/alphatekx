import { Component, type ErrorInfo, type ReactNode } from 'react';

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

export default class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[app] Unhandled render error:', error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;

      return (
        <div className="min-h-screen flex items-center justify-center px-6 py-16" style={{ background: '#050d1a', color: '#e6edf3' }}>
          <div className="w-full max-w-md rounded-2xl border border-white/10 p-8 text-center shadow-2xl" style={{ background: 'rgba(13,17,31,0.90)' }}>
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full" style={{ background: 'rgba(248,81,73,0.14)' }}>
              <span className="text-xl font-black">!</span>
            </div>
            <h1 className="mb-2 text-xl font-black">Something went wrong</h1>
            <p className="mb-6 text-sm leading-relaxed" style={{ color: '#8b949e' }}>
              AlphaTekx hit an unexpected client-side error. Reloading usually restores the experience immediately.
            </p>
            <button
              onClick={this.handleReload}
              className="rounded-xl px-4 py-2 text-sm font-semibold transition-opacity hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, #1a4fbd, #2563eb)', color: '#e0e7ff' }}
            >
              Reload page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
