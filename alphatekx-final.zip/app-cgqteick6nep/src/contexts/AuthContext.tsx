import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

/* ── Profile type (matches DB schema) ────────────────────── */
export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  avatar_url: string | null;
  credit_balance: number;
  role: string | null;
  created_at: string;
}

/* ── Context shape ────────────────────────────────────────── */
interface AuthContextValue {
  user:             User    | null;
  session:          Session | null;
  profile:          Profile | null;
  loading:          boolean;
  signInWithGoogle: () => Promise<void>;
  signOut:          () => Promise<void>;
  refreshCredits:   () => Promise<void>;
}

const DEFAULT_CTX: AuthContextValue = {
  user:             null,
  session:          null,
  profile:          null,
  loading:          true,
  signInWithGoogle: async () => {},
  signOut:          async () => {},
  refreshCredits:   async () => {},
};

const AuthContext = createContext<AuthContextValue>(DEFAULT_CTX);

/* ── Provider ─────────────────────────────────────────────── */
export function AuthProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  /* Fetch or create the profile row for the signed-in user */
  const fetchProfile = useCallback(async (userId: string, userEmail?: string | null, userName?: string | null, avatarUrl?: string | null) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, full_name, avatar_url, credit_balance, role, created_at')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[auth] profile lookup failed:', error.message);
        return;
      }

      if (data) {
        setProfile(data as Profile);
        return;
      }

      const insertPayload = {
        id: userId,
        email: userEmail ?? null,
        full_name: userName ?? null,
        avatar_url: avatarUrl ?? null,
        credit_balance: 20,
        role: 'user',
      };

      const { data: inserted, error: insertError } = await supabase
        .from('profiles')
        .insert(insertPayload)
        .select('id, email, full_name, avatar_url, credit_balance, role, created_at')
        .single();

      if (insertError) {
        console.warn('[auth] profile create failed:', insertError.message);
      } else {
        setProfile(inserted as Profile);
      }
    } catch (err) {
      console.warn('[auth] profile bootstrap failed:', err);
    }
  }, []);

  /* Refresh only the credit balance */
  const refreshCredits = useCallback(async () => {
    if (!session?.user) return;
    const { data } = await supabase
      .from('profiles')
      .select('credit_balance')
      .eq('id', session.user.id)
      .maybeSingle();
    const row = data as { credit_balance: number } | null;
    if (row) setProfile(prev => prev ? { ...prev, credit_balance: row.credit_balance } : prev);
  }, [session]);

  /* Bootstrap auth on mount */
  useEffect(() => {
    const bootstrap = async () => {
      try {
        const { data: { session: s }, error } = await supabase.auth.getSession();
        if (error) {
          console.warn('[auth] getSession failed:', error.message);
        }
        setSession(s);
        if (s?.user) {
          await fetchProfile(s.user.id, s.user.email, s.user.user_metadata?.full_name ?? s.user.user_metadata?.name, s.user.user_metadata?.avatar_url);
        }
      } catch (err) {
        console.warn('[auth] bootstrap failed:', err);
      } finally {
        setLoading(false);
      }
    };

    bootstrap();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, s) => {
      setSession(s);
      if (s?.user) {
        await fetchProfile(s.user.id, s.user.email, s.user.user_metadata?.full_name ?? s.user.user_metadata?.name, s.user.user_metadata?.avatar_url);
        // Redirect to dashboard after fresh sign-in OR when token refreshes on return visit
        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
          const path = window.location.pathname;
          // Only redirect from public/auth pages — never interrupt mid-flow app pages
          if (path === '/' || path === '/login' || path === '/auth/callback' || path === '/signup') {
            navigate('/dashboard', { replace: true });
          }
        }
      } else {
        setProfile(null);
        if (event === 'SIGNED_OUT') {
          navigate('/login', { replace: true });
        }
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile, navigate]);

  /* Real Google OAuth using Supabase Auth */
  const signInWithGoogle = async () => {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });

    if (error) {
      console.error('[auth] Google OAuth error:', error.message);
      throw error;
    }

    if (data?.url) {
      window.location.assign(data.url);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setSession(null);
  };

  return (
    <AuthContext.Provider value={{
      user:    session?.user ?? null,
      session,
      profile,
      loading,
      signInWithGoogle,
      signOut,
      refreshCredits,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

/* ── Hook ─────────────────────────────────────────────────── */
export function useAuth() {
  return useContext(AuthContext);
}
