import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import ErrorBoundary from '@/components/ErrorBoundary';
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/LoginPage';
import AuthCallbackPage from '@/pages/AuthCallbackPage';
import WelcomePage from '@/pages/WelcomePage';
import IngestionPage from '@/pages/IngestionPage';
import PipelinePage from '@/pages/PipelinePage';
import LiveSitePage from '@/pages/LiveSitePage';
import DashboardLayout from '@/layouts/DashboardLayout';
import OverviewPage from '@/pages/dashboard/OverviewPage';
import SecurityShieldPage from '@/pages/dashboard/SecurityShieldPage';
import PolicyEnginePage from '@/pages/dashboard/PolicyEnginePage';
import AuditTrailPage from '@/pages/dashboard/AuditTrailPage';

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Routes>
          <Route path="/"              element={<LandingPage />} />
          <Route path="/login"         element={<LoginPage />} />
          <Route path="/signup"        element={<LoginPage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/claim"         element={<WelcomePage />} />
          <Route path="/deploy"        element={<IngestionPage />} />
          <Route path="/pipeline"      element={<PipelinePage />} />
          <Route path="/live/:subdomain" element={<LiveSitePage />} />
          <Route path="/dashboard"     element={<DashboardLayout />}>
            <Route index                element={<Navigate to="overview" replace />} />
            <Route path="overview"      element={<OverviewPage />} />
            <Route path="security"      element={<SecurityShieldPage />} />
            <Route path="policy"        element={<PolicyEnginePage />} />
            <Route path="audit"         element={<AuditTrailPage />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </ErrorBoundary>
  );
}
