import { useState, useEffect, useCallback } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  Shield, ClipboardList, History, LayoutDashboard,
  Zap, LogOut, Plus, Menu, X,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import TopUpModal from '@/components/TopUpModal';

/* ── Deployment type ──────────────────────────────────────── */
export interface Deployment {
  id: string;
  subdomain: string;
  live_url: string;
  status: string;
  created_at: string;
}

/* ── Context exported for child pages ─────────────────────── */
import { createContext, useContext } from 'react';
interface DashCtx { deployments: Deployment[]; loading: boolean; reload: () => void; }
export const DashContext = createContext<DashCtx>({ deployments: [], loading: true, reload: () => {} });
export function useDash() { return useContext(DashContext); }

const NAV = [
  { to: 'overview',  Icon: LayoutDashboard, label: 'Overview'   },
  { to: 'security',  Icon: Shield,           label: 'Protection' },
  { to: 'policy',    Icon: ClipboardList,    label: 'Rules'      },
  { to: 'audit',     Icon: History,          label: 'History'    },
];

export default function DashboardLayout() {
  const navigate = useNavigate();
  const { profile, signOut, refreshCredits } = useAuth();

  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [depsLoading, setDepsLoading] = useState(true);
  const [showTopUp,   setShowTopUp]   = useState(false);
  const [mobileNav,   setMobileNav]   = useState(false);

  // Redirect unauthenticated users to login
  const { loading: authLoading } = useAuth();
  useEffect(() => {
    if (!authLoading && !profile) navigate('/login', { replace: true });
  }, [authLoading, profile, navigate]);

  const loadDeployments = useCallback(async () => {
    if (!profile?.id) {
      setDeployments([]);
      setDepsLoading(false);
      return;
    }
    setDepsLoading(true);
    try {
      const { data, error } = await supabase
        .from('site_deployments')
        .select('id, subdomain, live_url, status, created_at')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false });
      if (error) {
        console.warn('[dashboard] Deployment load failed:', error.message);
        setDeployments([]);
      } else {
        setDeployments((data as Deployment[]) ?? []);
      }
    } catch (err) {
      console.warn('[dashboard] Deployment load crashed:', err);
      setDeployments([]);
    } finally {
      setDepsLoading(false);
    }
  }, [profile?.id]);

  useEffect(() => { loadDeployments(); }, [loadDeployments]);

  return (
    <DashContext.Provider value={{ deployments, loading: depsLoading, reload: loadDeployments }}>
      {showTopUp && (
        <TopUpModal
          onClose={() => setShowTopUp(false)}
          onSuccess={() => { refreshCredits(); setShowTopUp(false); }}
        />
      )}

      <div className="flex flex-col min-h-screen w-full" style={{ background: '#050d1a' }}>
        {/* ── Top Nav ─────────────────────────────────────────── */}
        <nav className="shrink-0 h-14 flex items-center justify-between px-4 md:px-8 gap-2"
          style={{
            background: 'rgba(7,13,30,0.95)',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            borderBottom: '1px solid rgba(88,166,255,0.12)',
          }}>

          {/* Logo */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.28)' }}>
              <Shield className="w-3.5 h-3.5" style={{ color: '#58a6ff' }} />
            </div>
            <span className="text-xs font-bold tracking-widest uppercase hidden sm:block"
              style={{ color: 'rgba(88,166,255,0.80)' }}>AlphaTekx</span>
          </div>

          {/* Desktop nav tabs */}
          <div className="hidden md:flex items-center gap-1">
            {NAV.map(({ to, Icon, label }) => (
              <NavLink key={to} to={to}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 ${isActive ? 'active-nav' : ''}`
                }
                style={({ isActive }) => ({
                  background: isActive ? 'rgba(88,166,255,0.12)' : 'transparent',
                  color: isActive ? '#58a6ff' : '#8b949e',
                  border: isActive ? '1px solid rgba(88,166,255,0.22)' : '1px solid transparent',
                })}>
                <Icon className="w-3.5 h-3.5 shrink-0" />
                {label}
              </NavLink>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Credits */}
            {profile && (
              <button onClick={() => setShowTopUp(true)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full transition-opacity hover:opacity-80"
                style={{ background: 'rgba(240,136,62,0.10)', border: '1px solid rgba(240,136,62,0.25)', color: '#f0883e' }}
                title="Top up credits">
                <Zap className="w-3 h-3" />
                <span className="text-xs font-semibold">{profile.credit_balance}</span>
                <Plus className="w-3 h-3 opacity-60" />
              </button>
            )}

            {/* Deploy new — desktop */}
            <button onClick={() => navigate('/claim')}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 hover:opacity-80"
              style={{ background: 'rgba(88,166,255,0.10)', border: '1px solid rgba(88,166,255,0.22)', color: '#58a6ff' }}>
              <Plus className="w-3 h-3" /> Deploy New
            </button>

            {/* Avatar */}
            {profile && (
              profile.avatar_url
                ? <img src={profile.avatar_url} alt="avatar"
                    className="w-7 h-7 rounded-full object-cover shrink-0 cursor-pointer"
                    style={{ border: '1px solid rgba(88,166,255,0.25)' }}
                    title={profile.full_name ?? profile.email ?? ''} />
                : <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold"
                    style={{ background: 'rgba(88,166,255,0.12)', border: '1px solid rgba(88,166,255,0.25)', color: '#58a6ff' }}>
                    {(profile.full_name ?? profile.email ?? 'U')[0].toUpperCase()}
                  </div>
            )}

            {/* Sign out */}
            <button onClick={signOut} title="Sign out"
              className="hidden sm:flex items-center justify-center w-7 h-7 rounded-lg transition-opacity hover:opacity-70"
              style={{ color: '#8b949e' }}>
              <LogOut className="w-3.5 h-3.5" />
            </button>

            {/* Mobile hamburger */}
            <button onClick={() => setMobileNav(v => !v)}
              className="md:hidden flex items-center justify-center w-8 h-8 rounded-lg"
              style={{ color: '#8b949e' }}>
              {mobileNav ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </nav>

        {/* ── Mobile Nav Drawer ─────────────────────────────── */}
        {mobileNav && (
          <div className="md:hidden shrink-0 flex flex-col gap-1 px-4 py-3"
            style={{ background: 'rgba(7,13,30,0.98)', borderBottom: '1px solid rgba(88,166,255,0.10)' }}>
            {NAV.map(({ to, Icon, label }) => (
              <NavLink key={to} to={to}
                onClick={() => setMobileNav(false)}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all`
                }
                style={({ isActive }) => ({
                  background: isActive ? 'rgba(88,166,255,0.12)' : 'transparent',
                  color: isActive ? '#58a6ff' : '#8b949e',
                })}>
                <Icon className="w-4 h-4 shrink-0" />
                {label}
              </NavLink>
            ))}
            <div className="h-px my-1" style={{ background: 'rgba(88,166,255,0.08)' }} />
            <button onClick={() => { navigate('/claim'); setMobileNav(false); }}
              className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold"
              style={{ color: '#58a6ff' }}>
              <Plus className="w-4 h-4" /> Deploy New
            </button>
            <button onClick={signOut}
              className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm"
              style={{ color: '#8b949e' }}>
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        )}

        {/* ── Page Content ──────────────────────────────────── */}
        <main className="flex-1 min-w-0 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </DashContext.Provider>
  );
}

