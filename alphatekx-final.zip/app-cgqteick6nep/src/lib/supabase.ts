import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL  as string;
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!SUPABASE_URL || !SUPABASE_ANON) {
  console.warn('[supabase] Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY — continuing with safe placeholders');
}

// Singleton — stored on globalThis to survive HMR re-runs and prevent
// "Multiple GoTrueClient instances" warnings.
const g = globalThis as typeof globalThis & { __supabase?: ReturnType<typeof createClient> };

if (!g.__supabase) {
  g.__supabase = createClient(
    SUPABASE_URL  ?? 'https://placeholder.supabase.co',
    SUPABASE_ANON ?? 'placeholder',
    {
      auth: {
        persistSession:    true,
        autoRefreshToken:  true,
        detectSessionInUrl: true,
        storageKey: 'alphatekx-auth',
      },
    }
  );
}

export const supabase = g.__supabase;
